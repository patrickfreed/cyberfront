<div style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# userpermissions.php - Add/remove permissions for all users/sites
if(!$session->isAdmin()){
	die;
}
if (isset($_REQUEST["rem"])) {
	//Remove a permission
	if (!remove_permission_page($_REQUEST["rem"], $_REQUEST["check"])) {
		echo PROBLEM_REMOVING_PERMISSION . "<br>";
	}
} 
if (isset($_REQUEST["add"])) {
	//Add permission
	if (!add_permission_page($_REQUEST["add"], $_REQUEST["check"])) {
		echo PROBLEM_ADDING_PERMISSION . "<br>";
	}
}
//Get all user's info
$q = "SELECT * FROM users WHERE id = \"" . mysql_real_escape_string($_REQUEST["check"]) . "\"";
$result = mysql_query($q);
if (is_resource($result)) {
	while ($row = mysql_fetch_array($result)) {
	$user = $row["name"];
	}
} 
echo "<h1>" . PERMISSIONS_FOR_TEXT . " " . $user . "</h1>";
echo "<br>";
//Get all the allowed domains for current admin
$q = "SELECT permissions.Permission, domains.Name FROM permissions, domains WHERE permissions.Permission = domains.ID AND permissions.UserID = \"" . $session->user_db_id . "\" AND permissions.Type = \"Domain\" ORDER BY domains.Name";
$result = mysql_query($q);
//print_r(mysql_fetch_array($result));
while ($row = mysql_fetch_array($result)) {
	echo "<table cellspacing=\"5\" border=\"0\" width=\"100%\" style=\"margin-left:10px; border-bottom: 1px solid; border-top: 1px solid; border-left: 1px solid; border-right: 1px solid;\"><tr><td>";
	echo "<h2>" . $row["Name"] . "</h2></td></tr>";
	$q2 = "SELECT permissions.*, pages.* FrOM permissions, pages WHERE permissions.Permission = pages.ID AND permissions.UserID = \"" . mysql_real_escape_string($_REQUEST["check"]) . "\" AND permissions.Type = \"Page\" AND pages.Domain = \"" . mysql_real_escape_string($row["Permission"]) . "\" ORDER BY pages.Name";
	$result2 = mysql_query($q2);
	echo "<tr><td style=\"border-top: 1px dotted;\">" . REMOVE_EXISTING_PERMISSION_TEXT . ":</td></tr>";
	while ($row2 = mysql_fetch_array($result2)) {
		echo "<tr><td><a href=\"?page=u2&amp;popup=1&amp;rem=" . $row2["ID"] . "&amp;check=" . $_REQUEST["check"] . "\">" . $row2["Name"] . "</a></td></tr>";
		$allowed_array[] = $row2["ID"];
	}
	$q2 = "SELECT * from pages WHERE Domain = \"" . mysql_real_escape_string($row["Permission"]) . "\"";
	if (is_array($allowed_array)) {
		foreach ($allowed_array as $allowed) {
			$q2 = $q2 . " AND ID != \"" . $allowed . "\"";
		}
	}
	$q2 = $q2 . " ORDER BY Name";
	$result2 = mysql_query($q2);
	echo "<tr><td><br></td></tr><tr><td style=\"border-top: 1px dotted;\">" . ADD_NEW_PERMISSION_TEXT . "</td></tr>";
	while ($row2 = mysql_fetch_array($result2)) {
		echo "<tr><td><a href=\"?page=u2&amp;popup=1&amp;add=" . $row2["ID"] . "&amp;check=" . $_REQUEST["check"] . "\">" . $row2["Name"] . "</a></td></tr>";
	}
	echo "<tr><td></td></tr></table><br>";
}
echo "<br>";
?>
</div>
</div>
      <div id="sidebar">
       <ul><li><h2><?php echo USER_PERMISSIONS_TEXT;?></h2>
	   <?php echo USER_PERMISSIONS_PAGE_RIGHT_TEXT;?>
	   </li></ul>
      </div>