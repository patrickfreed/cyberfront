<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# main.php - The main page for the cms
if(!$session->logged_in){
die;
}
if ($session->isSuperAdmin() & UPDATE_CHECK == "on") {
	$last_check = LAST_UPDATE_CHECK + 604800;
	if ($last_check < time()) {
		if (function_exists('curl_init')) {
			$ch = curl_init();
			curl_setopt ($ch, CURLOPT_URL, 'http://v-cms.org/v/');
			curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 2);
			$published_version = rtrim(curl_exec($ch));
			curl_close($ch);
		} else {
			$published_version = VCMS_VERSION;
			echo CURL_UPGRADE_CHECK_ERROR . "<br>";
		}
		if ($published_version != false) {
			$q = "UPDATE configuration SET value = \"" . time() . "\" WHERE name = \"LAST_UPDATE_CHECK\"";
			$result = mysql_query($q);
			if ($published_version != VCMS_VERSION) {
				echo UPGRADE_AVAILABLE_TEXT . "<br><a href=\"http://sourceforge.net/projects/v-cms/files/\" target=\"_blank\">V-CMS " . $published_version . "</a><br>";
			} else {
				echo UPDATE_OK_TEXT . "<br>";
			}
		}
	}
}
if ($_REQUEST["saved"] == "1") {
	echo SAVED_TEXT . "<br>";
}
echo "<h1>" . SITES_PAGES_TEXT . "</h1>";
echo CLICKY_NOTICE_TEXT . "<br>";
//Get all domain permissions for current user
$q = "SELECT permissions.Permission, domains.Name FROM permissions LEFT JOIN domains ON permissions.Permission = domains.ID WHERE permissions.Type = \"Domain\" AND permissions.UserID = \"" . $session->user_db_id . "\" ORDER BY domains.Name";
$result = mysql_query($q);
while ($row = mysql_fetch_array($result)){
	$domain_display_temp[] = $row["Permission"];
	$domain_display_name_temp[] = $row["Name"];
}
$q = "SELECT * from domain_sort where UserID = \"" . $session->user_db_id . "\"";
$result = mysql_query($q);
while ($row = mysql_fetch_array($result)) {
	$savedsort = $row["Sort"];
}
if ($savedsort == "") {
	$domain_display = $domain_display_temp;
	$domain_display_name = $domain_display_name_temp;
} else {
	$saved_sort1 = explode(",", $savedsort);
	foreach($saved_sort1 as $sort) {
		if ($sort != "") {
			$domain_display[] = $sort;
			$x = 0;
			while ($x < count($domain_display_temp)) {
					if ($domain_display_temp[$x] == $sort) {
					$domain_display_temp[$x] = "";
				}
				$x = $x + 1;
			}
		}
	}
	foreach($domain_display_temp as $display_temp) {
		if ($display_temp != "") {
			$domain_display[] = $display_temp;
		}
	}
}
?>
<script type="text/javascript">
$(function(){
	$('.dragbox')
	.each(function(){
		$(this).hover(function(){
			$(this).find('h2').addClass('collapse');
		}, function(){
			$(this).find('h2').removeClass('collapse');
		})
		.end()
	});
	$('.column').sortable({
		connectWith: '.column',
		handle: 'h3',
		cursor: 'move',
		placeholder: 'placeholder',
		forcePlaceholderSize: true,
		opacity: 0.4,
		stop: function(event, ui){
			sortorder="";
			$(ui.item).find('h3').click();
			$('.column').each(function(){
				var itemorder=$(this).sortable('toArray');
				var columnId=$(this).attr('id');
				sortorder+=columnId+'='+itemorder.toString()+'&';
			});
			$("#sort_update").html("<img src='images/ajax-loader.gif' alt='<?php echo LOADING_TEXT;?>'>").load("includes/sort_update.php?"+sortorder);
		}
	})

});
$(function(){
	$('.dragbox_page')
	.each(function(){
		$(this).hover(function(){
			$(this).find('h3').addClass('collapse');
		}, function(){
			$(this).find('h3').removeClass('collapse');
		})
		.end()
	});

});
function deleteconfirm(de,item,title) {
		switch(item){
			case "1":
				var item_name = "domain";
				break;
			case "2":
				var item_name = "page";
				break;
			case "3":
				var item_name = "editor";
				break;
		}
		var answer = confirm("<?php echo DELETE_ARE_YOU_SURE_TEXT;?> " + item_name + ": " + title)
		if (answer){
			$('#sort_update').html("<img src='images/ajax-loader.gif' alt='<?php echo LOADING_TEXT;?>'>").load("includes/process_d.php?de2=" + de + "&item=" + item); 
			//if (item=="1") {
			//	window.location.reload();
			//} else {
			//	editorsupdate();
			//	domainupdate(de,'<?php echo ENABLE_IMAGE_MANAGER;?>','<?php echo ENABLE_LINK_MANAGER;?>', '<?php echo ENABLE_MEDIA_MANAGER;?>', '<?php echo ENABLE_INLINE_EDITOR;?>');
			//	window.location.reload();
			//}
		}
	}
	var mouse_is_inside = false;

</script>
<script type="text/javascript">
function domainupdate(domain, enableimage, enablelink, enablemedia, inlineeditor) {
	var theid = "#domain" + domain;
	if ($(theid).length == 0) {
		window.location.reload();
	}else{
		var loadUrl = "includes/get_domain.php?count=1&InlineEditor="+inlineeditor+"&enablelink=" + enablelink + "&enableimg=" + enableimage + "&enablemedia=" + enablemedia + "&update=1&domain=" + domain;
		$(theid).html("<img src='images/ajax-loader.gif' alt='<?php echo LOADING_TEXT;?>'>").load(loadUrl);
	}
}
</script><br>
<div id="sort_update">&nbsp;</div>
<?php
//Start page display
//Get domain info on permitted domains
$domain_counter = 0;
echo "<div class=\"column\" id=\"column1\">";
$_REQUEST["count"] = count($domain_display);
while($domain_counter < count($domain_display)) {
	echo "<div class=\"domain" . $domain_display[$domain_counter] . "\" id=\"domain" . $domain_display[$domain_counter] . "\">";
	$_REQUEST["domain"] = $domain_display[$domain_counter];
	include('includes/get_domain.php');
	$domain_counter = $domain_counter + 1;
	echo "</div>";
}
if ($domain_counter == 0) {
	echo "<p>" . NO_PAGES_FOUND_TEXT . "</p>";
}	
?>
</div>
<?php
if ($session->isAdmin()){
	?>
	<script type="text/javascript">
	function editorsupdate() {
		var theid = "#editors_update";
		var loadUrl = "includes/get_editors.php?update=1";
		$(theid).html("<img src='images/ajax-loader.gif' alt='<?php echo LOADING_TEXT;?>'>").load(loadUrl);  
	}
	</script>
	<br>
	<a href="?page=a1&amp;popup=1" class="btn blue add_page_lightbox"><i></i><span><span></span><i></i><?php echo ADD_NEW_SITE_TEXT; ?></span></a>
	<br><br><br><div style="padding: 3px; border-bottom: 1px solid; border-top: 1px solid; border-left: 1px solid; border-right: 1px solid;">
	<div id="editorsclick"><h2><a href="#" class="heading2" onClick="$('#editors_div').slideToggle('slow', function() {});return false;">
	<?php echo EDITORS_TEXT;?><img src="images/e_c.png" alt="+/-" border=0></a></h2></div><div id="editors_update">
	<?php
	include('includes/get_editors.php');
	echo "</div></div>";
}
if ($noborder!=1) {
	?></div>
    <div id="sidebar">
    <ul><li><h2><?php echo WELCOME_TEXT;?></h2>
	<?php if ($session->isAdmin()) {
		echo WELCOME_PAGE_RIGHT_ADMIN_TEXT;
	} else {
		echo WELCOME_PAGE_RIGHT_EDITOR_TEXT;
	}
	?>
	</li></ul></div>
<?php
}
?>