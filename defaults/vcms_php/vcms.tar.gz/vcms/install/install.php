<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC

if (!function_exists("page_owner")) {
	die;
}
if ($_GET["re"] == "1") {
	header("Location: ../index.php");
	die;
}
echo "<h1>" . INSTALL_HEADER_TEXT . "</h1>";
$install_query[] = "CREATE TABLE IF NOT EXISTS `active_guests` (
  `ip` varchar(15) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `active_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `banned_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `configuration` (
  `ID` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `value` varchar(254) NOT NULL,
  `tab` varchar(2) NOT NULL,
  `sortorder` int(3) NOT NULL,
  `active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8";
$install_query[] = "
CREATE TABLE IF NOT EXISTS `domains` (
  `ID` int(11) NOT NULL auto_increment,
  `Name` varchar(50) NOT NULL,
  `ftp` varchar(255) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` blob NOT NULL,
  `SiteURL` varchar(255) NOT NULL,
  `Path` varchar(255) NOT NULL,
  `ImagePath` varchar(255) NOT NULL,
  `LinkPath` varchar(255) NOT NULL,
  `MediaPath` varchar(255) NOT NULL,
  `CustomCSS` varchar(255) NOT NULL,
  `InlineEditor` varchar(2) NOT NULL,
   `FTPType` varchar(4) NOT NULL,
   `Port` varchar(6) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `img_revisions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PageID` int(11) NOT NULL,
  `Path` varchar(255) NOT NULL,
  `ImgID` varchar(50) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `pages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Path` varchar(255) NOT NULL,
  `Domain` int(11) NOT NULL,
  `CustomCSS` varchar(255) NOT NULL,
  `InlineEditor` varchar(2) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `page_sort` (
  `UserID` varchar(50) NOT NULL,
  `Domain` varchar(255) NOT NULL,
  `Sort` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `permissions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` varchar(32) NOT NULL,
  `Type` varchar(10) NOT NULL,
  `Permission` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `revisions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PageID` int(11) NOT NULL,
  `Path` varchar(255) NOT NULL,
  `TimeStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `userid` varchar(32) DEFAULT NULL,
  `userlevel` tinyint(1) unsigned NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  `valid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `parent` varchar(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1";
$install_query[] = "CREATE TABLE IF NOT EXISTS `domain_sort` (
  `UserID` varchar(50) NOT NULL,
  `Sort` varchar(255) NOT NULL,
  UNIQUE KEY `UserID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$install_query[] = "INSERT INTO `configuration` (`ID`, `name`, `value`, `tab`, `sortorder`, `active`) VALUES
(1, 'VCMS_INSTALLED_VERSION', '1.0', '0', 0, 0),
(2, 'LAST_UPDATE_CHECK', '0', '0', 0, 0),
(3, 'SITE_NAME', 'V-CMS', '1', 5, 1),
(4, 'TAGLINE', 'A Completely Open Source Simple CMS', '1', 10, 1),
(5, 'EMAIL_FROM_ADDR', 'cms@domain.com', '1', 15, 1),
(6, 'CUSTOM_CLASS_1', '', '1', 20, 1),
(7, 'CUSTOM_CLASS_2', '', '1', 25, 1),
(8, 'ALLOWED_REVISIONS', '6', 1, 30, 1),
(9, 'LOGO_IMAGE', 'images/logo.png', '2', 5, 1),
(10, 'BACKGROUND_CSS', 'url(images/img01.jpg) repeat-x left top', '2', 10, 1),
(11, 'HEADER_COLOR', '#AA2808', '2', 15, 5),
(12, 'BUTTON_BACKGROUND', '#22aaee', '2', 20, 5),
(13, 'BUTTON_COLOR', '#ffffff', '2', 25, 5),
(14, 'BUTTON_HOVER_BACKGROUND', '#aa0000', '2', 30, 5),
(15, 'BUTTON_HOVER_COLOR', '#ffffff', '2', 35, 5),
(16, 'BUTTON_ACTIVE_BACKGROUND', '#444444', '2', 40, 5),
(17, 'BUTTON_ACTIVE_COLOR', '#ffffff', '2', 45, 5),
(18, 'CUSTOM_HELP_LINK', '', '1', 35, 1),
(19, 'CUSTOM_CSS', 'css/style.css', '2', 50, 1),
(20, 'UPDATE_CHECK', 'on', '1', 40, 2),
(21, 'ENABLE_PUBLIC_SIGNUP', '', '1', 45, 2),
(22, 'ENABLE_IMAGE_MANAGER', 'on', '1', 50, 2),
(23, 'ENABLE_LINK_MANAGER', 'on', '1', 55, 2),
(24, 'ENABLE_MEDIA_MANAGER', 'on', '1', 60, 2),
(25, 'RESTRICTED_UPLOAD_TYPES', 'php,php3,php4,php5,shtm,shtml,asp,cgi,pl,cfm,cfml,rb', '1', 65, 1),
(26, 'SYSTEM_CHECKS', 'on', '1', 42, 2),
(27, 'ENABLE_INLINE_EDITOR', 'on', '1', 13, 2),
(28, 'IE_WARNING', 'on', '1', 14, 2),
(29, 'SUBMIT_STATS', 'on', '1', 15, 2),
(30, 'COLORBOX_STYLE', '1', '2', 50, 1);";

foreach ($install_query as $install) {
	if (!mysql_query($install)) {	
		echo CREATE_TABLE_DATABASE_ERROR_TEXT . "<br>";
		$good = 0;
	} else {
		$good = 1;
	}
}
if ($good == 1) {
	echo CREATE_TABLE_DATABASE_SUCCESS_TEXT . "<br>";
}

if($form->num_errors > 0){
   echo "<font size=\"2\" color=\"#ff0000\">".$form->num_errors." " . ERRORS_FOUND_TEXT . "</font>";
}

echo ATTEMPT_CHMOD . "<br>";
$chmod_error = 0;
$chmod_array[] = "temp";
foreach ($chmod_array as $chmod){
	echo "\"" . $chmod . "\"...";
	@chmod($chmod, 0777);
	if (substr(sprintf('%o', fileperms($chmod)), -4) == "0777") {
		echo OK_TEXT . "<br>";
	} else {
		echo CHMOD_FAILED_TEXT . "<br><br>";
		$chmod_error = 1;
	}
}
if ($chmod_error == 1) {
	echo "<span style=\"color: red;\">" . CHMOD_ERROR_TEXT . "</span><br><br>";
}
?>
<div class="form_main">
<form action="process.php" name="new" method="POST">
		<div class="form_a"><div class="form_left"><?php echo NAME_TEXT;?>:</div><div class="form_right"><input type="text" name="name" maxlength="30" size="30" value="<?php echo $form->value("name"); ?>"><?php echo $form->error("name"); ?></div></div>
		<div class="form_a"><div class="form_left"><?php echo USER_NAME_TEXT;?>:</div><div class="form_right"><input type="hidden" name="user" value="admin"><b>admin</b> <?php echo $form->error("user"); ?></div></div>
		<div class="form_a"><div class="form_left"><?php echo PASSWORD_TEXT;?>:</div><div class="form_right"><input type="password" name="pass" size="30" maxlength="30" value="<?php echo $form->value("pass"); ?>"><?php echo $form->error("pass"); ?></div></div>
		<div class="form_a"><div class="form_left"><?php echo EMAIL_TEXT;?>:</div><div class="form_right"><input type="text" name="email" size="30" maxlength="50" value="<?php echo $form->value("email"); ?>"><?php echo $form->error("email"); ?></div></div>
		<div class="form_a"><div class="form_left"></div><div class="form_right"><input type="hidden" name="subjoin" value="1"><input type="submit" style="visibility:hidden"><a href="#" onclick="document.new.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo SUBMIT_TEXT;?></span></a></div></div>
	<br><br>
	</form>
	<BR><BR>
	</div>
	<?php
if ($noborder!=1) {
?></div></div>
      <div id="sidebar">
       <ul><li><h2><?php echo INSTALL_HEADER_TEXT;?></h2>
	   <?php echo INSTALL_PAGE_RIGHT_TEXT;?>
</li></ul>
      </div>

		
<?php
}
?>	 