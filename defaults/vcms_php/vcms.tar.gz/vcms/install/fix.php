<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
if (!function_exists("page_owner")) {
	die;
}
echo "<h1>" . FIX_ADMIN_HEADER_TEXT . "</h1>";
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
$q = "UPDATE users SET valid = \"1\" WHERE username = 'admin'";
$result = mysql_query($q);
echo FIX_ADMIN_FIXED_TEXT . "<br>";
?>
<?php
if ($noborder!=1) {
?></div></div></div>
      <!-- end div#content -->
      <div id="sidebar">
       <ul><li><h2><?php echo FIX_ADMIN_HEADER_TEXT;?></h2>
	   <?php echo INSTALL_PAGE_RIGHT_TEXT;?>
</li></ul>
      </div>

		
<?php
}
?>	 