<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
if (!$session->isSuperAdmin()) {
	die;
}

$versions = array("x", "1.0 RC3", "1.0");
$current_version = array_search(VCMS_INSTALLED_VERSION, $versions);

echo "<h1>" . UPGRADE_HEADER_TEXT . "</h1>";
if ($current_version == sizeof($versions)-1) {
	echo NO_UPGRADE_NEEDED_TEXT;
} else {
	//Starting with the next version in the array, build the queries needed to be executed to upgrade the database
	for($a=$current_version+1; $a < sizeof($versions); $a++) {
		switch ($a){
			case 1:
				//1.0 RC3
				//No upgrade information, this is the first version that can be upgraded from
				break;
			case 2:
				//1.0
				$upgrade_query[] = "UPDATE configuration SET value = '1.0' WHERE name = 'VCMS_INSTALLED_VERSION';";
				break;
		}
	}
	//Execute the queries
	foreach ($upgrade_query as $upgrade) {
		if (!mysql_query($upgrade)) {	
			echo UPGRADE_DATABASE_ERROR_TEXT . "<br>" . mysql_error() . "<br>" . QUERY_TEXT . ":" . $upgrade . "<br>";
			$bad = true;
		} else {
			$good = true;
		}
	}
	if ($bad) {
		echo UPGRADE_DATABASE_ERRORS_FOUND_TEXT . "<br>";
	}
	if ($good) {
		echo UPGRADE_DATABASE_SUCCESS_TEXT . "<br>";
	}
}

if ($noborder!=1) {
?>
</div>
      <div id="sidebar">
       <ul><li><h2><?php echo UPGRADE_HEADER_TEXT;?></h2>
	   <?php echo UPGRADE_PAGE_RIGHT_TEXT;?>
</li></ul>
      </div>

		
<?php
}
?>	 