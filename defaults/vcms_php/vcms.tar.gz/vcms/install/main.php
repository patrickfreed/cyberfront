<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
if (!function_exists("page_owner")) {
	die;
}
echo "<h1>" . INSTALL_TEXT . "</h1>";
echo INSTALL_WELCOME_TEXT . "<br><br><hr><br>";
echo FIX_ADMIN_WELCOME_TEXT . "<br><br><hr>";
?>
<BR>
<a href="../index.php?page=install2" class="btn blue"><i></i><span><span></span><i></i><?php echo INSTALL_TEXT;?></a>
<a href="../index.php?page=fix_admin" class="btn blue"><i></i><span><span></span><i></i><?php echo FIX_ADMIN_TEXT;?></a>
<br><br>
<?php
if (phpversion() < 5.3) {
	$phpversion_ok = '<font color="red">' . NOT_OK_TEXT . '(' . phpversion() . ' ' . FOUND_TEXT . ')</font>';
	$install_error = true;
} else {
	$phpversion_ok = '<font color="green">' . OK_TEXT . '</font>';
}
$gd_version = phpversion('gd');
$imagick_version = phpversion('imagick');

if ($gd_version && $imagick_version == '') {
	$image_ext = '<font color="red">' . NOT_OK_TEXT . '</font>';
	$install_error = true;
} else {
	$image_ext = '<font color="green">' . OK_TEXT . '</font>';
}
echo SYSTEM_CHECKS_TEXT . '<br>';
echo PHP_VERSION_TEXT . ':' . $phpversion_ok . '<br>';
echo GD_IMAGICK_TEXT . ':' . $image_ext . '<br>';
if ($install_error) {
	echo SYSTEM_CHECK_ERROR_TEXT . '<br>';
}

if ($noborder!=1) {
?></div></div>
      <!-- end div#content -->
      <div id="sidebar">
       <ul><li><h2><?php echo INSTALL_TEXT;?></h2>
	   <?php echo INSTALL_PAGE_RIGHT_TEXT;?>
</li></ul>
      </div>

		
<?php
}
?>	 