<div style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# File originally from Jpmaster77's login system
if($session->logged_in){
	echo "<h1>" . USER_ACCOUNT_EDIT_TEXT . " : " . $session->username . "</h1>";
	if($form->num_errors > 0){
	echo "<font size=\"2\" color=\"#ff0000\">".$form->num_errors." " . ERRORS_FOUND_TEXT . "</font><br><br>";
	}
	?>
	<div class="form_main">
	<form action="process.php" name="useredit" method="POST">
	<div class="form_a"><div class="form_left"><?php echo NAME_TEXT;?>:</div><div class="form_right"><input class="left" type="text" id="name" name="name" size="45" maxlength="25" value="<?php
	if($form->value("name") == ""){
		echo $session->userinfo['name'];
	}else{
		echo $form->value("name");
	}
	?>"><?php echo $form->error("name"); ?></div></div>
	<div class="form_a"><div class="form_left"><?php echo CURRENT_PASSWORD_TEXT;?>:</div><div class="form_right"><input type="password" size="45" id="curpass" name="curpass" maxlength="30" value="<?php echo $form->value("curpass"); ?>"><?php echo $form->error("curpass"); ?></div></div>
	<div class="form_a"><div class="form_left"><?php echo NEW_PASSWORD_TEXT;?>:</div><div class="form_right"><input class="left" type="password" size="45" id="newpass" name="newpass" maxlength="30" value="<?php echo $form->value("newpass"); ?>"><?php echo $form->error("newpass"); ?></div></div>
	<div class="form_a"><div class="form_left"><?php echo EMAIL_TEXT;?>:</div><div class="form_right"><input class="left" type="text" name="email" size="45" id="email" maxlength="50" value="<?php
	if($form->value("email") == ""){
		echo $session->userinfo['email'];
	}else{
		echo $form->value("email");
	}
	?>"><?php echo $form->error("email"); ?></div></div>
	<div class="form_a"><div class="form_left">&nbsp;</div><div class="form_right"><input type="hidden" name="subedit" value="1">
	<a href="#" onclick="document.useredit.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo SAVE_SETTINGS_TEXT;?></span></a>
	<input style="visibility:hidden" type="submit"></div></div><br>&nbsp;<br>
	</form>
	</div>
<?php
}
?>
</div>
</div>
</div>
      <div id="sidebar">
       <ul><li><h2><?php echo MY_ACCOUNT_TEXT;?></h2><?php echo USER_EDIT_PAGE_RIGHT_TEXT;?></li></ul>
      </div>