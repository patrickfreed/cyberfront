<div style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# File originally from Jpmaster77's login system
if($form->num_errors > 0){
   echo "<font size=\"2\" color=\"#ff0000\">".$form->num_errors." " . ERRORS_FOUND_TEXT . "</font>";
}
?>
<div id="register">
<?php
if ($session->isAdmin()){
	?>
	<h1><?php echo ADD_NEW_EDITOR_TEXT;?></h1>
	<?php
} else {
?>
	<h1><?php echo NEW_ACCOUNT_TEXT;?></h1>
<?php
}
?><div class="form_main">
	<form action="process.php" name="new" method="POST">
	<div class="form_a"><div class="form_left">
		<?php echo NAME_TEXT;?>:</div><div class="form_right"><input type="text" name="name" maxlength="30" size="30" value="<?php echo $form->value("name"); ?>"><?php echo $form->error("name"); ?></div></div>
		<div class="form_a"><div class="form_left"><?php echo USER_NAME_TEXT;?>:</div><div class="form_right"><input type="text" name="user" size="30" maxlength="30" value="<?php echo $form->value("user"); ?>"><?php echo $form->error("user"); ?></div></div>
		<div class="form_a"><div class="form_left"><?php echo PASSWORD_TEXT;?>:</div><div class="form_right"><input type="password" name="pass" size="30" maxlength="30" value="<?php echo $form->value("pass"); ?>"><?php echo $form->error("pass"); ?></div></div>
		<div class="form_a"><div class="form_left"><?php echo EMAIL_TEXT;?>:</div><div class="form_right"><input type="text" name="email" size="30" maxlength="50" value="<?php echo $form->value("email"); ?>"><?php echo $form->error("email"); ?></div></div>
		<div class="form_a"><div class="form_left"></div><div class="form_right"><input type="hidden" name="subjoin" value="1"><input type="submit" style="visibility:hidden"><a href="#" onclick="document.new.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo SUBMIT_TEXT;?></span></a>
		</div></div><br><br>
	</form>
	</div>
</div>
</div>
</div>
    <div id="sidebar">
    <ul><li><h2><?php echo NEW_ACCOUNT_TEXT;?></h2><?php echo NEW_ACCOUNT_PAGE_RIGHT_TEXT;?></li></ul>
    </div>