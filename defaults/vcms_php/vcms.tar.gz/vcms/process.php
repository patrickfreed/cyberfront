<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# File originally from Jpmaster77's login system
require('includes/config.php');
include("includes/session.php");
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
$query = "SELECT * FROM configuration";
$result = mysql_query($query);
	while ($row = mysql_fetch_array($result)) {
		if ($row["value"] != "") {
			define($row["name"], $row["value"]);
		}
	}
require("includes/languages/" . LANGUAGE_FILE . ".php");
class Process
{
   /* Class constructor */
   function Process(){
      global $session;
      /* User submitted login form */
      if(isset($_POST['sublogin'])){
         $this->procLogin();
      }
      /* User submitted registration form */
      else if(isset($_POST['subjoin'])){
         $this->procRegister();
      }
      /* User submitted forgot password form */
      else if(isset($_POST['subforgot'])){
         $this->procForgotPass();
      }
      /* User submitted edit account form */
      else if(isset($_POST['subedit'])){
         $this->procEditAccount();
      }
      else if(isset($_POST['subConfirm'])){
      	$this->procSendConfirm();
	  
	  }
      /**
       * The only other reason user should be directed here
       * is if he wants to logout, which means user is
       * logged in currently.
       */
      else if(isset($_REQUEST['logout'])){
         $this->procLogout();
      }
      /**
       * Should not get here, which means user is viewing this page
       * by mistake and therefore is redirected.
       */
       else{
          header("Location: index.php");
       }
   }

   /**
    * procLogin - Processes the user submitted login form, if errors
    * are found, the user is redirected to correct the information,
    * if not, the user is effectively logged in to the system.
    */
   function procLogin(){
      global $session, $form;
      /* Login attempt */
      $retval = $session->login($_POST['user'], $_POST['pass'], isset($_POST['remember']));
      
      /* Login successful */
      if($retval){
         header("Location: ".$session->referrer);
      }
      /* Login failed */
      else{
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer);
      }
   }
   
   /**
    * procLogout - Simply attempts to log the user out of the system
    * given that there is no logout form to process.
    */
   function procLogout(){
      global $session;
      $retval = $session->logout();
      header("Location: index.php");
   }
   
   /**
    * procRegister - Processes the user submitted registration form,
    * if errors are found, the user is redirected to correct the
    * information, if not, the user is effectively registered with
    * the system and an email is (optionally) sent to the newly
    * created user.
    */
   function procRegister(){
      global $session, $form;
      /* Convert username to all lowercase (by option) */
      if(ALL_LOWERCASE){
         $_POST['user'] = strtolower($_POST['user']);
      }
      /* Registration attempt */
      $retval = $session->register($_POST['user'], $_POST['pass'], $_POST['email'], $_POST['name']);
      
      /* Registration Successful */
      if($retval == 0){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = true;
		 if ($session->logged_in) {
			echo "<script type=\"text/javascript\">parent.editorsupdate(); parent.$.colorbox.close();</script>";
		} else {
			header("Location: ".$session->referrer."?re=1");
		}
      }
      /* Error found with form */
      else if($retval == 1){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
		 if ($session->logged_in) {
			$loc = "index.php?page=r1&popup=1";
		 } else {
			$loc = "index.php?page=r1";
		 }
         header("Location: " . $loc);
      }
      /* Registration attempt failed */
      else if($retval == 2){
         $_SESSION['reguname'] = $_POST['user'];
         $_SESSION['regsuccess'] = false;
         header("Location: ".$session->referrer);
      }
   }
   
   /**
    * procForgotPass - Validates the given username then if
    * everything is fine, a new password is generated and
    * emailed to the address the user gave on sign up.
    */
   function procForgotPass(){
      global $database, $session, $mailer, $form;
      /* Username error checking */
      $subuser = $_POST['user'];
      $field = "user";  //Use field name for username
      if(!$subuser || strlen($subuser = trim($subuser)) == 0){
         $form->setError($field, "* " . USERNAME_EMPTY_ERROR_TEXT . "<br>");
      }
      else{
         /* Make sure username is in database */
         $subuser = stripslashes($subuser);
         if(strlen($subuser) < 5 || strlen($subuser) > 30 ||
            !eregi("^([0-9a-z])+$", $subuser) ||
            (!$database->usernameTaken($subuser))){
            $form->setError($field, "* " . USERNAME_NOT_EXIST_ERROR_TEXT . "<br>");
         }
      }
      
      /* Errors exist, have user correct them */
      if($form->num_errors > 0){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
      }
      /* Generate new password and email it to user */
      else{
         /* Generate new password */
         $newpass = $session->generateRandStr(8);
         
         /* Get email of user */
         $usrinf = $database->getUserInfo($subuser);
         $email  = $usrinf['email'];
         
         /* Attempt to send the email with new password */
         if($mailer->sendNewPass($subuser,$email,$newpass)){
            /* Email sent, update database */
            $database->updateUserField($subuser, "password", md5($newpass));
            $_SESSION['forgotpass'] = true;
         }
         /* Email failure, do not change password */
         else{
            $_SESSION['forgotpass'] = false;
         }
      }
      
      header("Location: ".$session->referrer);
   }
   
   /**
    * procEditAccount - Attempts to edit the user's account
    * information, including the password, which must be verified
    * before a change is made.
    */
   function procEditAccount(){
      global $session, $form;
      /* Account edit attempt */
      $retval = $session->editAccount($_POST['curpass'], $_POST['newpass'], $_POST['email'], $_POST['name']);

      /* Account edit successful */
      if($retval){
         $_SESSION['useredit'] = true;
         //header("Location: includes/useredit.php");
		 echo "<script type=\"text/javascript\">parent.$.colorbox.close();</script>";
		 
      }
      /* Error found with form */
      else{
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
		 header('Location: index.php?page=u1&popup=1');
      }
   }
   
   /**
   	* procSendConfirm - only needs to be used if the administrator
   	* changes the EMAIL_WELCOME from false to true and wants
   	* the users to confirm themselves. (why not?!)
   	*/
   function procSendConfirm(){
       global $session, $form, $database, $mailer;
       
       $user	=	$_POST['user'];
       $pass	=	$_POST['pass'];
       
      /* Checks that username is in database and password is correct */
      $user = stripslashes($user);
      $result = $database->confirmUserPass($user, md5($pass));

      /* Check error codes */
      if($result == 1){
         $field = "user";
         $form->setError($field, "* " . USERNAME_NOT_EXIST_ERROR_TEXT);
      }
      elseif($result == 2){
         $field = "pass";
         $form->setError($field, "* " . PASSWORD_ERROR_TEXT);
      }
      
      /* Check to see if the user is already valid */
      $q = "SELECT valid FROM ".TBL_USERS." WHERE username='$user'";
      $valid = $database->query($q);
      $valid = mysql_fetch_array($valid);
      $valid = $valid['valid'];
      
      if($valid == 1){
         $field = 'user';
         $form->setError($field, "* " . USERNAME_CONFIRMED_ERROR_TEXT);
      }
      
      /* Return if form errors exist */
      if($form->num_errors > 0){
         $_SESSION['value_array'] = $_POST;
         $_SESSION['error_array'] = $form->getErrorArray();
         header("Location: ".$session->referrer);
      }
      else{
	      $q = "SELECT username, userid, email FROM ".TBL_USERS." WHERE username='$user'";
	      $info = $database->query($q) or die(mysql_error());
	      $info = mysql_fetch_array($info);
	      
		      $username = $info['username'];
		      $userid = $info['userid'];
		      $email = $info['email'];
	      
	      if($mailer->sendConfirmation($username,$userid,$email)){
	      	  echo CONFIRMATION_SENT_TEXT;
	      }
	  }
   }
};
/* Initialize process */
$process = new Process;
?>