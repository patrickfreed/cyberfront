<div style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#


# image_manager.php - The image manager

if(!$session->logged_in){
	die;
}
//SQL Injection prevention
$_REQUEST["domain"] = mysql_real_escape_string($_REQUEST["domain"]);

//File Injection prevention
$replace_array = array("/", "\\", "..");
$_REQUEST["thefile"] = str_replace($replace_array, "", $_REQUEST["thefile"]);

//Security Check
if (!domain_permission_check($_REQUEST["domain"])) {
	die("Domain " . $_REQUEST["domain"] . " not allowed.");
}
//Get domain login info
$ftp = new VCMS_FTP;
$ftp->GetDomainInfo($_REQUEST["domain"]);

$ftp->Open();
$_REQUEST["path"] = "/" . $ftp->path . "/" . $ftp->image_path;
$current_path = $_REQUEST["path"] . "/";
//If we cannot chage to the image directory, create one
$ftp->CheckDirectory($current_path);

if ($_REQUEST["delete"] == "1") {
$ftp->delete($_REQUEST["thefile"]);
}
$filedir = 'temp/'; // the directory for the original image
$thumbdir = 'temp/'; // the directory for the thumbnail image
$prefix = 'small_'; // the prefix to be added to the original name
$maxfile = '2000000';
$mode = '0666';			

$allowedExtensions = array("jpg","jpeg","png","gif","bmp");
$userfile_name = $_FILES['image']['name'];
$userfile_tmp = $_FILES['image']['tmp_name'];
$userfile_size = $_FILES['image']['size'];
$userfile_type = $_FILES['image']['type'];
if ($_POST["height"] == "") {$_POST["height"] = 0;}
if ($_POST["width"] == "") {$_POST["width"] = 0;}
if ($userfile_name != "") {
	if(!in_array(end(explode(".", strtolower($userfile_name))), $allowedExtensions)) {
		echo IMAGE_UPLOAD_INVALID_TYPE_TEXT;
	} else {
		//Image uploaded, process...
		$prod_img = $filedir.$userfile_name;
		move_uploaded_file($userfile_tmp, $prod_img);
		chmod ($prod_img, octdec($mode));
		if (($_POST["height"] != 0) || ($_POST["width"] != 0)){
			//Height or width found, resize image...
			echo RESIZING_PHOTO_TEXT . "...";
			if (!class_exists('Resize_Image')){
				include 'includes/resize.image.class.php';
			}
			$image = new Resize_Image;
			$image->new_width = $_POST["height"];
			$image->new_height = $_POST["width"];
			if ($image->new_width == "") { $image->new_width=0;}
			if ($image->new_height == "") { $image->new_width=0;}
			$image->image_to_resize = $prod_img; // Full Path to the file
			$image->ratio = true; // Keep Aspect Ratio?
			// Name of the new image (optional) - If it's not set a new will be added automatically
			$image->new_image_name = $prefix.$userfile_name;
			/* Path where the new image should be saved. If it's not set the script will output the image without saving it */
			$image->save_folder = $thumbdir;
			$process = $image->resize();
			if($process['result'] && $image->save_folder) {
				$prod_img_thumb = $process['new_file_path'];
				//Successful!
				echo OK_TEXT . "<br>";
			} else {
				//Fail
				echo ERROR_RESIZE_IMAGE_TEXT . '<br>';
			}
		}	
		if ($prod_img_thumb == "") {
			$prod_img_thumb = $prod_img;
		}
		//ftp to server.
		$ftp->put($current_path . $userfile_name, $prod_img_thumb, FTP_BINARY);
		//cleanup
		unlink($prod_img_thumb);
		$prod_img_thumb = "";


	}
}
	if ($_REQUEST['inline'] == '1') {
		echo '[<a href="#" onClick="parent.$(\'#image_manager_dropdown\').slideToggle(\'slow\'); return false;">' . CLOSE_TEXT . '</a>]<br>';
	}

echo "<h1>" . IMAGE_MANAGER_TEXT . "</h1>";
?>
<script type="text/javascript">
function deleteconfirm(message, place){
    var answer = confirm(message)
    if (answer){
        window.location = place;
    }
	return false;
} 
</script>
<form name="image_submit" action="index.php" method="post" enctype="multipart/form-data">
<table cellpadding=5 cellspacing=15 width="100%">
<?php

$ftp->GetFileList($current_path);
$paths = explode("/", $_REQUEST["path"]);
$image_counter = 0;


if (!empty($ftp->filelist)) {
		foreach ($ftp->filelist as $dirname => $dirinfo) {
		$image_counter++;
		if ($image_counter > 5) {
			$image_counter=1;
			echo "</tr><tr>";
		}





		echo "<td align=center><img align=top border=0 src=\"includes/phpThumb/phpThumb.php?&amp;bg=ffffff&amp;w=96&amp;src=" . $ftp->site_url . "/" . $ftp->image_path . "/" . $dirname . "\"><br><font style=\"font-size:.75em; font-weight:bold;\">" . wordwrap($dirname, 12, "<br>", true) . "</font><br><a onclick=\"return deleteconfirm('" . ARE_YOU_SURE_DELETE_TEXT . " " . $dirname . "','?page=i1&amp;";
				if ($_REQUEST['inline'] == '1') {
			echo "inline=1&amp;";
		}
		echo "popup=1&amp;delete=1&amp;domain=" . $_REQUEST["domain"] . "&amp;thefile=" . $dirname . "');\" href=\"#\">" . DELETE_TEXT . "</a></td>";
	}
}
if ($image_counter == 0) {
	echo "<td align=center width=\"100%\">" . NO_LINKS_FOUND_TEXT . "</td>";
}
?>
</table><br>
<LABEL for="firstname"><?php echo IMAGE_TEXT;?>: </LABEL>
				<input type="file" name="image"><br> 
				<?php echo HEIGHT_TEXT;?>: <input type="text" name="height" size="4" value=""> <?php echo PIXELS_TEXT;?> - <?php echo WIDTH_TEXT;?>: <input type="text" size="4" name="width" value=""> <?php echo PIXELS_TEXT;?><br>
				<input type="hidden" name="upload_image" value="1">
				<input type="hidden" name="domain" value="<?php echo $_REQUEST["domain"];?>">
				<input type="hidden" name="page" value="i1">
				<input type="hidden" name="popup" value="1">
				<?php
				if ($_REQUEST['inline'] == '1') {
					echo '<input type="hidden" name="inline" value="1">';
				}
				?>
				<a href="#" onclick="document.image_submit.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo UPLOAD_NEW_IMAGE_TEXT;?></span></a>
			<br><br></form>
			</div>
</div>
      <div id="sidebar">
       <ul><li><h2><?php echo IMAGE_MANAGER_TEXT;?></h2><?php echo IMAGE_MANAGER_RIGHT_TEXT;?>




</li></ul>
      </div>