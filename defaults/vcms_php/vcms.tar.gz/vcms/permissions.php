<div style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# permissions.php - Called by the page settings button
?>
<script type="text/javascript">
    if (parent.$("#colorbox").css("display")=="block") {  
          
    }else{  
        window.location = 'index.php';  
    }  
</script>
<?php
if(!$session->isAdmin()){
	die;
}
//Check if configuration has been loaded
if (ENABLE_INLINE_EDITOR == 'ENABLE_INLINE_EDITOR') {
	$query = 'SELECT * FROM configuration';
	$result = mysql_query($query);
	if ($result) {
		while ($row = mysql_fetch_array($result)) {
			if ($row['value'] != "") {
				define($row['name'], $row['value']);
			}
		}
	}
}

//Get all users under the current admin
$q = 'SELECT * FROM users WHERE parent = "' . $session->user_db_id . '" ORDER BY `name`';
$result = mysql_query($q);
if (is_resource($result)) {
	while ($row = mysql_fetch_array($result)) {
	$allowed_users[] = $row['ID'];
	}
} 
$q = 'SELECT * FROM pages WHERE ID = "' . mysql_real_escape_string($_REQUEST['activepage']) . '"';
$result = mysql_query($q);
while ($row = mysql_fetch_array($result)) {
	$page_name = $row['Name'];
	$ppage_path = $row['Path'];
	$page_domain = $row['Domain'];
	$custom_css = $row['CustomCSS'];
	$inline_editor = $row['InlineEditor'];
}
$q = 'SELECT * FROM domains WHERE ID = "' . $page_domain . '"';
$result = mysql_query($q);
while ($row = mysql_fetch_array($result)) { 
	$inline_editor_domain = $row['InlineEditor'];
}

if (isset($_POST['upd'])) {
	$x = 0;
	if ($_REQUEST['page_name'] != '') {
		$q = 'UPDATE pages set InlineEditor = "' . mysql_real_escape_string($_REQUEST['InlineEditor']) . '", CustomCSS = "' . mysql_real_escape_string($_REQUEST['custom_css']) . '", Name = "' . mysql_real_escape_string($_REQUEST['page_name']) . '" WHERE ID = "' . mysql_real_escape_string($_REQUEST['activepage']) . '"';
		$result = mysql_query($q);
	}
	while ($x < count($_POST['userid'])){
		//Check if user is selected
		if ($_POST['user'][$x] == 'on') {
			//Yes, they are selected.
			//Add permission
			if (!add_permission_page($_REQUEST['activepage'], $_REQUEST['userid'][$x])) {
				echo PROBLEM_ADDING_PERMISSION . '<br>';
			}				
			
		} else {
			//No, not selected.
			if (!remove_permission_page($_REQUEST['activepage'], $_POST['userid'][$x])) {
				//There was a problem, but that is OK here, so we do nothing.
				//They may not have had the permission in the first place.
			}
					
		}
		$x = $x + 1;
	}
	echo "<script type=\"text/javascript\">parent.domainupdate('" . $page_domain . "', '" . ENABLE_IMAGE_MANAGER . "', '" . ENABLE_LINK_MANAGER . "', '" . ENABLE_MEDIA_MANAGER . "', '" . ENABLE_INLINE_EDITOR . "');
	parent.$.colorbox.close()</script>";
	die;
}
if ($SkipForm != 1) {
	echo "<h1>". PAGE_SETTINGS_TEXT . "</h1>";
	echo "<h2>" . $ppage_path . "</h2>";
	echo "<div class=\"form_main\"><form name=\"test\" id=\"permissionform\" method=\"post\">";
	echo "<div class=\"form_a\"><div class=\"form_left\">" . PAGE_NAME_TEXT . ":</div><div class=\"form_right\"><input type=\"text\" name=\"page_name\" value=\"" . $page_name . "\"></div></div>";
	echo "<div class=\"form_a\"><div class=\"form_left\">" . CUSTOM_CSS_TEXT . ":</div><div class=\"form_right\"><input type=\"text\" name=\"custom_css\" value=\"" . $custom_css . "\"></div></div>";
	
	if ($inline_editor_domain == "on" & ENABLE_INLINE_EDITOR == "on") {
		echo "<div class=\"form_a\"><div class=\"form_left\">" . ENABLE_INLINE_EDITOR_TEXT . ":</div><div class=\"form_right\"><input type=\"checkbox\" name=\"InlineEditor\" ";
		if ($inline_editor == "on") {
			echo "checked";
		}
		echo "></div></div>";
	}
	echo "<div class=\"form_a\"><div class=\"form_left\"></div><div class=\"form_right\"><h2>" . ALLOWED_EDITORS_TEXT . "</h2></div></div>";
	$x = 0;
	while ($x < count($allowed_users)){
		$q = "SELECT * FROM permissions WHERE UserID = \"" . $allowed_users[$x] . "\" AND Type = \"Page\" AND Permission = \"" . mysql_real_escape_string($_REQUEST["activepage"]) . "\"";
	
	$result = mysql_query($q);
		while ($row = mysql_fetch_array($result)) {
			$current_editor[$allowed_users[$x]] = 1;
		}
		echo "<div class=\"form_a\"><div class=\"form_left\"><input type=\"checkbox\" ";
		if ($current_editor[$allowed_users[$x]] == 1) {
			echo "checked ";
		}
		echo "id=\"user[" . $x . "]\" name=\"user[" . $x . "]\"> ";
		$q = "SELECT * FROM users WHERE ID = \"" . $allowed_users[$x] . "\"";
		$result = mysql_query($q);
		while ($row = mysql_fetch_array($result)) {
			echo "</div><div class=\"form_right\">" . $row["name"];
		}
		echo "<input type=\"hidden\" id=\"userid[" . $x . "]\" name=\"userid[" . $x . "]\" value=\"" . $allowed_users[$x] . "\">";
		echo "</div></div>";
		$x = $x + 1;
	}
	echo "<div class=\"form_a\"><div class=\"form_left\"></div><div class=\"form_right\"><a href=\"\" onclick=\"document.test.submit(); return false\" class=\"btn blue\"><i></i><span><span></span><i></i>" .SAVE_SETTINGS_TEXT . "</span></a><input style=\"visibility:hidden\" type=\"submit\"\"><br><br>";
	echo "<input type=\"hidden\" id=page name=\"page\" value=\"p1\">";
	echo "<input type=\"hidden\" id=upd name=\"upd\" value=\"1\">";
	echo "<input type=\"hidden\" id=\"activepage\" name=\"activepage\" value=\"" . $_REQUEST["activepage"] . "\"></div></div>";
	echo "<br><br></form></div>";
}
?>
</div>
</div>