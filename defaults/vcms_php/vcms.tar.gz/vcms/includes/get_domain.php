<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# get_domain.php - Draws the box used on main.php for a domain
# Accepts $_REQUEST["domain"] and $_REQUEST["update"] and $_REQUEST["count"]
# update = 1 is expected for AJAX calls after the first draw, to not re-draw the outer DIV.
if ($_REQUEST["update"] == "1") {
	require('config.php');
	include("languages/" . LANGUAGE_FILE . ".php");
	include("session.php");
	include("v-cms.php");
	mysql_connect(DB_SERVER, DB_USER, DB_PASS);
	MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
	if(!$session->logged_in){
		die;
	}
}
if ($_REQUEST["enableimg"] == "on") {
	define("ENABLE_IMAGE_MANAGER", "on");
}
if ($_REQUEST["enablelink"] == "on") {
	define("ENABLE_LINK_MANAGER", "on");
}
if ($_REQUEST["enablemedia"] == "on") {
	define("ENABLE_MEDIA_MANAGER", "on");
}
if ($_REQUEST["InlineEditor"] == "on") {
	define("ENABLE_INLINE_EDITOR", "on");
}
// SQL Injection prevention
$_REQUEST["domain"] = mysql_real_escape_string($_REQUEST["domain"]);

// Security check -- does user have permissions on this domain?
if (!domain_permission_check($_REQUEST["domain"])) {
	die;
}
$q = "SELECT * FROM domains WHERE ID = \"" . $_REQUEST["domain"] . "\"";
$result3 = mysql_query($q);
$domaingood = 0;
while ($row = mysql_fetch_array($result3)){
	$this_page_id = $row["ID"];
	$domaingood = 1;
	$inline_editor_domain = $row["InlineEditor"];
	echo "<div style=\"margin-top:10px; padding: 5px;  border: 1px solid;\" class=\"dragbox\" id=\"item" . $row["ID"] . "\">";
	echo "<div style=\"position: relative; float:right;\" >";
	if ($session->isAdmin()) {
	 echo "<a href=\"?page=e1&amp;popup=1&amp;domainedit=" . $row["ID"] . "\" class=\"site_edit_lightbox btn blue\"><i></i><span><span></span><i></i>" . EDIT_TEXT . "</span></a>";
	}
	if (ENABLE_MEDIA_MANAGER == "on") {
		echo "<a href=\"?page=m2&amp;popup=1&amp;domain=" . $row["ID"] . "\"class=\"image_manager_lightbox btn blue\"><i></i><span><span></span><i></i><img src=\"images/media_icon.png\" height=\"15\" width=\"15\" border=\"0\" title=\"" . MEDIA_MANAGER_LINK_TEXT . "\" alt=\"" . MEDIA_MANAGER_LINK_TEXT . "\"></span></a>";
	}
	if (ENABLE_IMAGE_MANAGER == "on") {
		echo "<a href=\"?page=i1&amp;popup=1&amp;domain=" . $row["ID"] . "\"class=\"image_manager_lightbox btn blue\"><i></i><span><span></span><i></i><img src=\"images/img_icon.png\" height=\"15\" width=\"15\" border=\"0\" class=\"none\" title=\"" . IMAGE_MANAGER_LINK_TEXT . "\" alt=\"" . IMAGE_MANAGER_LINK_TEXT . "\"></span></a>";
	}
	if (ENABLE_LINK_MANAGER == "on") {
		echo "<a href=\"?page=l1&amp;popup=1&amp;domain=" . $row["ID"] . "\"class=\"image_manager_lightbox btn blue\"><i></i><span><span></span><i></i><img src=\"images/link_icon.png\" height=\"15\" width=\"15\" border=\"0\" class=\"none\" title=\"" . LINK_MANAGER_LINK_TEXT . "\" alt=\"" . LINK_MANAGER_LINK_TEXT . "\"></span></a>";
	}
	
	echo '<div style="float:right;">
		<h3><img src="images/up_down.png" alt="&uarr;&darr;"></h3></div>';
	echo "<br></div>";
		
	echo "<h2><a class=\"heading2\" href=\"#\" onClick=\"$('#collapse" . $row["ID"] . "').slideToggle('slow', function() {});return false;\">" . $row["Name"] . "<img align=\"top\" src=\"images/e_c.png\" alt=\"+/-\" border=0></a></h2>";

	echo "<div ";
	if ($_REQUEST["count"] != 1) {
		echo 'style="display:none" ';
	}
	echo 'class="dragbox-content" id="collapse' . $row["ID"] . '"><div style="padding-top:3px; border-top: 1px solid;" class="column_page' . $row["ID"] . '" id="column2_' . $row["ID"] .'">';
	// Display each page for this domain
	?>
	<script type="text/javascript">
	$(function(){
	$('.column_page<?php echo $row["ID"];?>').sortable({
		connectWith: '.column_page<?php echo $row["ID"];?>',
		handle: 'h3',
		cursor: 'move',
		placeholder: 'placeholder',
		forcePlaceholderSize: true,
		opacity: 0.4,
		stop: function(event, ui){
		sortorder="";
			$(ui.item).find('h3').click();
			$('.column_page<?php echo $row["ID"];?>').each(function(){
				var itemorder=$(this).sortable('toArray');
				var columnId=$(this).attr('id');
				sortorder+=columnId+'='+itemorder.toString()+'&';
			});
			$("#sort_update").html("<img src='images/ajax-loader.gif' alt='<?php echo LOADING_TEXT;?>'>").load("includes/page_sort_update.php?domain=<?php echo $row["ID"];?>&"+sortorder);
		}
	})
	.disableSelection();
	});
	</script>
	<?php
	$z = 0;
	$y = 0;
	$q = "SELECT permissions.type, permissions.UserID, permissions.Permission, pages.Name, pages.ID, pages.Path, pages.Domain, pages.InlineEditor
	FROM permissions
	LEFT JOIN pages ON permissions.Permission = pages.ID
	WHERE permissions.UserID = \"" . $session->user_db_id . "\"
	AND permissions.Type = \"Page\"
	AND pages.Domain = \"" . $row["ID"] . "\" ORDER BY pages.Name";
	$result2 = mysql_query($q);
	unset($pages);
	unset($page_ids);
	unset($page_domains);
	unset($page_path);
	unset($page_display);
	while ($row2 = mysql_fetch_array($result2)){
		$id = $row2["ID"];
		$pages[$id] = $row2["Name"];
		$page_ids[$id] = $row2["ID"];
		$page_ids2[$id] = $row2["ID"];
		$page_domains[$id] = $row2["Domain"];
		$domain = $row2["Domain"];
		$page_path[$id] = $row2["Path"];
		$inline_editor_page[$id] = $row2["InlineEditor"];
	}
	$q = "SELECT * from page_sort where Domain = \"" . $row["ID"] . "\" AND UserID = \"" . $session->user_db_id . "\"";
	$result = mysql_query($q);
	$pagesavedsort = "";
	while ($row3 = mysql_fetch_array($result)) {
		$pagesavedsort = $row3["Sort"];
	}
	if ($pagesavedsort == "") {
		$page_display = $page_ids;
		$page_display_name = $pages;
	} else {
		$pagesaved_sort1 = explode(",", $pagesavedsort);
		foreach($pagesaved_sort1 as $sort) {
			if ($sort != "") {
				$page_display[] = $sort;
				$x = 0;
				foreach ($page_ids as $key => $value) {
					if ($page_ids[$key] == $sort) {
						$page_ids[$key] = "";
						$page_ordering[] = $key;
					}
					$x = $x + 1;
				}
			}
		}
		foreach($page_ids as $page_display_temp) {
			if ($page_display_temp != "") {
				$page_display[] = $page_display_temp;
			}
		}
	}
	$page_counter = 0;
	if ($page_display != "") {
	foreach ($page_display as $page_show){
		$y = $y + 1;
		?>
			<script type="text/javascript">
				$(function(){
	$('.pageoptions<?php echo $page_ids2[$page_show];?>').hover(function(){ 
        mouse_is_inside=true; 
    }, function(){ 
        mouse_is_inside=false; 
    });

    $("body").mouseup(function(){ 
        if(! mouse_is_inside) $('.pageoptions<?php echo $page_ids2[$page_show]?>').slideUp('slow');
    });

});


	</script>
	<?php
		echo '<div style="height:28px; margin-bottom: 3px; border-bottom: 1px dotted;" class="dragbox_page" id="item' . $page_ids2[$page_show] . '">
		<div style="float:left;"><a href="?page=e2&amp;editfile=' . $page_ids2[$page_show] . '&amp;ftp=' . $page_domains[$page_show] . '" class="btn blue"><i></i><span><span></span><i></i>' . $pages[$page_show] . '</span></a>';
		if ($inline_editor_page[$page_show] == "on" & $inline_editor_domain == "on" & ENABLE_INLINE_EDITOR == "on") {
			echo '<a href="?page=e3&amp;popup=1&amp;editfile=' . $page_ids2[$page_show] . '&amp;ftp=' . $page_domains[$page_show] . '" class="inline_editor_lightbox btn blue"><i></i><span><span></span><i></i>' . INLINE_EDIT_TEXT . ' ' . $pages[$page_show] . '</span></a>';
		}
		$page_path[$page_show] = substr($page_path[$page_show], 1);
		echo '</div><div style="float:right;">
		
		<a href="' . $row["SiteURL"] . $page_path[$page_show] . '?' . rand(100, 50000) . '" target="_blank" class="btn blue iframe_lightbox"><i></i><span><span></span><i></i>' . VIEW_LIVE_PAGE_TEXT . '</span></a>';

		echo '<div style="float:right;">
		<h3><img src="images/up_down.png" alt="&uarr;&darr;"></h3></div>';
		if ($session->isAdmin()) {
			echo '<div class="pageoptionsarrow" style="float:right"><a onclick="$(\'.pageoptions' . $page_ids2[$page_show].'\').slideToggle(\'slow\'); return false;" href="#" class="btn blue"><i></i><span><span></span><i></i>' . PAGE_OPTIONS_TEXT . '</span></a><div class="pageoptions' . $page_ids2[$page_show] . '" style="border: 1px solid black; background-color: #fff; line-height: 1.5em; padding: 0px 5px; position: absolute; z-index: 9999; display:none;">
<a href="?page=p1&amp;popup=1&amp;activepage=' . $page_ids2[$page_show] . '" class="settings_lightbox" onclick="$(\'.pageoptions' . $page_ids2[$page_show].'\').hide();">' . PAGE_SETTINGS_TEXT . '</a><br>
<a href="?page=c2&amp;popup=1&amp;domain=' . $page_domains[$page_show] . '&amp;activepage=' . $page_ids2[$page_show] . '" class="copy_lightbox" onclick="$(\'.pageoptions' . $page_ids2[$page_show].'\').hide();">' . COPY_PAGE_TEXT . '</a><br>

<a href="#" onclick="deleteconfirm(\'' . $page_ids2[$page_show] . '\',\'2\', \''. $pages[$page_show] . '\');$(\'.pageoptions' . $page_ids2[$page_show].'\').hide();">' . DELETE_TEXT . '</a><br>
</div></div>';
}

		echo '</div></div>';
	$z = $z + 1;
	$last_site_id = $page_ids2[$page_show];
	$page_counter = $page_counter + 1;
	}
	}
	echo "</div>";
	// If admin, show other options
	if ($session->isAdmin()){
		// If no pages exist for the site, offer delete option
		if ($y == 0) {
			echo '<a href="#" onclick="deleteconfirm(\'' . $this_page_id . '\',\'1\',\'' . $row["Name"] . '\');" class="btn blue"><i></i><span><span></span><i></i>' . DELETE_TEXT . ' ' . $row["Name"] . '</span></a><br><br>';
		}
		echo '<a href="?page=a2&amp;popup=1&amp;domain=' . $this_page_id . '" class="btn blue add_page_lightbox"><i></i><span><span></span><i></i>' . ADD_PAGE_TO_TEXT . ' ' . $row["Name"] . '</span></a><br><br>';
	}
}
if ($domaingood == 1) {
	echo "</div>";
	echo "</div>";
	$domaingood = 0;
}