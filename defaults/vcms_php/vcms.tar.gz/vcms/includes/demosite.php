<script type="text/javascript">
var mins
var secs;
function cd() {
 	mins = 1 * m("<?php echo 59-date(i);?>"); // change minutes here date(i)
 	secs = 0 + s(":<?php echo 59-date(s);?>"); // change seconds here (always add an additional second to your total)
 	redo();
}
function m(obj) {
 	for(var i = 0; i < obj.length; i++) {
  		if(obj.substring(i, i + 1) == ":")
  		break;
 	}
 	return(obj.substring(0, i));
}
function s(obj) {
 	for(var i = 0; i < obj.length; i++) {
  		if(obj.substring(i, i + 1) == ":")
  		break;
 	}
 	return(obj.substring(i + 1, obj.length));
}
function dis(mins,secs) {
 	var disp;
 	if(mins <= 9) {
  		disp = " 0";
 	} else {
  		disp = " ";
 	}
 	disp += mins + ":";
 	if(secs <= 9) {
  		disp += "0" + secs;
 	} else {
  		disp += secs;
 	}
 	return(disp);
}

function redo() {
 	secs--;
 	if(secs == -1) {
  		secs = 59;
  		mins--;
 	}
 	document.cd.disp.value = dis(mins,secs); // setup additional displays here.
 	if((mins == 0) && (secs == 0)) {

 	} else {
 		cd = setTimeout("redo()",1000);
 	}
}

function init() {
  cd();
}
window.onload = init;
</script>
<div style="float:right;">
<form name="cd" action="#">
Welcome! The V-CMS Demo will be reset in:
<input id="txt" readonly="readonly" type="text" value="<?php echo date(i) - 60 . ":" . date(s)-60;?>" name="disp" size="4"><br>
<sub>The database is reset at the top of every hour.  When the reset occours,<br>the demo website and the CMS are reset.  You will also need to log in again.</sub>
</form>
</div>