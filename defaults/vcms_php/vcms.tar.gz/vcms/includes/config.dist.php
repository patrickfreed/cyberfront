<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
date_default_timezone_set('America/Chicago'); # http://www.php.net/manual/en/timezones.php
define("ENCRYPTION_SALT", "987654321SalT");   # This is the encryption salt used to store the FTP passwords in the database.
define("ENCRYPTION_PASSWORD", "PassWord123456789");	  # This is the encryption password used to store the FTP passwords in the database.
# CHANGE THESE TWO!  But DON'T FORGET THEM!  If you lose this, you will NOT be able to recover the passwords stored in your database.
# They can be any length, the longer the better, consisting of a-z, A-Z and 0-9.

define("DB_SERVER", "localhost");   # MySQL Server location info, "localhost" will usually do the trick.
define("DB_USER", "user");   # Database Username
define("DB_PASS", "password");   # Database Password
define("DB_NAME", "vcms");   # Database Name
# define("BASE_URL", "https://cms.domain.com"); # The full URL to reach V-CMS.  MUST be https:// if USE_SSL is set to "1" below.
define("USE_SSL", "1"); # If set to 1 will check for SSL if not found redirect to BASE_URL.
						# If BASE_URL is not an "https" address and USE_SSL is set to "1", this will cause an infinate redirect.
						# Since we're passing FTP passwords and such around, use of SSL is HIGHLY recommended.
define("LANGUAGE_FILE", "english"); #  includes/languages/[LANGUAGE_FILE].php
?>