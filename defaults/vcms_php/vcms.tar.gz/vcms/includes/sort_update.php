<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# includes/sort_update.php
# Updates the sorting list in the database for the current user

require('config.php');
include("languages/" . LANGUAGE_FILE . ".php");
include("session.php");
include("v-cms.php");
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
if(!$session->logged_in){
	die;
}
if ($_REQUEST["column1"] == "") {
	die;
}
$domain_sort = explode(",", mysql_real_escape_string($_REQUEST["column1"]));
foreach($domain_sort as $domain) {
	$sort_save = $sort_save . str_replace("item", "", $domain) . ",";
}
$q = "INSERT INTO domain_sort (UserID, Sort) VALUES (\"" . $session->user_db_id . "\",\"" . $sort_save . "\") ON DUPLICATE KEY UPDATE Sort=\"" . $sort_save . "\"";
$query = mysql_query($q);
echo "<font color=\"red\">" . DOMAIN_SORT_SAVED_TEXT . "</font>";
?>