<?php
$filedir = '../temp/'; // the directory for the original image
					$thumbdir = '../temp/'; // the directory for the thumbnail image
					$prefix = 'small_'; // the prefix to be added to the original name
					$maxfile = '2000000';
					$mode = '0777';			
					$userfile_name = $_FILES['Filedata']['name'];
					$userfile_tmp = $_FILES['Filedata']['tmp_name'];
					$userfile_size = $_FILES['Filedata']['size'];
					$userfile_type = $_FILES['Filedata']['type'];
					$image_counter = $image_counter + 1;
					if ($userfile_name != "") {

							//Image uploaded, process...
							$prod_img = $filedir.$userfile_name;
							move_uploaded_file($userfile_tmp, $prod_img);
							chmod ($prod_img, octdec($mode));
							if (($_POST["height"] != 0) || ($_POST["width"] != 0)){
								//Height or width found, resize image...
								if (!class_exists('Resize_Image')){
									require('resize.image.class.php');
								}
								$image = new Resize_Image;
								$image->new_width = $_POST["height"];
								$image->new_height = $_POST["width"];
								if ($image->new_width == "") { $image->new_width=0;}
								if ($image->new_height == "") { $image->new_width=0;}
								$image->image_to_resize = $prod_img; // Full Path to the file
								$image->ratio = true; // Keep Aspect Ratio?
								// Name of the new image (optional) - If it's not set a new will be added automatically
								$image->new_image_name = $prefix.$userfile_name;
								/* Path where the new image should be saved. If it's not set the script will output the image without saving it */
								$image->save_folder = $thumbdir;
								$process = $image->resize();
								if($process['result'] && $image->save_folder) {
									$prod_img_thumb = $process['new_file_path'];
									unlink($prod_img);
									rename($prod_img_thumb, $prod_img);
									//Successful!
								} else {
									//Fail
									echo ERROR_RESIZE_IMAGE_TEXT . '<br>';
								}
							}	
							if ($prod_img_thumb == "") {
								$prod_img_thumb = $prod_img;
							}
							
							$prod_img_thumb = "";
						
					}

echo "1";

?>
