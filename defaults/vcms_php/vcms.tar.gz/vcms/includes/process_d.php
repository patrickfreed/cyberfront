<div style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# File originally from Jpmaster77's login system
if (!defined('LANGUAGE_FILE')) {
	require('config.php');
	include("languages/" . LANGUAGE_FILE . ".php");
	include("session.php");
	include("v-cms.php");
	mysql_connect(DB_SERVER, DB_USER, DB_PASS);
	MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
}
//Check if configuration has been loaded
if (ENABLE_INLINE_EDITOR == 'ENABLE_INLINE_EDITOR') {
	$query = 'SELECT * FROM configuration';
	$result = mysql_query($query);
	if ($result) {
		while ($row = mysql_fetch_array($result)) {
			if ($row['value'] != "") {
				define($row['name'], $row['value']);
			}
		}
	}
}
if(!$session->isAdmin()){
	die;
}
if (isset($_REQUEST["de"])) {
	//Confirm Delete
	switch ($_REQUEST["item"]) {
		case "1":
			if (!domain_permission_check($_REQUEST["de"])) {
				die;
			}
			$table = "domains";
			$item = "domain";
			$therow = "Name";
			break;
		case "2":
			if (!page_permission_check($_REQUEST["de"])) {
				die;
			}
			$table = "pages";
			$item = "page";
			$therow = "Name";
			break;
		case "3":
			$table = "users";
			$item = "editor";
			$therow = "name";
			break;
	}
	$q = "SELECT * FROM " . $table . " WHERE ID = \"" . mysql_real_escape_string($_REQUEST["de"]) . "\"";
	$result = mysql_query($q);
	while ($row = mysql_fetch_array($result)) {
		$the_name = $row[$therow];
	}
	echo "<h2>" . DELETE_TEXT . " " . $item . "</h2><br><table><tr><td colspan=\"2\">" . DELETE_ARE_YOU_SURE_TEXT . " " . $item . ": " . $the_name . "?</td></tr><tr><td colspan=\"2\" height=\"5px\"></td></tr><tr><td>";
	echo "<h1>[<a href=\"#\" onClick=\"parent.$.colorbox.close(); return false;\">" . NO_TEXT . "</a>]</h1></td><td align=\"right\">";
	echo "[<a href=index.php?page=p2_d&amp;popup=1&amp;de2=" . $_REQUEST["de"] . "&amp;item=" . $_REQUEST["item"] . ">" . YES_TEXT . "</a>]</td></tr></table>";
	?>
	</div>
	</div>
    <?php
} else if (isset($_REQUEST["de2"])) {
	//Delete!
	switch ($_REQUEST["item"]) {
		case "1":
			$domain = $_REQUEST['de2'];
			$table = "domains";
			$item = "domain";
			$therow = "ID";
			//Check if logged in user has permission to work with this domain, if not die.
			if (!domain_permission_check($_REQUEST["de2"])) {
				die;
			}
			//Cleanup any leftover permissions
			$q = "DELETE FROM permissions WHERE Type = \"Domain\" AND Permission = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\"";
			$result = mysql_query($q);
			//Cleanup Sort Order
			$q = "SELECT * FROM domain_sort";
			$result = mysql_query($q);
			while ($row = mysql_fetch_array($result)){
				$thesort = str_replace($_REQUEST["de2"] . ",", "", $row["Sort"], $count);
				if ($count != 0) {
					$theid = $row["UserID"];
					$q2 = "UPDATE domain_sort SET Sort = \"" . mysql_real_escape_string($thesort) . "\" WHERE UserID = \"" . $theid . "\"";
					$result2 = mysql_query($q2);
				}
			}
			$q = "DELETE FROM domains WHERE ID = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\"";
			$result = mysql_query($q);
			break;
		case "2":
			$domain = page_owner($_REQUEST['de2']);
			$table = "pages";
			$item = "page";
			$therow = "ID";
			if (!page_permission_check($_REQUEST["de2"])) {
				die;
			}
			$q = "SELECT * FROM permissions WHERE Type = \"Page\" AND UserID = \"" . $session->user_db_id . "\" AND Permission = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\"";
			$result = mysql_query($q);
			if (!mysql_num_rows($result)) {
				die;
			}	
			$q = "DELETE from pages WHERE id = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\"";
			$result = mysql_query($q);
			//Cleanup any leftover permissions
			$q = "DELETE FROM permissions WHERE Type = \"Page\" AND Permission = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\"";
			$result = mysql_query($q);		
			//Cleanup Sort Order
			$q = "SELECT * FROM page_sort";
			$result = mysql_query($q);
			while ($row = mysql_fetch_array($result)){

				$thesort = str_replace($_REQUEST["de2"] . ",", "", $row["Sort"], $count);
				if ($count != 0) {
					$theid = $row["UserID"];
					$q2 = "UPDATE page_sort SET Sort = \"" . $thesort . "\" WHERE UserID = \"" . $theid . "\"";

					$result2 = mysql_query($q2);
					
				}
			}			

			break;
		case "3":
			$table = "users";
			$item = "editor";
			$therow = "ID";
			$q = "SELECT * FROM users WHERE ID = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\" AND parent = \"" . $session->user_db_id . "\"";
			$result = mysql_query($q);
			if (!mysql_num_rows($result)) {
				die;
			}
			//Cleanup any leftover permissions
			$q = "DELETE FROM permissions WHERE UserID = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\"";
			$result = mysql_query($q);
			break;
	}	
	$q = "DELETE FROM " . $table . " WHERE " . $therow . " = \"" . mysql_real_escape_string($_REQUEST["de2"]) . "\"";
	$result = mysql_query($q);
	?><script type="text/javascript">
		editorsupdate();
		domainupdate('<?php echo $domain;?>','<?php echo ENABLE_IMAGE_MANAGER;?>','<?php echo ENABLE_LINK_MANAGER;?>', '<?php echo ENABLE_MEDIA_MANAGER;?>', '<?php echo ENABLE_INLINE_EDITOR;?>');
		<?php if ($_REQUEST["item"] == "1") {
			echo "window.location.reload();";
		}?>
	</script>
<?php
}
?>