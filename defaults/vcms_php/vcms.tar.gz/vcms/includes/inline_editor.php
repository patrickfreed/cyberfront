<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# inline_editor.php - The code injected for the inline editor to work
//Security Check
if(!$session->logged_in){
	die;
}
if (!domain_permission_check($_REQUEST["ftp"])) {
	die;
}
if (!page_permission_check($_REQUEST["editfile"])) {
	die;
}
//Define the allowed classes and apend any custom classes
$class_search = "[class*=clienteditor],[class*=cushycms],[class*=editable]";
$class_options[] = "clienteditor";
$class_options[] = "cushycms";
$class_options[] = "editable";
if (defined('CUSTOM_CLASS_1')) {
	$class_search = $class_search . ",[class*=" . CUSTOM_CLASS_1 . "]";
	$class_options[] = CUSTOM_CLASS_1;
}
if (defined('CUSTOM_CLASS_2')) {
	$class_search = $class_search . ",[class*=" . CUSTOM_CLASS_2 . "]";
	$class_options[] = CUSTOM_CLASS_2;
}
foreach($class_options as $c_o) {
	$java_class_options .= $c_o . ",";
}
$java_class_options = substr($java_class_options, 0, -1);
$inline_remote_path = explode("/", $remote_file);
for ($i = 0; $i < sizeof($inline_remote_path)-1; $i++) {
	if ($inline_remote_path[$i] != "") {
		$base_path .= $inline_remote_path[$i] . "/";
	}
}

ob_start();
?>
<base href="<?php echo $ftp->site_url . $base_path;?>">
<style type="text/css">.vcms_inlineborder {
	border: 1px grey dotted;
}
.vcms_inline input{
	border: 1px black solid;
}
.vcms_inline {
	margin: 0px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 13px;
	color: #4D4D4D;
	padding: 0px;
}
.vcms_inline i{
	margin: 0px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 13px;
	color: #4D4D4D;
	padding: 0px;
}

	/* Forms */

/* Main DIV */
.form_main
{
padding: 2px;
height: auto;
width: 500px;
}

/* Left DIV */
.form_left
{
width: 150px;
margin: 0px;
padding: 0px; 
float: left;
text-align: right;
}

/* Right DIV */
.form_right
{
width: 350px;
margin: 0px;
padding: 0px; 
float: right; 
text-align: left;
}


</style>
<script type="text/javascript" src="<?php echo BASE_URL;?>/includes/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL;?>/includes/js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL;?>/includes/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL;?>/includes/tiny_mce/jquery.tinymce.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL;?>/includes/js/uploadify/swfobject.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL;?>/includes/js/uploadify/jquery.uploadify.v2.1.4.min.js"></script>
<link href="<?php echo BASE_URL;?>/includes/js/uploadify/uploadify.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
var original_text = new Array();
var saved_text = new Array();
var saved_editor1 = new Array();
var saved_class = new Array();
var saved_isimage = new Array();
var html_element = new Array();
var saved_edittitle = new Array();
var image_active = new Array();
var editable_count = 0;
var page_title = "";
var page_description = "";
var page_keywords = "";
$(document).ready(function() {
	setTimeout("load_inline_editor()", 1000);
})
function load_inline_editor() {
$("#draggable").draggable();
	
	$("<?php echo $class_search;?>").each(function(index) {
		editable_count = editable_count + 1;
		a = $(this).html();
		b = "text";
		thetitle = "";
		if ($(this).attr("alt") != '') {
			thetitle = $(this).attr("alt");
			html_type = 'alt';
		}
		if ($(this).attr("id") != '') {
			thetitle = $(this).attr("id");
			html_type = 'id';
		}
		if ($(this).attr("title") != '') {
			thetitle = $(this).attr("title");
			html_type = 'title';
		}
		if (typeof($(this).attr("src")) != "undefined") {
			b = "image";
			a = $(this).attr("src");
		}
		saved_edittitle[editable_count]=thetitle;
		// If class contains more than the "clienteditor", lets get rid the extra
		class_text = $(this).attr("class").split(" ");
		class_active = "";
		var class_options=new Array("<?php echo str_replace(",","\",\"",$java_class_options);?>");
		for (c_text in class_text) {
			for (c_options in class_options) {
				if (class_options[c_options] == class_text[c_text].substr(0, class_options[c_options].length)) {
					class_active = class_text[c_text].substr(0, class_options[c_options].length);
				}
			}
		}

		custom_editor_height = "";
		custom_editor_width = "";
		custom_editor_read_only = false;
		if (class_active != "") {
			class_actions = class_active.split("_");
			for (var c_actions in class_actions) {
				//This allows for and handles extra class info. eg: clienteditor_bla_bla2_bla3					
				custom_editor_read_only = false;
				if (c_actions.toUpperCase() == "READONLY") {
					//Make editor read only
					custom_editor_read_only = true;
				}
				c_actions = c_actions.substr(0,1);
				if (c_actions.toUpperCase() == "W") {
					//Define the custom width for the editor
					custom_editor_width = c_actions.substr(1,c_actions.length-1);	
				}
				if (c_actions.toUpperCase() == "H") {
					//Define the custom height for the editor
					custom_editor_height = c_actions.substr(1,c_actions.length-1);	
				}
			}
		}
		thetitle = "vcms_inline_editor_" + thetitle.replace(/ /g, 'vcms_vcms');
		switch (b) {
			case "text":
				$(this).addClass("vcms_inlineborder");
				pos = $(this).position();
				$('<div id="editable_icon_' + thetitle + '" style="padding:0;border:0;top:'+pos.top+';left:'+pos.left+';position:absolute;"><img src="<?php echo BASE_URL;?>/images/editable.png" border="0" style="border:0;padding:0px;margin:-4px;" onmousedown="toggle_mce(\''+thetitle+'\',\''+custom_editor_read_only+'\');"></div>').insertBefore(this);
				$('body').prepend('<script type="text/javascript">function cancel_' + thetitle +'(a){$("div.'+thetitle+'").html(original_text["'+thetitle+'"]);toggle_mce(\''+thetitle+'\',\''+custom_editor_read_only+'\');}function save_' + thetitle + '(a){saved_class["'+thetitle+'"]="'+class_active+'";saved_editor1["'+thetitle+'"]="'+html_type+'";saved_text["'+thetitle+'"]=$("div.'+thetitle+'").html();toggle_mce(\''+thetitle+'\',\''+custom_editor_read_only+'\');}<\/script>');
				$(this).html('<div class="'+thetitle+'" id="' + thetitle + '">' + $(this).html() + '</div>');
				
				break;
			default:
				
				pos = $(this).position();
				$('<div id="editable_icon_' + thetitle + '" style="top:'+pos.top+';left:'+pos.left+';position:absolute;"><script type="text/javascript">saved_class["'+thetitle+'"]="'+class_active+'";saved_editor1["'+thetitle+'"]="'+html_type+'";function cancel_' + thetitle +'(a){$("div.'+thetitle+'").html(original_text["'+thetitle+'"]);toggle_mce(\''+thetitle+'\',\''+custom_editor_read_only+'\');}function save_' + thetitle + '(a){}<\/script><img src="<?php echo BASE_URL;?>/images/editable.png" style="border:0;padding:0;margin:-4px;" onmousedown="toggle_image(\''+thetitle+'\');"></div><div id="image_edit_' + thetitle + '" style="top:'+pos.top+';left:'+pos.left+';border: 1px black solid; width:375px; height:125px; padding: 5px;background-color:#ffffff;position: absolute;display:none;"></div>').insertBefore(this);
				$(this).wrap('<div style="top:'+pos.top+';left:'+pos.left+';" class="'+thetitle+'" id="' + thetitle + '">');
				$("#"+thetitle).find("img").addClass("vcms_inlineborder");
			break;
		}
		
	});
}
function toggle_mce(divtitle, readonly){
		if (typeof($('div.'+divtitle).tinymce()) == "undefined") {
			original_text[divtitle] = $("div."+divtitle).html();
			$(function() {
				$('div.'+divtitle).tinymce({
					<?php echo $default_mce_init;?>
				});
			});			
			$("#editable_icon_" + divtitle).hide();
			$("#"+thetitle).removeClass("vcms_inlineborder");				
		} else {
			$("div." + divtitle).tinymce().remove();
			$("#editable_icon_" + divtitle).show();
			$("#"+thetitle).addClass("vcms_inlineborder");
		}
	}
function savechanges(){
	editor1_string = "";
	class_string = "";
	isimage_string = "";
	edittitle_string = "";
	editor_string = "";
	y = 0;
	for (i in saved_text) { 
		y = y + 1;
		h = i.replace('vcms_inline_editor_', '');
		j = h.replace('vcms_vcms', ' ');
		editor1_string = editor1_string + h +'vcms_;_vcms'+saved_editor1[i]+'vcms_~_vcms';
		class_string = class_string + h + 'vcms_;_vcms'+saved_class[i]+'vcms_~_vcms';
		isimage_string = isimage_string + h + 'vcms_;_vcms' + saved_isimage[i]+'vcms_~_vcms';
		edittitle_string = edittitle_string + y + 'vcms_;_vcms' + h+'vcms_~_vcms';
		editor_string = editor_string + h + 'vcms_;_vcms' + saved_text[i]+'vcms_~_vcms';
	};
	$.post("<?php echo BASE_URL;?>/index.php", { popup : "1", page_title: page_title, page_keywords: page_keywords, page_description: page_description, editor1_inline: editor1_string, class_inline: class_string, isimage_inline: isimage_string,edittitle_inline: edittitle_string,editor_inline: editor_string, page: "e3", rafile: "<?php echo $random_id;?>", editfile: "<?php echo $_REQUEST["editfile"];?>", ftp: "<?php echo $_REQUEST["ftp"]?>", edittime: "yes" },function(data){$("body").html(data);});
}
function toggle_image(divtitle){
	if (image_active[divtitle] != 1) {
		img_string = "";
		original_text[divtitle] = $("#"+divtitle).find("img").attr("src");
		display_width = $("#"+divtitle).find("img").attr("width");
		display_height = $("#"+divtitle).find("img").attr("height");
		if (display_width == "undefined") { display_width = "0"; }
		if (display_height == "undefined") { display_height = "0"; }
		if ((display_height != "0") || (display_width != "0")) {
			img_string = "&nbsp;<i class=\"vcms_inline\"><?php echo IMAGE_RESIZE_NOTICE_TEXT;?>: ";
			if (display_width != "0") {
				img_string = img_string + "<?php echo WIDTH_TEXT;?>: " + display_width + " ";
			}
			if (display_height != "0") {
				img_string = img_string + "<?php echo HEIGHT_TEXT;?>: " + display_height;
			}
			img_string = img_string + "</i><br>";
		}
		img_form = "<br>" + img_string + "<div id=\"fileQueue_" + divtitle + "\"></div><form id=\"vcms_upload_" + divtitle + "\" name=\"vcms_upload_" + divtitle + "\" method=\"POST\" enctype=\"multipart/form-data\"><?php echo IMAGE_TEXT;?>: <input type=\"hidden\" name=\"width\" value=\"" + display_width + "\"><input type=\"hidden\" name=\"height\" value=\""+display_height+"\"><input type=\"file\" name=\"image\"><input type=\"hidden\" name=\"height["+divtitle+"]\" value=\"" +display_height+"\"><input type=\"hidden\" name=\"width["+divtitle+"]\" value=\""+display_width+"\"><input type=\"hidden\" name=\"isimage["+divtitle+"]\" value=\"1\"></form>";
		$("#image_edit_" + divtitle).html('<div style="position:absolute;margin:-20px;"><a href="" onclick="toggle_image(\''+divtitle+'\');return false;"><img src="<?php echo BASE_URL;?>/images/close.png" border="0"></a></div>' + img_form);
		$("#image_edit_" + divtitle).show('slow');
		image_active[divtitle] = 1;
		button_text = '<?php echo BROWSE_TEXT;?>',
		button_width = button_text.length;
		$("#vcms_upload_" + divtitle).uploadify({
			'uploader'       : '<?php echo BASE_URL;?>/includes/js/uploadify/uploadify.swf',
			'script'         : '<?php echo BASE_URL;?>/includes/inline_image_upload.php',
			'cancelImg'      : '<?php echo BASE_URL;?>/includes/js/uploadify/cancel.png',
			'folder'         : '/temp',
			'queueID'        : 'fileQueue_' + divtitle,
			'auto'           : true,
			'multi'          : false,
			'fileDesc'		 : 'Image Files',
			'fileExt'		 : '*.bmp,*.gif;*.jpg;*.jpeg,*png',
			'buttonText'	 : button_text,
			//'width'			 : (button_width * 10)+55,
			'scriptData'	 : {'width':display_width, 'height':display_height},
			'onComplete'	 : function(event, queueID, fileObj, reposnse, data) {image_upload_done(divtitle, fileObj.filePath, reposnse, data);}
		});
	} else {
		$("img." + divtitle).html(original_text[divtitle]);
		$("#image_edit_" + divtitle).hide('slow');
		image_active[divtitle] = 0;
	}
}	 
function image_upload_done(divtitle, filePath,reposnse, data){
	$("#"+divtitle).find("img").attr("src", "<?php echo BASE_URL;?>" + filePath);
	saved_isimage[divtitle]="1";
	saved_text[divtitle]=filePath;
	toggle_image(divtitle);
}
function save_title_description(){
page_title=$('#title').val();
page_description=$('#description').val();
page_keywords=$('#keywords').val();
update_title(page_title);
$('#title_editor').slideToggle('slow');
}
 
</script>

<?php
$out = ob_get_contents();
ob_end_clean();
