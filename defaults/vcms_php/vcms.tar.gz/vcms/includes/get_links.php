<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# get_images.php - Gets the images for a domain
require('config.php');
include("languages/" . LANGUAGE_FILE . ".php");
include("session.php");
include("v-cms.php");
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
if(!$session->logged_in){
	die;
}
//SQL Injection prevention
$_REQUEST["domain"] = mysql_real_escape_string($_REQUEST["domain"]);
//Security check -- does user have permissions on this domain?
if (!domain_permission_check($_REQUEST["domain"])) {
	die;
}
//Get domain login info
$ftp = new VCMS_FTP;
$ftp->GetDomainInfo($_REQUEST["domain"]);

$ftp->Open();
$_REQUEST["path"] = "/" . $ftp->link_path;
$current_path = $_REQUEST["path"] . "/";
//If we cannot chage to the image directory, create one
$ftp->CheckDirectory($ftp->path . "/" . $current_path);
$paths = explode("/", $_REQUEST["path"]);
$ftp->GetFileList("/" . $ftp->path . $current_path);

$js = 'var tinyMCELinkList = new Array(';
if (!empty($ftp->filelist)) {
		foreach ($ftp->filelist as $filename => $fileinfo) {

		$js .= '["'.$filename.'", "'. $ftp->site_url . $ftp->link_path . "/" . $filename . '"],';
		}
	}
$js = rtrim($js, ',').');';
echo $js;