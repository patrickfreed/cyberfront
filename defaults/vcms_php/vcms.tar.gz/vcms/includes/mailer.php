<?php 
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# File originally from Jpmaster77's login system

class Mailer
{
   /**
    * sendWelcome - Sends a welcome message to the newly
    * registered user, also supplying the username and
    * password.
    */
   function sendWelcome($user, $email, $pass, $userid){
      $from = "From: \"".SITE_NAME."\" <".EMAIL_FROM_ADDR.">";
      $subject = EMAIL_WELCOME_SUBJECT_TEXT;
      $body = $user.",\n\n"
             .EMAIL_WELCOME_BODY_1 . "\n\n"
             .USER_NAME_TEXT .": ".$user."\n"
             .PASSWORD_TEXT . ": ".$pass."\n\n"
             .EMAIL_WELCOME_BODY_2 . "\n\n"
             .BASE_URL . "/valid.php?qs1=".$user."&qs2=".$userid."\n\n"
             .EMAIL_WELCOME_BODY_3 . "\n\n"
             ."";
      return mail($email,$subject,$body,$from);
   }
   
   /**
    * sendConfirmation - Sends a confirmation to users
    * who click a "Send confirmation" button.  This
    * only needs to be used if the EMAIL_WELCOME constant
    * is changed to true and the user's 'valid' field is 0
    */
   function sendConfirmation($user, $userid, $email){
       $from = "From: \"".SITE_NAME."\" <".EMAIL_FROM_ADDR.">";
       $subject = EMAIL_CONFIRMATION_SUBJECT_TEXT;
       $body = $user.",\n\n"
               .EMAIL_CONFIRMATION_BODY_1 . "\n\n"
               .BASE_URL . "/valid.php?qs1=".$user."&amp;qs2=".$userid."\n\n"
               .EMAIL_CONFIRMATION_BODY_2 . "\n\n";
               
      return mail($email,$subject,$body,$from);
   }
   
   
   /**
    * sendNewPass - Sends the newly generated password
    * to the user's email address that was specified at
    * sign-up.
    */
   function sendNewPass($user, $email, $pass){
      $from = "From: \"".SITE_NAME."\" <".EMAIL_FROM_ADDR.">";
      $subject = EMAIL_NEW_PASSWORD_SUBJECT_TEXT;
      $body = $user.",\n\n"
             .EMAIL_NEW_PASSWORD_BODY_1 . "\n\n"
             .USER_NAME_TEXT . ": ".$user."\n"
             .PASSWORD_TEXT . ": ".$pass."\n\n"
             .EMAIL_NEW_PASSWORD_BODY_2 . "\n\n";
             
      return mail($email,$subject,$body,$from);
   }
};

/* Initialize mailer object */
$mailer = new Mailer;
 
?>
