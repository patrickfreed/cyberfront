<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# get_editors.php - Draws the information in the editors box used on main.php
# Accepts $_REQUEST["update"]
# update = 1 is expected for AJAX calls after the first draw.
if ($_REQUEST["update"] == "1") {
	require('config.php');
	include("languages/" . LANGUAGE_FILE . ".php");
	include("session.php");
	include("v-cms.php");
	mysql_connect(DB_SERVER, DB_USER, DB_PASS);
	MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
}
if(!$session->isAdmin()){
	die;
}
unset($allowed_users);
//Get all users under the current admin
$q = "SELECT * FROM users WHERE parent = \"" . $session->user_db_id . "\" ORDER BY `name` ASC";
$result = mysql_query($q);
if (is_resource($result)) {
	while ($row = mysql_fetch_array($result)) {
	$allowed_users[] = $row["ID"];
	$allowed_users_names[] = $row["name"];
	}
} 
$editor_count = 0;
echo "<div id=\"editors_div\" style=\"padding-top:3px; border-top: 1px solid;display:none;\">";
while ($editor_count < count($allowed_users)){
	echo '<div style="height:28px; margin-bottom: 3px; border-bottom: 1px dotted;"><a href="?page=u2&amp;popup=1&amp;check=' . $allowed_users[$editor_count] . '" class="btn blue editor_permissions_lightbox"><i></i><span><span></span><i></i>' . $allowed_users_names[$editor_count] . '</span></a><div style="float:right;"><a href="#" onclick="deleteconfirm(\'' . $allowed_users[$editor_count] . '\',\'3\',\'' . $allowed_users_names[$editor_count] . '\');" class="btn blue"><i></i><span><span></span><i></i>' . DELETE_TEXT . '</span></a><br></div></div>';
	$editor_count = $editor_count + 1;
}
if ($editor_count == 0) {
	echo  NO_EDITORS_FOUND_TEXT . '<br>';
}
echo '<a href="?page=r1&amp;popup=1" class="btn blue add_editor_lightbox"><i></i><span><span></span><i></i>' . ADD_NEW_EDITOR_TEXT . '</span></a><br><br>';
echo "</div>";