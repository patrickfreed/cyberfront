<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# includes/chose_path.php - Gets the pathlist via FTP for selecting the document root
require('config.php');
include("languages/" . LANGUAGE_FILE . ".php");
include("session.php");
include("v-cms.php");
if(!$session->isAdmin()){
	die;
}
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
if ($_REQUEST["selectedfile"] == "") {
	$ftp_user_name = $_REQUEST["User"];
	$ftp_user_pass = $_REQUEST["Password"];
	$ftp_server = $_REQUEST["ftp"];
	$ftp_port = $_REQUEST["port"];
	$ftp_type = $_REQUEST["FTPType"];
	if ($ftp_user_pass == "") {
		$q = "SELECT Password FROM domains WHERE ftp = \"" . mysql_real_escape_string($_REQUEST["ftp"]) . "\"";
		$result = mysql_query($q);
		while ($row = mysql_fetch_array($result)){
			$ftp_user_pass = $row["Password"];
			$ftp_user_pass = decrypt_password($ftp_user_pass);
		}
	}
	$ftp = new VCMS_FTP;
	$ftp->user_name = $ftp_user_name;
	$ftp->user_pass = $ftp_user_pass;
	$ftp->server = $ftp_server;
	$ftp->port = $ftp_port;
	$ftp->type = $ftp_type;
	$ftp->open();

	$back_dir = explode("/", $_REQUEST["path"]);
	$a = 0;
	$theback = "";
	while ($a < count($back_dir)-1) {
		if ($back_dir[$a] != "") {
		$theback = $theback . "/" . $back_dir[$a];
		}
		$a++;
	}

if ($_REQUEST["path"] == "") {
	echo "[<a href=\"#\" onClick=\"document.getElementById('choose_path').innerHTML=' ';\">" . CLOSE_FTP_TEXT . "]</a><br>";
}
	echo "<ul class=\"jqueryFileTree\" style=\"display: none;\">";
	
	
	$ftp->GetFileList($_REQUEST["path"]);
	if (!empty($ftp->dirlist)) {
		foreach ($ftp->dirlist as $dirname => $dirinfo) {
			$dirname_update = $dirname;
			if (substr($dirname, 0, 1) == "/") {
				$dirname_update = substr($dirname_update, 1);
			}
			echo "<li class=\"directory collapsed\"><a href=\"#\" rel=\"" . htmlentities($_REQUEST["path"] . $dirname) . "/\">" . htmlentities($dirname_update) . "</a></li>";
		}
	}
	
	echo "</ul>";
}




?>