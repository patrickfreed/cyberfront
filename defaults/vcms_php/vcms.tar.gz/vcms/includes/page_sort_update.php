<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# includes/sort_update.php
# Updates the sorting list in the database for the current user

require('config.php');
include("languages/" . LANGUAGE_FILE . ".php");
include("session.php");
include("v-cms.php");
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
if(!$session->logged_in){
	die;
}
$the_column = "column2_" . $_REQUEST["domain"];
if ($_REQUEST[$the_column] == "") {
	die;
}
$domain_sort = explode(",", mysql_real_escape_string($_REQUEST[$the_column]));
foreach($domain_sort as $domain) {
	if ($domain != "") {
		$sort_save = $sort_save . str_replace("item", "", $domain) . ",";
	}
}
$q = "SELECT * from page_sort WHERE UserID = '" . $session->user_db_id . "' AND Domain = '" . mysql_real_escape_string($_REQUEST["domain"]) . "'";
$result = mysql_query($q);
$test = "";
if (is_resource($result)) {
	while ($row = mysql_fetch_array($result)) {
		$test = $row["UserID"];
	}
}
if ($test != "") {
	//Existing sort found, update
	$q = "UPDATE page_sort SET Sort = '" . $sort_save . "' WHERE UserID = '" . $session->user_db_id . "' AND Domain = '" . mysql_real_escape_string($_REQUEST["domain"]) . "'";
} else {
	$q = "INSERT INTO page_sort (UserID, Domain, Sort) VALUES (\"" . $session->user_db_id . "\",\"" . mysql_real_escape_string($_REQUEST["domain"]) . "\",\"" . $sort_save . "\")";
}
$query = mysql_query($q);
echo "<font color=\"red\">" . PAGE_SORT_SAVED_TEXT . "</font>";
?>