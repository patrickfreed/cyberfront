<?php
//Installer
define('CREATE_TABLE_DATABASE_ERROR_TEXT', 'There was a problem creating the database tables.');
define('CREATE_TABLE_DATABASE_SUCCESS_TEXT', 'Successfully created the database tables.');
define('ATTEMPT_CHMOD', 'Attempting to set the correct file permissions...');
define('CHMOD_FAILED_TEXT', '<div style="text-color:red;">FAILED!</div>  Please manually set this directory to 0777.');
define('CHMOD_ERROR_TEXT', 'There was an error changing the permissions for the temp directories!  You MUST ensure all directories have the correct permission settings!');
define('INSTALL_HEADER_TEXT', 'Installation');
define('INSTALL_TEXT', 'Install');
define('FIX_ADMIN_TEXT', 'Fix Admin');
define('INSTALL_WELCOME_TEXT', 'Welcome to V-CMS v' . VCMS_VERSION . '!<br><br>Before installing be sure you\'ve configured <b>includes/config.php</b> correctly.  Although you must have done something right, you\'ve made it this far.<br><br><hr><br>This installer will setup the database and create the admin account.  Click the ' . INSTALL_TEXT . ' button below to start!');
define('FIX_ADMIN_WELCOME_TEXT', 'If the system fails to mail you a confirmation e-mail, come back to the installer (<b>/install</b>) and use the ' . FIX_ADMIN_TEXT . ' button below.  This will activate the admin account for you.');
define('INSTALL_PAGE_RIGHT_TEXT', '<p>If you have trouble installing V-CMS, please visit our Website at <a href="http://v-cms.org" target="_blank">v-cms.org</a>!</p><p>Please post any issues you may have on the forum at <a href="http://forum.v-cms.org" target="_blank">forum.v-cms.org</a></p>');
define('FIX_ADMIN_HEADER_TEXT', 'Validate Admin Account');
define('FIX_ADMIN_FIXED_TEXT', 'You should now be able to <a href="index.php">login</a>.  If the login still does not work, edit the database table "users" and set "valid" = 1. (UPDATE users SET valid = \'1\' WHERE ID = \'admin\')');

//Upgrader
define('UPGRADE_HEADER_TEXT', 'V-CMS Upgrade');
define('UPGRADE_DATABASE_SUCCESS_TEXT', 'Upgrade successful!');
define('UPGRADE_PAGE_RIGHT_TEXT', '');
define('NO_UPGRADE_NEEDED_TEXT', 'No upgrade required.');
define('UPGRADE_DATABASE_ERROR_TEXT', 'Database error');
define('UPGRADE_DATABASE_ERRORS_FOUND_TEXT', 'There was a problem running the upgrade queries');


//General - Used in several places
define('NAME_TEXT', 'Name');
define('ERRORS_FOUND_TEXT', 'error(s) found');
define('EMAIL_TEXT', 'E-Mail');
define('SAVE_SETTINGS_TEXT', 'Save Settings');
define('KEY_GENERATION_FAILED_TEXT', 'Failed to generate the secret key.');
define('ENCRYPTION_FAILED_TEXT', 'Password encryption failed.');
define('DECRYPTION_FAILED_TEXT', 'Password decryption failed.');
define('LOADING_TEXT', 'Loading...');
define('INSTALL_DIRECTORY_EXISTS_TEXT', '<span style="color: red;">WARNING:</span> The install directory still exists.  Remove the /install directory to secure your installation!');
define('ENABLE_INLINE_EDITOR_TEXT', 'Enable Inline Editor');

//Header
define('JAVASCRIPT_ERROR_TEXT', '<strong>V-CMS requires JavaScript to run</strong>.  This site will not function correctly without Javascript enabled.');
define('HOME_MENU_TEXT', 'HOME');
define('MY_ACCOUNT_MENU_TEXT', 'MY ACCOUNT');
define('CONFIGURATION_MENU_TEXT', 'CONFIGURATION');
define('LOGOUT_MENU_TEXT', 'LOGOUT');
define('NEW_PASSWORD_GENERATED_TEXT', 'New Password Generated');
define('NEW_PASSWORD_SUCCESSFUL_TEXT', 'Your new password has been generated and sent to the email associated with your account.');
define('NEW_PASSWORD_FAILURE_TEXT', 'New Password Failure');
define('NEW_PASSWORD_ERROR_TEXT', 'There was an error sending you the email with the new password so your password has not been changed.');
define('REGISTERED_TEXT', 'Registered!');
define('THANK_YOU_TEXT', 'New account created:');
define('CONFIRMATION_SENT_OK_TEXT', 'A confirmation email should be arriving shortly.');
define('NO_CONFIRMATION_SENT_TEXT', 'your information has been added to the database!');
define('REGISTRATION_FAILED_TEXT', 'Registration Failed');
define('REGISTRATION_FAILED_NOTICE_TEXT', 'We\'re sorry, an error has occurred and your registration could not be completed.');
define('TEMP_DIR_ERROR', '<span style="color:red;">Permission issue:</span> Please check the permissions of the directory:');
define('HELP_MENU_TEXT', 'HELP');
define('CURL_UPGRADE_CHECK_ERROR', 'CURL is not available on this machine.  Please enable CURL to allow V-CMS to check for updates.');
define('UPGRADE_AVAILABLE_TEXT', 'A newer version of V-CMS is available for download.  Please use the link below to download the latest version.');
define('UPDATE_OK_TEXT', 'You are using the most current version of V-CMS.');
define('EDITOR_SAVE_ERROR_TEXT', 'Error(s) while saving');
define('ENCRYPTION_SALT_ERROR_TEXT', 'Please change your encryption salt setting in the configuration.');
define('ENCRYPTION_PASSWORD_ERROR_TEXT', 'Please change your encryption password setting in the configuration.');
define('CRITICAL_ERROR_TEXT', 'Critical Error');
define('CRITICAL_ERROR_STOP_TEXT', 'Please contact the system administrator to correct the above error.');
define('IE_BROWSER_WARNING_TEXT', 'This CMS operates very slowly in Intenet Explorer.  We suggest using Mozilla Firefox.  For more information and to download Mozilla Firefox, click here.');

//Copy Page Text
define('COPY_PAGE_HEADER_TEXT','Copy Page');

//Welcome Page Text
define('SITES_PAGES_TEXT', 'Sites & Pages');
define('CLICKY_NOTICE_TEXT', 'Click on the title of the site to view the pages available to edit.  To change the sort order of the domains or pages in a domain, drag the up/down arrow next to the item you wish to move.');
define('DOMAIN_SORT_SAVED_TEXT', 'Domain Sort Order - Saved');
define('PAGE_SORT_SAVED_TEXT', 'Page Sort Order - Saved');
define('EDIT_TEXT', 'Edit');
define('IMAGE_MANAGER_LINK_TEXT', 'Image Manager');
define('MEDIA_MANAGER_LINK_TEXT', 'Media Manager');
define('EDITORS_TEXT', 'Editors');
define('CONFIGURE_TEXT', 'Configure');
define('PREVIEW_TEXT', 'Preview Changes');
define('VIEW_LIVE_PAGE_TEXT', 'View');
define('PAGE_OPTIONS_TEXT', 'Options');
define('COPY_PAGE_TEXT','Copy');
define('SETTINGS_TEXT', 'Settings');
define('DELETE_TEXT', 'Delete');
define('ADD_PAGE_TO_TEXT', 'Add Page To');
define('ADD_NEW_SITE_TEXT', 'Add New Site');
define('PAGE_SETTINGS_TEXT', 'Settings');
define('PERMISSIONS_TEXT', 'Permissions');
define('NO_PAGES_FOUND_TEXT', 'No Pages Found');
define('NO_EDITORS_FOUND_TEXT', 'No Editors Found');
define('ADD_NEW_EDITOR_TEXT', 'Add New Editor');
define('INLINE_EDIT_TEXT', 'Inline Edit');
define('WELCOME_TEXT', 'Welcome!');
define('WELCOME_PAGE_RIGHT_EDITOR_TEXT', '<p>To begin editing, click the name of the page you wish to edit.</p><p>If you need to add images, links or media to the WYSIWYG editor, use the manager icons to the right of the site\'s name.  These icons are also avaialbe on the editor page.</p><p>You can view the page exactly as it is now by clicking on the "Live" button.</p><br><br>');
define('WELCOME_PAGE_RIGHT_ADMIN_TEXT', '<p>To start using your new CMS, click the "' . ADD_NEW_SITE_TEXT . '" button under "' . SITES_PAGES_TEXT . '".  After setting up your new site and adding your first page you can then create a new Editor by clicking the "' . ADD_NEW_EDITOR_TEXT . '" button under "' . EDITORS_TEXT . '"</p>
	<p>Once you are all set up, you can add more pages to a site by clicking the "' . ADD_PAGE_TO_TEXT . '" button under the site\'s list of pages.</p>
	<p>To give view what editors have access to a page, click the "' . PERMISSIONS_TEXT . '" button next to the page name you wish to view.</p>
	<p>To view what pages editors have access to, click "' . EDIT_TEXT . '" button next to the name of the editor you wish to view under "' . EDITORS_TEXT . '"</p>
	<p>To remove an Editor, Page or Site, click the "' . DELETE_TEXT . '" button next to the name of the item you wish to remove.  Note: Sites cannot be deleted until all pages for that site are first deleted.</p>');

//My Account
//define('EDIT_ACCOUNT_TEXT', 'Edit Account');
//define('USER_ACCOUNT_EDIT_RIGHT_TEXT', '<p>This is for notes for this page.</p><ul><li>Placeholder</li></ul>');

//Page Settings Page
define('ALLOWED_EDITORS_TEXT', 'Allowed Editors');
define('CUSTOM_CSS_TEXT', 'Custom CSS URL');
define('PAGE_NAME_TEXT', 'Page Name');

//User Edit Page
define('USER_ACCOUNT_EDIT_TEXT', 'User Account Edit');
define('CURRENT_PASSWORD_TEXT', 'Current Password');
define('NEW_PASSWORD_TEXT', 'New Password');
define('MY_ACCOUNT_TEXT', 'My Account');
define('USER_EDIT_PAGE_RIGHT_TEXT', '<p>Change your Name, Password or E-Mail address on file.</p><p>You only need to enter the Current Password when also entering a New Password.</p>');

//Login Page
define('LOGIN_TEXT', 'Login');
define('USER_NAME_TEXT', 'User Name');
define('PASSWORD_TEXT', 'Password');
define('REMEMBER_NEXT_TIME_TEXT', 'Remember me next time');
define('SIGN_UP_TEXT', 'Sign Up!');
define('SEND_CONFIRMATION_LINK_TEXT', 'Resend Confirmation E-Mail');
define('FORGOT_PASSWORD_TEXT', 'Forgot Password');
define('SEND_CONFIRMATION_EMAIL_TEXT', 'Send Confirmation E-Mail');
define('SEND_CONFIRMATION_EMAIL_PAGE_RIGHT_TEXT', '<p>If you did not recieve your confirmation e-mail, use this form and the confirmation e-mail will be re-sent to the e-mail address on file for your account.</p><p>If you no longer have access to the e-mail address on file, please contact the system administrator for assistance.</p>');
define('LOGIN_PAGE_RIGHT_TEXT', '<p>Welcome!  To start, please login using the form to the left.</p><p>If you have forgotten your password, use the "' . FORGOT_PASSWORD_TEXT . '" button below the login form.</p><p>If you did not receive your confirmation email, please click the "' . SEND_CONFIRMATION_EMAIL_TEXT . '" button below the form.</p>');
define('FORGOT_PASSWORD_BODY_TEXT', 'A new password will be generated for you and sent to the email address associated with your account, all you have to do is enter your username.');
define('GET_NEW_PASSWORD_TEXT', 'Get New Password');

//Configuration
$configuration_setting['SITE_NAME'] = 'Site Name';
$configuration_setting['TAGLINE'] = 'Tagline';
$configuration_setting['EMAIL_FROM_ADDR'] = 'E-Mail From Address';
$configuration_setting['CUSTOM_CLASS_1'] = 'Custom Class #1';
$configuration_setting['CUSTOM_CLASS_2'] = 'Custom Class #2';
$configuration_setting['LOGO_IMAGE'] = 'Logo Image';
$configuration_setting['BACKGROUND_CSS'] = 'Background CSS';
$configuration_setting['HEADER_COLOR'] = 'Header (H1, H2, etc) Color';
$configuration_setting['BUTTON_BACKGROUND'] = 'Button Background Color';
$configuration_setting['BUTTON_COLOR'] = 'Button Font Color';
$configuration_setting['BUTTON_HOVER_BACKGROUND'] = 'Button Background Color (Hover)';
$configuration_setting['BUTTON_HOVER_COLOR'] = 'Button Font Color (Hover)';
$configuration_setting['BUTTON_ACTIVE_BACKGROUND'] = 'Button Background Color (Active)';
$configuration_setting['BUTTON_ACTIVE_COLOR'] = 'Button Font Color (Active)';
$configuration_setting['CUSTOM_HELP_LINK'] = 'URL to Help';
$configuration_setting['CUSTOM_CSS'] = 'Custom CSS';
$configuration_setting['ENABLE_IMAGE_MANAGER'] = 'Enable Image Manager';
$configuration_setting['ENABLE_PUBLIC_SIGNUP'] = 'Enable Public Signup';
$configuration_setting['ENABLE_LINK_MANAGER'] = 'Enable Link Manager';
$configuration_setting['ENABLE_MEDIA_MANAGER'] = 'Enable Media Manager';
$configuration_setting['RESTRICTED_UPLOAD_TYPES'] = 'Restricted File Types';
$configuration_setting['UPDATE_CHECK'] = 'Check For V-CMS Updates';
$configuration_setting['ALLOWED_REVISIONS'] = 'Maximum Stored Revisions';
$configuration_setting['SYSTEM_CHECKS'] = 'Do System Checks';
$configuration_setting['ENABLE_INLINE_EDITOR'] = 'Enable Inline Editor';
$configuration_setting['IE_WARNING'] = 'Display IE Warning';
$configuration_setting['SUBMIT_STATS'] = 'Submit Usage Stats';
$configuration_setting['COLORBOX_STYLE'] = 'Colorbox Style';

$configuration_help['SITE_NAME'] = 'The name of your site, displayed in the header.';
$configuration_help['TAGLINE'] = 'Tagline for your site, displayed below the ' . $configuration_setting['SITE_NAME'] . '.';
$configuration_help['EMAIL_FROM_ADDR'] = 'The e-mail address system e-mails will be From.';
$configuration_help['CUSTOM_CLASS_1'] = 'Custom class for editable areas, this will be used in addition to clienteditor, cushycms, and editable.';
$configuration_help['CUSTOM_CLASS_2'] = 'Custom class for editable areas, this will be used in addition to clienteditor, cushycms, editable and ' . $configuration_setting['CUSTOM_CLASS_1'] . '.';
$configuration_help['LOGO_IMAGE'] = 'The URL to your logo.  The image will be displayed at a height of 75px. Example: <b>http://www.domain.com/logo.jpg</b>';
$configuration_help['BACKGROUND_CSS'] = 'The CSS used to render the background image for the CMS.  Leave blank for the default of: <b>url(images/img01.jpg) repeat-x left top#F5F5F5 url(images/img01.jpg) repeat-x left top</b>';
$configuration_help['HEADER_COLOR'] = 'The CSS color used for the headings.  Leave blank for the default of: <b>#AA2808</b>';
$configuration_help['BUTTON_BACKGROUND'] = 'The CSS color used for the background color of the buttons.  Leave blank for the default of: <b>#22aaee</b>';
$configuration_help['BUTTON_COLOR'] = 'The CSS color used for the font of the buttons.  Leave blank for the default of: <b>#ffffff</b>';
$configuration_help['BUTTON_HOVER_BACKGROUND'] = 'The CSS color used for the background of the buttons when the mouse is hovered over them.  Leave blank for the default of: <b>#aa0000</b>';
$configuration_help['BUTTON_HOVER_COLOR'] = 'The CSS color used for the font of the buttons when the mouse is hovered over them.  Leave blank for the default of <b>#ffffff</b>';
$configuration_help['BUTTON_ACTIVE_BACKGROUND'] = 'The CSS color used for the background of the buttons when the button is active.  Leave blank for the default of <b>#444444</b>';
$configuration_help['BUTTON_ACTIVE_COLOR'] = 'The CSS color used for the font of the buttons when the buttons are active.  Leave blank for the default of <b>#fffff</b>';
$configuration_help['CUSTOM_HELP_LINK'] = 'If you wish to create a walk-through for your users, enter the URL to the movie/PDF/webpage here.  Example: <b>http://domain.com/cmshelp</b>';
$configuration_help['CUSTOM_CSS'] = 'The location of your custom V-CMS CSS.  Leave blank to use the default of <b>css/style.css</b>.';
$configuration_help['ENABLE_IMAGE_MANAGER'] = 'Allow users access to the image manager';
$configuration_help['ENABLE_PUBLIC_SIGNUP'] = 'Activates link on home page to allow the public to signup and use this website as their CMS.';
$configuration_help['ENABLE_LINK_MANAGER'] = 'Allow users access to the link manager';
$configuration_help['ENABLE_MEDIA_MANAGER'] = 'Allow users access to the media manager';
$configuration_help['RESTRICTED_UPLOAD_TYPES'] = 'These file extensions are not allowed to be uploaded. Separate each extension with a comma. <b>Suggested:</b> php, php3, php4, php5, shtm, shtml, asp, cgi, pl, cfm, cfml, rb';
$configuration_help['UPDATE_CHECK'] = 'If selected, the software will check every 7 days for any new releases of V-CMS and display a message when the admin is logged in.';
$configuration_help['ALLOWED_REVISIONS'] = 'This number is the maximum revisions allowed for a single page.  Reach revision creates a copy of the file edited, plus any images changed.';
$configuration_help['SYSTEM_CHECKS'] = 'Upon each page load, the system checks for the correct permissions on the temp directory and the existence of the install directory.';
$configuration_help['ENABLE_INLINE_EDITOR'] = 'Allow users the option to use the Inline Editor.';
$configuration_help['IE_WARNING'] = 'Displays a warning to Internet Explorer users that V-CMS runs slowly in IE and a link to download Mozilla Firefox.';
$configuration_help['SUBMIT_STATS'] = 'Submit some stats on how you use V-CMS to the developers.  This really helps us develop future features, and we won\'t share the information with ANYONE for ANY reason.';
$configuration_help['COLORBOX_STYLE'] = 'Pick one of 5 default colorbox styles.  Valid options are: 1, 2, 3, 4, 5';

$configuration_tab[1] = 'General Settings';
$configuration_tab[2] = 'Template Settings';

//Configuration Page
define('CONFIGURATION_TEXT', 'Configuration');
define('CONFIGURATION_PAGE_RIGHT_TEXT', '<p>For a better description of the values listed, hover your mouse over any item\'s name for a full description.</p>');

//Mail Settings
define('EMAIL_WELCOME_SUBJECT_TEXT', SITE_NAME . ' - Welcome!');
define('EMAIL_WELCOME_BODY_1', 'Welcome!  You\'ve just been registered at ' . SITE_NAME . ' with the following information:');
define('EMAIL_WELCOME_BODY_2', 'Before you can login you need to activate your account by clicking on this link:');
define('EMAIL_WELCOME_BODY_3', 'If you ever lose or forget your password, a new password will be generated for you and sent to this email address, if you would like to change your email address you can do so by going to the My Account page after signing in.');
define('EMAIL_CONFIRMATION_SUBJECT_TEXT', SITE_NAME . ' - Welcome!');
define('EMAIL_CONFIRMATION_BODY_1', 'We\'re sorry for the inconvenience.  We are making our website more secure for both your and our benefit.\n\nTo activate your account you can either click on the following link or copy the link and paste it into your address bar.');
define('EMAIL_CONFIRMATION_BODY_2', 'We here at ' . SITE_NAME . ' hope you continue to enjoy our wonderful service.');
define('EMAIL_NEW_PASSWORD_SUBJECT_TEXT', SITE_NAME . ' - Your New Password!');
define('EMAIL_NEW_PASSWORD_BODY_1', 'We\'ve generated a new password for you at your request, you can use this new password with your username to log in to ' . SITE_NAME);
define('EMAIL_NEW_PASSWORD_BODY_2', 'It is recommended that you change your password to something that is easier to remember, which can be done by going to the My Account page after signing in.');

//Delete Page
define('DELETE_ARE_YOU_SURE_TEXT', 'Are you sure you wish to remove the');
define('YES_TEXT', 'Yes');
define('NO_TEXT', 'No');

//Addfile Page
define('SAVED_TEXT', 'Saved');
define('FTP_ERROR_CONNECT_TEXT', 'Unable to connect to FTP server, please check the host name!');
define('FTP_ERROR_BAD_LOGIN_TEXT', 'Unable to login to FTP server, please check the user name and password!');
define('FTP_ERROR_PUT_PAGE_ERROR_TEXT', 'There was a problem writing a file to the server!');
define('NEW_PAGE_NAME_TEXT', 'New Page Filename');

//Adddomain Page
define('CONNECTION_OK_TEXT', 'Connection OK!');
define('SITE_URL_TEXT', 'Site URL');
define('FTP_SERVER_TEXT', 'FTP Server');
define('PATH_TEXT', 'Path');
define('IMAGE_PATH_TEXT','Image Path');
define('LINK_PATH_TEXT','Link Path'); 
define('MEDIA_PATH_TEXT','Media Path');
define('ADD_DOMAIN_PAGE_RIGHT_TEXT', '<p>' . SITE_URL_TEXT . ' Example:<br><i>http://mysite.com/</i></p><p>' . CUSTOM_CSS_TEXT . ' URL Example:<br><i>http://mysite.com/style.css</i></p><p>' . FTP_SERVER_TEXT . ' Example:<br><i>ftp.mysite.com</i></p><p>' . USER_NAME_TEXT . ' and ' . PASSWORD_TEXT . ' fields are for the FTP login information.</p><p>' . PATH_TEXT . ': Select the document root for this site, click the text field to select</p><p>' . IMAGE_PATH_TEXT . ': <i>OPTIONAL</i> Custom location for uploaded images to be stored.  If the directory does not exist, navigate to the level below where you\'d like the images stored, add "/dirname" to the end and it will be created for you.  Leave blank to have it filled in automatically.</p><p>' . LINK_PATH_TEXT . ': <i>OPTIONAL</i> Custom location for uploaded linkable documents to be stored.  If the directory does not exist, navigate to the level below where you\'d like the images stored, add "/dirname" to the end and it will be created for you.  Leave blank to have it filled in automatically.</p>');
define('CONFIRM_PASSWORD_TEXT', 'Confirm New Password');
define('NEW_PASSWORD_TEXT', 'New Password');
define('LOADING_FTP_TEXT', 'Please wait, communicating with the FTP server...');
define('CLOSE_FTP_TEXT','Click Here To Close FTP List');

//Editor Page
define('FTP_ERROR_GET_PAGE_ERROR_TEXT', 'There was a problem accessing the requested page on the server.');

//define('RESIZING_PHOTO_TEXT', 'Resizing photo');
define('OK_TEXT', 'OK');
define('ERROR_RESIZE_IMAGE_TEXT', 'Unable to re-size image');
define('EDIT_CONTENT_TEXT', 'Edit Content');
define('PAGE_TITLE_TEXT', 'Page Title');
define('PAGE_DESCRIPTION_TEXT', 'Page Description');
define('PAGE_KEYWORDS_TEXT', 'Page Keywords');
define('IMAGE_RESIZE_NOTICE_TEXT', 'Image will be re-sized');
define('WIDTH_TEXT', 'Width');
define('HEIGHT_TEXT', 'Height');
define('IMAGE_TEXT', 'Image');
define('IMAGE_BLANK_NOTICE_TEXT', '(Leave blank to use the current image)');
define('NO_EDITABLE_FOUND_TEXT', 'No editable regions were found.');
define('SUBMIT_TEXT', 'Submit');
define('RESTORE_REVISION_TEXT', 'Restore Revision');
define('NO_REVISIONS_FOUND_TEXT', 'No Revisions Available');
define('REVISIONS_TEXT', 'Revisions');
define('REVISIONS_HOWTO_TEXT', 'Click on a revision to view/save as the current page.');

//Process file
define('USERNAME_EMPTY_ERROR_TEXT', 'User name not entered');
define('USERNAME_NOT_EXIST_ERROR_TEXT', 'User name does not exist');
define('PASSWORD_ERROR_TEXT', 'Invalid password');
define('USERNAME_CONFIRMED_ERROR_TEXT', 'User name already confirmed');
define('CONFIRMATION_SENT_TEXT', 'Your confirmation email has been sent! Back to <a href=|index.php|>Home</a>');

//Register Page (New editor)
define('NEW_ACCOUNT_TEXT', 'New Account');
define('CLOSE_TEXT', 'Close');
define('NEW_ACCOUNT_PAGE_RIGHT_TEXT', '<p>Fill out the form and a confirmation e-mail will be sent to the specified e-mail address.  After the e-mail address is verified this account will become active.</p>');

//User permissions page
define('PERMISSIONS_FOR_TEXT', 'Permissions for');
define('REMOVE_EXISTING_PERMISSION_TEXT', 'Remove Existing Permission');
define('ADD_NEW_PERMISSION_TEXT', 'Add New Permission');
define('USER_PERMISSIONS_PAGE_RIGHT_TEXT', '<p>To remove this editor\'s ability to edit a page, click on the name of the page you wish to remove under "' . REMOVE_EXISTING_PERMISSION_TEXT . '"</p><p>To give this editor the ability to edit a page, click on the name of the page you with to add under "' . ADD_NEW_PERMISSION_TEXT . '"</p>');
define('USER_PERMISSIONS_TEXT', 'User Permissions');
define('PROBLEM_ADDING_PERMISSION', 'There was a problem adding the permission.');
define('PROBLEM_REMOVING_PERMISSION', 'There was a problem removing the permission.');

//Valid.php
define('SEND_TEXT', 'Send!');
define('CONFIRMATION_FAIL_TEXT', 'Confirmation failed, username and UIN do not match.');
define('ACCOUNT_VERIFIED_TEXT', 'Account Verified!');
define('ACCOUNT_VERIFIED_THANKS_TEXT' , 'Thank you for taking the time to verify your e-mail address.  If you need to change your e-mail address on file, after logging in click "' . MY_ACCOUNT_TEXT . '" from the top menu.');
define('ACCOUNT_VERIFIED_SUCCESSFUL_TEXT', '\'s account has been successfully verified.<br><br>You can now <a href="index.php">login</a>.');

// includes/choose_path.php
define('DATABASE_SELECT_ERROR_TEXT', 'Could not select database!');

// includes/resize.image.class.php
define('IMAGE_NOT_EXIST_ERROR_TEXT', 'File does not exist.');
define('IMAGE_NOT_IMAGE_ERROR_TEXT', 'File doesn\'t seem to be an image.');
define('IMAGE_WIDTH_HIGHT_ERROR_TEXT', 'Neither the new height or new width has been set.');

// includes/session.php
define('USERNAME_NOT_ALPHANUMERIC_ERROR_TEXT', 'User name is not alphanumeric.');
define('PASSWORD_NOT_ALPHANUMERIC_ERROR_TEXT', 'Password is not alphanumeric.');

define('USERNAME_NOT_CONFIRMED_ERROR_TEXT', 'User\'s account had not yet been confirmed.');
define('USER_BELOW_5_ERROR_TEXT', 'User name is below 5 characters.');
define('USER_ABOVE_30_ERROR_TEXT', 'User name is over 30 characters.');
define('USER_RESERVED_ERROR_TEXT', 'User name is reserved.');
define('USER_IN_USE_ERROR_TEXT', 'User name is already in use.');
define('USER_BANNED_ERROR_TEXT', 'User name is banned.');
define('PASSWORD_TOO_SHORT_ERROR_TEXT', 'Password is too short.');
define('EMAIL_INVALID_ERROR_TEXT', 'Invalid E-Mail address.');
define('EMAIL_ALREADY_USED_ERROR_TEXT', 'E-Mail address is already in use.');
define('NAME_EMPTY_ERROR_TEXT', 'Name not entered.');
define('CURRENT_PASSWORD_ERROR_TEXT', 'Current Password is incorrect.');
define('NEW_PASSWORD_TOO_SHORT_ERROR_TEXT', 'New Password is too short.');

//image_manager.php
define('IMAGE_MANAGER_TEXT', 'Image Manager');
define('NO_IMAGES_FOUND_TEXT', 'Sorry, no images were found.  To start adding photos, please use the form below!');
define('IMAGE_UPLOAD_INVALID_TYPE_TEXT', 'Please upload a valid image type.');
define('PIXELS_TEXT', 'pixels');
define('UPLOAD_NEW_IMAGE_TEXT', 'Upload New Image');
define('IMAGE_MANAGER_RIGHT_TEXT', '<p>This image manager will allow you to add and remove image files that are available to add via the insert image icon found in the WYSIWYG editor.<br><br>If you wish to re-size your images, enter the preferred height and width of the final image.  The aspect ratio of the image will be maintained.<br><br>After adding photos here, you will find these same image files in the editor.  Simply click the insert image icon and these images will be under the "Image list" pull-down menu.</p><p><b>Allowed images:</b><br>jpg, jpeg, png, gif, bmp');
define('ARE_YOU_SURE_DELETE_TEXT', 'Are you sure you want to delete');

//link_manager.php
define('LINK_MANAGER_TEXT', 'Link Manager');
define('NO_LINKS_FOUND_TEXT', 'Sorry, no files were found.  To start adding files, please use the form below!');
define('LINK_UPLOAD_INVALID_TYPE_TEXT', 'Please upload a valid file type.');
define('UPLOAD_NEW_LINK_TEXT', 'Upload New File');
define('LINK_MANAGER_RIGHT_TEXT', '<p>This link manager will allow you to add and remove links to files that are available to add via the insert link icon found in the WYSIWYG editor.<br><br>After adding files here, you will find these same files in the editor.  After highlighting the text you want to be a link, click the insert link icon and these files will be under the "Links list" pull-down menu.</p>');
define('LINK_MANAGER_LINK_TEXT', 'Link Manager');
define('LINK_TEXT', 'File to link');
define('NOT_ALLOWED_FILE_EXTENTION_TEXT', 'Not allowed file types:');

//media_manager.php
define('MEDIA_MANAGER_TEXT', 'Media Manager');
define('NO_MEDIA_FOUND_TEXT', 'Sorry, no files were found.  To start adding files, please use the form below!');
define('MEDIA_UPLOAD_INVALID_TYPE_TEXT', 'Please upload a valid file type.');
define('UPLOAD_NEW_MEDIA_TEXT', 'Upload New File');
define('MEDIA_MANAGER_RIGHT_TEXT', '<p>This Media manager will allow you to add and remove media files that are available to add via the insert media icon found in the WYSIWYG editor.</p><p>After adding files here, you will find these same files in the editor.  In the editor click the insert media icon and these files will be under the "List" pull-down menu.</p><p><b>Allowed File types:</b><br>swf, dcr, mov, mpg, mp3, mp4, mpeg, avi, wmv, asf, asx</p>');
define('MEDIA_MANAGER_MEDIA_TEXT', 'Media Manager');
define('MEDIA_TEXT', 'File to Media');

//add_file.php
define('ADD_FILE_TEXT', 'Add File');
define('CLICK_TEXT', 'Click');

//editdomain.php
define('DOMAIN_CHECK_FAILED', 'Domain permission check failed!');
define('EDIT_DOMAIN_TEXT', 'Edit Domain');
define('SITE_NAME_TEXT', 'Site Name');
define('EDIT_DOMAIN_PAGE_RIGHT_TEXT', '<p>' . SITE_URL_TEXT . ' Example:<br><i>http://mysite.com/</i></p><p>' . CUSTOM_CSS_TEXT . ' URL Example:<br><i>http://mysite.com/style.css</i></p><p>' . FTP_SERVER_TEXT . ' Example:<br><i>ftp.mysite.com</i></p><p>' . USER_NAME_TEXT . ' and ' . PASSWORD_TEXT . ' fields are for the FTP login information.</p><p>' . PATH_TEXT . ': Select the document root for this site, click the text field to select</p><p>' . IMAGE_PATH_TEXT . ': <i>OPTIONAL</i> Custom location for uploaded images to be stored.  If the directory does not exist, navigate to the level below where you\'d like the images stored, add "/dirname" to the end and it will be created for you.  Leave blank to have it filled in automatically.</p><p>' . LINK_PATH_TEXT . ': <i>OPTIONAL</i> Custom location for uploaded linkable documents to be stored.  If the directory does not exist, navigate to the level below where you\'d like the images stored, add "/dirname" to the end and it will be created for you.  Leave blank to have it filled in automatically.</p>');

//Inline Editor
define('SAVE_TEXT', 'Save');
define('CANCEL_TEXT', 'Cancel');
define('MOVE_TEXT', 'Move');
define('BROWSE_TEXT', 'BROWSE');
define('EDIT_TITLE_DESCRIPTION_TEXT','Edit Title/<br>Description');
?>