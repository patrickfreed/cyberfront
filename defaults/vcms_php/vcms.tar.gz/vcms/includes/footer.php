<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# footer.php - Draws the footer for V-CMS

?>
<div style="clear: both; height: 1px"></div>
    </div>
  </div>
</div>
	<?php
 if ($_REQUEST["popup"] != 1) {
?>	
	<div id="footer">
		<p>Powered by: <a href="http://www.v-cms.org" target="_blank">V-CMS v<?php echo VCMS_VERSION;?></a> - Copyright (c) 2010-<?php echo date('Y');?> VyReN, LLC - All rights reserved.<br>
	<?php
	$time = microtime();

$time = explode(" ", $time);

$time = $time[1] + $time[0];

$finish = $time;

$totaltime = ($finish - $start);

printf ("<sup>This page took %f seconds to load.</sup>", $totaltime);
	?>
	</p>
	</div>
	<?php
	}
	?>
</div>
</body>
</html>
