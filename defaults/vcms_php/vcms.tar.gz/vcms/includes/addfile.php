<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# includes/addfile.php - Adds a file to a domain
if (!defined('DB_SERVER')) {
	$from_root = true;
	require('config.php');
	include("languages/" . LANGUAGE_FILE . ".php");
	include("session.php");
	require("v-cms.php");
	mysql_connect(DB_SERVER, DB_USER, DB_PASS);
	MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
}
if(!$session->logged_in){
	die;
}
// SQL Injection prevention
$_REQUEST["selectedfile"] = mysql_real_escape_string($_REQUEST["selectedfile"]);
$_REQUEST["activepage"] = mysql_real_escape_string($_REQUEST["activepage"]);
// Domain is technically verified in the "security check" below.
$_REQUEST["domain"] = mysql_real_escape_string($_REQUEST["domain"]);
// Security check -- does user have permissions on this domain?
if (!domain_permission_check($_REQUEST["domain"])) {
	die;
}
// Get domain login info
$ftp = new VCMS_FTP;
$ftp->GetDomainInfo($_REQUEST["domain"]);

if ($_REQUEST["selectedfile"] != "") {
	echo SAVED_TEXT . "...<br>";
	$_REQUEST["selectedfile"] = str_replace("/" . $ftp->path, "", $_REQUEST["selectedfile"]);
	$q = "INSERT INTO pages (Name, Path, Domain) VALUES ('" .$_REQUEST["selectedfile"] . "','" . $_REQUEST["selectedfile"] . "','" . $_REQUEST["domain"] . "')";

	$result = mysql_query($q);
	$_REQUEST["activepage"] = mysql_insert_id();
	$q = "INSERT INTO permissions (UserID, Type, Permission) VALUES ('" . $session->user_db_id . "','Page','" . $_REQUEST["activepage"] . "')";
	$result = mysql_query($q);
	if ($from_root) {
		require('../permissions.php');
	} else {
		require('permissions.php');
	}
} else {
	//Open FTP Connection
	$ftp->Open();
	
	if ($_REQUEST["path"] == "") { $_REQUEST["path"] = "/" . $ftp->path;}
	$current_path = $_REQUEST["path"];
	if (substr($current_path, -1) != "/") {
		$current_path = $current_path . "/";
	}
	echo "<ul class=\"jqueryFileTree\" style=\"display: none;\">";
	$paths = explode("/", $_REQUEST["path"]);
	$a = 1;
	do {
		$back_path = $back_path . "/" . $paths[$a];
		$a = $a + 1;
	} while ($a < count($paths) - 1);
	?>


<script type="text/javascript" src="includes/js/jquery.js"></script>
<link rel="stylesheet" href="css/style.css" type="text/css">
<?php
$current_path = str_replace("%20", " ", $current_path);
	$ftp->GetFileList($current_path);
	if (!empty($ftp->dirlist)) {
		foreach ($ftp->dirlist as $dirname => $dirinfo) {
			//echo "[ $dirname ] " . $dirinfo['chmod'] . " | " . $dirinfo['owner'] . " | " . $dirinfo['group'] . " | " . $dirinfo['month'] . " " . $dirinfo['day'] . " " . $dirinfo['time'] . "<br>";
			echo "<li class=\"directory collapsed\"><a href=\"#\" rel=\"" . $current_path . $dirname . "/\">" . htmlentities($dirname) . "</a></li>";
		}
	}
	if (!empty($ftp->filelist)) {
		foreach ($ftp->filelist as $filename => $fileinfo) {
			//echo "$filename " . $fileinfo['chmod'] . " | " . $fileinfo['owner'] . " | " . $fileinfo['group'] . " | " . $fileinfo['size'] . " Byte | " . $fileinfo['month'] . " " . $fileinfo['day'] . " " . $fileinfo['time'] . "<br>";
			echo "<li class=\"file ext_" . end(explode(".", $filename)) . "\"><a href=\"#\" rel=\"" . $current_path . $filename . "\">" . htmlentities($filename) . "</a></li>";
		}
	}
	echo "</ul>";
}
?>