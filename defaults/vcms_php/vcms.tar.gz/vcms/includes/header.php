<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# includes/header.php - Draws the header for V-CMS
if ($_REQUEST['page'] != "e3") {
if (!defined(COLORBOX_STYLE)) {
	define('COLORBOX_STYLE','1');
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Powered By V-CMS <?php echo VCMS_VERSION;?> - http://www.v-cms.org -->
<!-- Removal of this notice is in violation of the GNU licensing. -->
<!-- Copyright 2011 VyReN, LLC, All Rights Reserved -->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo SITE_NAME;?>-Powered by V-CMS</title>
<link media="screen" rel="stylesheet" href="css/colorbox<?php echo COLORBOX_STYLE;?>/colorbox.css">
<script type="text/javascript" src="includes/js/jquery.js"></script>
<script type="text/javascript" src="includes/js/jquery-ui.js"></script>
<script type="text/javascript" src="includes/js/jquery.colorbox-min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
			//Examples of how to assign the ColorBox event to elements
			$(".configuration_lightbox").colorbox({width:"990", height:"655", iframe:true, 
				onClosed:function(){ window.location = 'index.php'; }
			});
			$(".editor_lightbox").colorbox({ width:"990px", height:"99%", iframe:true});
			$(".inline_editor_lightbox").colorbox({width:"99%", height:"99%", iframe:true});
			$(".iframe_lightbox").colorbox({width:"990", height:"625", iframe:true});
			$(".my_account_lightbox").colorbox({width:"990", height:"325", iframe:true});
			$(".delete_lightbox").colorbox({width:"990", height:"325", iframe:true});
			$(".site_edit_lightbox").colorbox({width:"1010", height:"690", iframe:true});
			$(".image_manager_lightbox").colorbox({width:"990", height:"575", iframe:true});
			$(".permissions_lightbox").colorbox({width:"990", height:"575", iframe:true});
			$(".add_page_lightbox").colorbox({width:"990", height:"725", iframe:true});
			$(".add_editor_lightbox").colorbox({width:"990", height:"325", iframe:true});
			$(".copy_lightbox").colorbox({width:"750", height:"725", iframe:true});
			$(".settings_lightbox").colorbox({width:"750", height:"575", iframe:true});
			$(".editor_permissions_lightbox").colorbox({width:"990", height:"625", iframe:true});
		});

</script>
<style type="text/css">
	h1, h2, h3, .heading2 {
		color:<?php if (defined('HEADER_COLOR')) {
			echo HEADER_COLOR;
			} else {
			echo "#AA2808";
			}
			?>;
	}
	*.btn.blue  { background:<?php if (defined('BUTTON_BACKGROUND')) {
			echo BUTTON_BACKGROUND;
			} else {
			echo "#2ae";
			}
			?>; }
	.btn { color: <?php if (defined('BUTTON_COLOR')) {
			echo BUTTON_COLOR;
			} else {
			echo "#fff";
			}
			?>; }
	.btn:hover { background-color: <?php if (defined('BUTTON_HOVER_BACKGROUND')) {
			echo BUTTON_HOVER_BACKGROUND;
			} else {
			echo "#a00";
			}
			?>; color:<?php if (defined('BUTTON_HOVER_COLOR')) {
				echo BUTTON_HOVER_COLOR;
				} else {
				echo "#fff";
				}
				?>;}
	.btn:active { background-color: <?php if (defined('BUTTON_ACTIVE_BACKGROUND')) {
				echo BUTTON_ACTIVE_BACKGROUND;
				} else {
				echo "#444";
				}
				?>; color:<?php if (defined('BUTTON_ACTIVE_COLOR')) {
				echo BUTTON_ACTIVE_COLOR;
				} else {
				echo "#fff";
				}
				?>;}
	body {
		<?php
			if ($_REQUEST['popup'] != 1) {
				if (defined('BACKGROUND_CSS')) {
					echo "background: " . BACKGROUND_CSS . ";";
				} else {
					echo "background: #f5f5f5 url(images/img01.jpg) repeat-x left top;";
				}
			} else {
				echo "background: #FFFFFF;";
			}
		?>
	}
</style>
<link rel="stylesheet" href="<?php if (defined('CUSTOM_CSS')) {
									echo CUSTOM_CSS;
									} else {
									echo "css/style.css";
									}
									?>" type="text/css">
</head>
<body>
<div id="dhtmltooltip"><?php if ($tool_tip_img != "") { echo '<img src="' . $tool_tip_img . '">';}?></div>
<div id="infobar">
	<noscript>
		<p><?php echo JAVASCRIPT_ERROR_TEXT;?></p>
	</noscript>
	<?php
	if (IE_WARNING == 'on' && $_REQUEST['popup'] != '1') {
		if(preg_match('/MSIE/i',$_SERVER['HTTP_USER_AGENT']))
		{
			echo "<a href=\"http://www.getfirefox.com\" target=\"_blank\"><p>" . IE_BROWSER_WARNING_TEXT . "</p></a>";
		} 
	}
	?>
</div>
<div id="wrapper">
<?php
if ($_REQUEST["popup"] != "1") {
?>	
	<div id="header">
		<div id="logo">
		<?php 
		if (defined("DEMO_SITE")) {
			include('includes/demosite.php');
		}
		
		if (defined('LOGO_IMAGE')) {
		?>
			<img style="padding-right:10px;float:left;" src="<?php echo LOGO_IMAGE; ?>" height=67 alt="logo">
			<?php
			}
			?>
			<h1><a href="#"><?php echo SITE_NAME;?></a></h1><br><br><br>
			<h2><?php echo TAGLINE;?></h2>
		</div>
	</div>
	<div id="menu">
			<ul>
				<li><a href="index.php" class="active"><?php echo HOME_MENU_TEXT;?></a></li>
					<?php
					if ($session->logged_in){
					?>
						<li><a href="?page=u1&amp;popup=1" class="my_account_lightbox"><?php echo MY_ACCOUNT_MENU_TEXT;?></a></li>
						<?php 
						if ($session->isSuperAdmin()){
							?>
							<li><a href="?page=c1&amp;popup=1" class="configuration_lightbox"><?php echo CONFIGURATION_MENU_TEXT;?></a></li>
							<?php
						}
						?>
					<li><a href="process.php?logout=1"><?php echo LOGOUT_MENU_TEXT;?></a></li>
					<?php
					}
				if (defined('CUSTOM_HELP_LINK')) {
					echo "<li><a href=\"" . CUSTOM_HELP_LINK . "\" target=\"_blank\">" . HELP_MENU_TEXT . "</a></li>";
				}
				?>
			</ul>
	</div>
	<div id="main">
		<div id="page">
			<div id="page-bgtop">
				<?php
}
?>
				<div id="content" class="content2">

   <?php
   // Permissions and other system checks
	if (SYSTEM_CHECKS == "on" & $_REQUEST["page"] != "install" & $_REQUEST["page"] != "install2") {
		$tocheck = "temp";
		$critical_error = "";
		if (substr(sprintf('%o', fileperms($tocheck)), -4) != "0777") {
			$critical_error = TEMP_DIR_ERROR . " " . $tocheck . "<br>";
		}
		if (file_exists("install")) {
			//$critical_error .= INSTALL_DIRECTORY_EXISTS_TEXT . "<br>";
		}
		if (ENCRYPTION_SALT == "987654321SalT") {
			$critical_error .= ENCRYPTION_SALT_ERROR_TEXT . "<br>";
		}
		if (ENCRYPTION_PASSWORD == "PassWord123456789") {
			$critical_error .= ENCRYPTION_PASSWORD_ERROR_TEXT . "<br>";
		}
		
	}
	//Problem saving an edited page
	if(isset($_SESSION['editerror'])){
		echo "<h1>" . EDITOR_SAVE_ERROR_TEXT . "</h1>";
		echo "<p>" . $_SESSION['editerror'] . "</p>";
		unset($_SESSION['editerror']);
	}
	// Forgot Password form has been submitted and no errors were found with the form (the username is in the database)
	if(isset($_SESSION['forgotpass'])){
		// New password was generated for user and sent to user's email address.
		if($_SESSION['forgotpass']){
			echo "<h1>" . NEW_PASSWORD_GENERATED_TEXT . "</h1>";
			echo "<p>" . NEW_PASSWORD_SUCCESSFUL_TEXT . "</p>";
		}
	// Email could not be sent, therefore password was not edited in the database.
		else {
			echo "<h1>" . NEW_PASSWORD_FAILURE_TEXT . "</h1>";
			echo "<p>" . NEW_PASSWORD_ERROR_TEXT . "</p>";
		}
		unset($_SESSION['forgotpass']);
	}
	// The user has submitted the registration form and the results have been processed.
	if(isset($_SESSION['regsuccess'])){
		// Registration was successful
		if(!$session->logged_in) {
			if($_SESSION['regsuccess']){
				echo "<h1>" . REGISTERED_TEXT . "</h1>";
				if(EMAIL_WELCOME){
					echo "<p>" . THANK_YOU_TEXT . " <b>".$_SESSION['reguname']."</b>. " . CONFIRMATION_SENT_OK_TEXT . "<br /></p>";
				}else{
					echo "<p>" . THANK_YOU_TEXT . " <b>".$_SESSION['reguname']."</b>, " . NO_CONFIRMATION_SENT_TEXT . "</p>";
				}
			}
			// Registration failed
			else{
				echo "<h1>" . REGISTRATION_FAILED_TEXT . "</h1>";
				echo "<p>" . REGISTRATION_FAILED_NOTICE_TEXT . "</p>";
			}
		}
		unset($_SESSION['regsuccess']);
		unset($_SESSION['reguname']);
	}
}