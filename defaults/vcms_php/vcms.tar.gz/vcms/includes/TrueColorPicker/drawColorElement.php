<?
$colorCode=$_GET['colorCode'];
$width = $_GET['width'];
$height = $_GET['height'];

	$x=$y=1;
	$x2 = $x + $width - 1;
	$y2 = $y + $height - 1;
	
	header('Content-type: image/png');
	
	$img = @imagecreate($width,$height);

	$r = hexdec(substr($colorCode,0,2)); 
	$g = hexdec(substr($colorCode,2,2));
	$b = hexdec(substr($colorCode,4,2));

	$color = imagecolorallocate($img,$r,$g,$b);

	imagefill($img,$x,$y,$color);
	imagefilledrectangle($img,$x,$y,$x2,$y2,$color);
	
	imagepng($img);
	imagedestroy($img);
W?>