<?
header('Content-type: image/png');

$df = $_GET['df'];//detailfactor
$baseColor = $_GET['bc'];//base color should be a color code WITHOUT the HASH (#)
$gridSize =  256;
$img = @imagecreatetruecolor($gridSize,$gridSize);
include 'generateBrightnessArrays.php';
$arr = generateBrightnessArrays($df,$baseColor);

//$filename="ColorArrays/{$df}/{$baseColor}.txt";
//if(is_file($filename)){
if($arr){
	//$fileContent = file_get_contents($filename);
	//eval($fileContent);
	//$arr = (${'_'.$baseColor});

	$blockSize = $gridSize/$df;
	$x = $y = 0;
	
	foreach($arr as $innerArr){
		$x = 0;
		foreach($innerArr as $colorCode){
			$r = hexdec(substr($colorCode,1,2)); 
			$g = hexdec(substr($colorCode,3,2));
			$b = hexdec(substr($colorCode,5,2));
			//echo "({$r},{$g},{$b})---";
			//echo "( $x , $y )-";
			$toFill = imagecolorallocate($img,$r,$g,$b);	
				$x2 = $x + $blockSize;
				$y2 = $y + $blockSize;
			
			imagefilledrectangle($img,$x,$y,$x2,$y2,$toFill);
			
			$x+= $blockSize;
		}
		//echo "<br>";
		$y += $blockSize;
	}
}
	imagepng($img);
	imagedestroy($img);
?>