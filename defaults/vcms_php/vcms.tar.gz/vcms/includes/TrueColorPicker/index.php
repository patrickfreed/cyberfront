<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script src="colorPicker.js" language="javascript" type="text/javascript"></script>
<title>True Color Picker</title>
</head>

<?
$preload = $_GET['preload'];
$df = $_GET['df'];

if(!empty($preload) && strlen($preload==7)){
	$preload=substr(strtolower($preload),1,6);
}

require_once ('class.TrueColorPicker.php');
$hueFile = "hueColors.txt";
eval(file_get_contents($hueFile));
?>
<body>

<?
	$cb = new TrueColorPicker();
	$cb->setDf($df);
	if(!empty($preload)){
		$cb->setPreload($preload);
	}
	$cb->build();

?>
	
</body>
</html>
