<?

$df = urldecode($_GET['df']);//detailfactor
$baseColor = urldecode($_GET['bc']);

$gridSize =  256;

include 'generateBrightnessArrays.php';
$arr = generateBrightnessArrays($df,$baseColor);

//$filename="ColorArrays/{$df}/{$baseColor}.txt";
//if(is_file($filename)){
if($arr){
	//$fileContent = file_get_contents($filename);
	//eval($fileContent);
	//$arr = (${'_'.$baseColor});

	$blockSize = $gridSize/$df;
	?><table cellpadding="0" cellspacing="0" height="<?=$gridSize?>" width=<?=$gridSize?>" 
		style="background:url('buildBrightnessBox.php?df=<?=$df?>&bc=<?=$baseColor?>')"><?	
	foreach($arr as $innerArr){
		?></tr><?	
		foreach($innerArr as $colorCode){
			?><td height="<?=$blockSize?>" width=<?=$blockSize?>" onclick="brightnessBoxClick('<?=substr($colorCode,1,6)?>')"><?	

			?></td><?	
		}
		?></tr><?	
	}
	?></table><?	
}

?>