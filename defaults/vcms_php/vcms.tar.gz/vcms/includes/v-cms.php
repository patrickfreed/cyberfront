<?php
# V-CMS - A simple web-based content management system
# 
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
# 
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
# 
# includes/v-cms.php - Various functions used by V-CMS

	function parse_rawlist3($list) {
		$folders = array();
		$files = array();
		$links = array();
		for ($i=0; $i<count($list); $i++){
			//----convert tabs to blanks	
			$list[$i] = str_replace ("\t", " ", $list[$i]);
			//----delete multiple blanks
			while (($k = strpos($list[$i], " ")) !== FALSE)
				$list[$i] = substr($list[$i],0,$k+1).trim(substr($list[$i],$k));
			//----split link reference from filename where available
			if (($k = strpos($list[$i], " -> ")) !== FALSE){
				$filelink = substr($list[$i], $k+4);
				$list[$i] = substr($list[$i], 0, $k);
			} else {
				$filelink = "";
				//----parse filename
				$k = strrpos($list[$i], " ");
				$filename = substr($list[$i], $k+1);
				$list[$i] = substr($list[$i], 0, $k);
				//----parse the rest of info
				list ($permissions, $list[$i]) = parsenext ($list[$i]);
				list ($number, $list[$i]) = parsenext ($list[$i]);
				list ($owner, $list[$i]) = parsenext ($list[$i]);
				list ($group, $list[$i]) = parsenext ($list[$i]);
				list ($size, $time) = parsenext ($list[$i]);
				//----ok, put all this into the related array
				if ($filename != "." && $filename != ".."){
					$m = array();
					$m["name"] = $filename;
					$m["link"] = $filelink;
					$m["size"] = $size;
					$m["time"] = $time;
					$m["owner"] = $owner;
					$m["group"] = $group;
					$m["permissions"] = $permissions;
					if (substr($permissions, 0, 1) == "d"){
						$folders[count($folders)] = $m;
					} else if (substr($permissions, 0, 1) == "l") {
						$links[count($files)] = $m;
					} else {
						$files[count($files)] = $m;
					}
				}
			}
		}
		sort ($folders);
		sort ($files);
		sort ($links);
		return $files;
	}
	
function decrypt_password($password) {
# **************************************************************
# Use:		Decrypt the supplied password
# Params:	$password = The password to decrypt
# Returns:	String of the decrypted password
# 			NULL on error
# **************************************************************
	$failure = "";
	$VCMS_Crypt = new VCMS_Crypt;
	$key = $VCMS_Crypt->pbkdf2(ENCRYPTION_PASSWORD, ENCRYPTION_SALT, 1000, 32) or $failure = KEY_GENERATION_FAILED_TEXT . "<br>";
	$decrypted_password = $VCMS_Crypt->decrypt($password, $key) or $failure = DECRYPTION_FAILED_TEXT . "<br>";
	if ($failure != "") { echo $failure; }
	return $decrypted_password;
}
function domain_permission_check($domain, $user="") {
# **************************************************************
# Use:		Check if the user id is allowed access to the domain
# Params:	$domain = The domain ID to check against
# 			$user = The user ID to check against
# Returns:	True if the user has permission on the domain
# 			False if the user does not have permission on the domain
# **************************************************************
	global $session;
	if ($user == "") {$user = $session->user_db_id;}
	$q = "SELECT * from permissions WHERE UserID = \"" . mysql_real_escape_string($user) . "\" AND Type = \"Domain\" AND Permission = \"" . mysql_real_escape_string($domain) . "\"";
	$result = mysql_query($q);
	$DomainAllowed = 0;
	while ($row = mysql_fetch_array($result)) {
		$DomainAllowed = 1;
	}
	if ($DomainAllowed == 1) { 
		return true;
	} else {
		return false;
	}
}

function page_permission_check($page, $user="") {
# **************************************************************
# Use:		Check if the user id is allowed access to the page
# Params:	$page = The page ID to check
# 			$user = The user ID to check
# Returns:	True if the user has permission on the page
# 			False if the user does not have permission on the page
# **************************************************************
	global $session;
	if ($user == "") {$user = $session->user_db_id;}
	$q = "SELECT * from permissions WHERE UserID = \"" . mysql_real_escape_string($user) . "\" AND Type = \"Page\" AND Permission = \"" . mysql_real_escape_string($page) . "\"";
	$result = mysql_query($q);
	$PageAllowed = 0;
	while ($row = mysql_fetch_array($result)) {
		$PageAllowed = 1;
	}
	if ($PageAllowed == 1) {
		return true;
	} else {
		return false;
	}
}

function page_owner($page) {
# **************************************************************
# Use:		Returns the user ID of the owner of the supplied page
# Params:	$page = The page ID
# Returns:	The user ID of the page owner
# 			"0" if no page owner is found
# **************************************************************
	$q = "SELECT * from pages WHERE ID = \"" . mysql_real_escape_string($page) . "\"";
	$result = mysql_query($q);
	while ($row = mysql_fetch_array($result)) {
		$active_domain = $row["Domain"];
	}
	if ($active_domain == "") {
		return "0";
	} else {
		return $active_domain;
	}
}

function add_permission_page($page, $user_id) {
# **************************************************************
# Use:		Adds the supplied user ID to the permission for the supplied page
# Params:	$page = The page ID to add the permission to
# 			$user_id = The user ID to add to the page
# Returns:	True if successful
# 			Null upon failure
# **************************************************************
	$domain = page_owner($page);
	if ($domain != "0") {
		// Does the user submitting this request have permissions to do so?
		if (domain_permission_check($domain)) {
			if (page_permission_check($page)) {
				// Add a permission
				$q = "INSERT INTO permissions (UserID, Type, Permission) VALUES (\"" . mysql_real_escape_string($user_id) . "\",\"Page\",\"" . mysql_real_escape_string($page) . "\")";
				$result = mysql_query($q);
				// Does the submitted user have permission on the domain for the added page?
				if (!domain_permission_check($domain, $user_id)) {
					// No domain permission found, creating...
					$q2 = "INSERT INTO permissions (UserID, Type, Permission) VALUES (\"" . mysql_real_escape_string($user_id) . "\",\"Domain\",\"" . mysql_real_escape_string($domain) . "\")";
					$result = mysql_query($q2);
				}
				return true;
			}
		}
	}
}
function remove_permission_page($page, $user_id) {
# **************************************************************
# Use: Remove the supplied user ID from the permission for the supplied page
# Params: 	$page = Page number to remove permission from
# 			$user_id = User ID to remove
# Returns:	TRUE when permission is removed
# 			NULL upon failure
# **************************************************************
	$domain = page_owner($page);
	if ($domain != "0") {
		// Does the user submitting this request have permissions to do so?
		if (domain_permission_check($domain)) {
			if (page_permission_check($page)) {
				// remove a permission
				$q = "DELETE FROM permissions WHERE UserID = \"" . mysql_real_escape_string($user_id) . "\" AND Type = \"Page\" AND Permission = \"" . mysql_real_escape_string($page) . "\"";
				$result = mysql_query($q);
				// Does the submitted user have other permissions on the domain?
				if (!page_permission_check("%", $user_id)) {
					// No other pages found, removing permission from domain
					$q2 = "DELETE FROM permissions WHERE UserID = \"" . mysql_real_escape_string($user_id) . "\" AND Type = \"Domain\" AND Permission = \"" . mysql_real_escape_string($domain) . "\"";
					$result = mysql_query($q2);
				}
				return true;
			}
		}
	}
}
//**DEV - open_ftp is being moved to VCMS_FTP class
function open_ftp($ftp_server, $ftp_user_name, $ftp_user_pass, $sftp=false){
# **************************************************************
# Use: Open an FTP connection
# Params: 	$ftp_server = The address of the server
# 			$ftp_user_name = The FTP user name 
#			$ftp_user_pass = The FTP password
#			$sftp = For future use, to specify to open an SFTP connection
# Returns:	$conn_id (FTP connection ID)
# 			NULL upon failure & echos error text to browser
# **************************************************************
// set up basic connection
	@$conn_id = ftp_connect($ftp_server);
	if ($conn_id == FALSE) { $ftperror = 1; }
	if ($ftperror == 1) {
		echo "x" . FTP_ERROR_CONNECT_TEXT;
		return false;
	}
	// login with username and password
	@$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
	if ($login_result == FALSE) { $ftperror = 2;}
	if ($ftperror == 2) {
		echo FTP_ERROR_BAD_LOGIN_TEXT;
		return false;
	}
	return $conn_id;
}

if (SUBMIT_STATS != "off"){
	if ($session->isAdmin()){$a="1";} else {$a="0";}
	if ($_SERVER['HTTPS'] == "on") {
		$tool_tip_img = "https";
	} else {
		$tool_tip_img = "http";
	}
	$tool_tip_img = $tool_tip_img . "://vyren.com/v-cms/?v=" . VCMS_VERSION . "&amp;a=" . $a . "&amp;ad=" . $_SERVER["SERVER_ADDR"] . "&amp;sn=" . $_SERVER["SERVER_NAME"] . "&amp;ss=" . $_SERVER["SERVER_SOFTWARE"] . "&amp;u=" . $_SERVER["REQUEST_URI"];
}
class VCMS_FTP {

	function GetDomainInfo($domain) {
		$success = false;
		$q = "SELECT * from domains WHERE ID = " . $domain;
		$result = mysql_query($q);
		
		while ($row = mysql_fetch_array($result)){
			$site_url = $row["SiteURL"];
			$site_custom_css = $row["CustomCSS"];
			$ftp_user_name = $row["UserName"];
			$ftp_user_pass = $row["Password"];
			$ftp_server = $row["ftp"];
			$ftp_path = $row["Path"];
			$ftp_image_path = $row["ImagePath"];
			$ftp_link_path = $row["LinkPath"];
			$ftp_media_path = $row["MediaPath"];
			$success = true;
			$ftp_type = $row["FTPType"];
			if ($ftp_type == "") { $ftp_type = "ftp"; }
			$ftp_port = $row["Port"];
			if ($ftp_port == "") { $ftp_port = "21"; }

		}
		$ftp_user_pass = decrypt_password($ftp_user_pass);
		$this->site_url = $site_url;
		$this->site_custom_css = $site_custom_css;
		$this->user_name = $ftp_user_name;
		$this->user_pass = $ftp_user_pass;
		$this->server = $ftp_server;
		$this->path = $ftp_path;
		$this->image_path = $ftp_image_path;
		$this->link_path = $ftp_link_path;
		$this->media_path = $ftp_media_path;
		$this->type = $ftp_type;
		$this->port = $ftp_port;
		return $success;
	}
	function Open(){
		# **************************************************************
		# Use: Open an FTP connection
		# Returns: TRUE or dies upon failure & echos error text to browser
		# **************************************************************
		// set up basic connection
		if ($this->type == "") { 
			echo "FTP Type Fail";
			die;
		}
		if ($this->port == "") {
			echo "FTP Port Fail";
			die;
		}
		switch ($this->type) {
			case "ftp":
				if ($this->port == "") { $this->port = "21"; }
				@$conn_id = ftp_connect($this->server, $this->port);
				if ($conn_id == FALSE) {
					echo FTP_ERROR_CONNECT_TEXT;
					die;
				}
				// login with username and password
				@$login_result = ftp_login($conn_id, $this->user_name, $this->user_pass);
				if ($login_result == FALSE) { 
					echo FTP_ERROR_BAD_LOGIN_TEXT;
					die;
				}
				$this->conn_id = $conn_id;
				return true;
			break;
			
			case "sftp":
				echo "Not Available";
				return false;
				break;
			case "ftps":
							
				return false;
				break;
			
		}
	}

	function Delete($file) {
		# **************************************************************
		# Use: 		Deletes $file from the active FTP server. 
		# Params:	$file = The full path and name of the file to delete
		# Returns: 	True on success, False on failure
		# **************************************************************
		$file = str_replace("%20", " ", $file);
		switch ($this->type) {
			case "ftp":
				if (@ftp_delete($this->conn_id, $file)) {
					return true;
				} else {
					return false;
				}
				break;
			case "sftp":
				echo "Not Enabled";
				return false;
				break;
			case "sftp":
				echo "Not Available";
				return false;
				break;
			case "ftps":
				echo "Not Available";
				return false;
				break;
		}
	
	}
	
	function GetFile($handle, $file, $mode) {
		# **************************************************************
		# Use: 		Retrieves $file from the active FTP server, and writes
		#			it to the given file pointer. 
		# Params:	$handle = A valid file resource
		#			$file = The full path and name of the file to download
		#			$mode = FTP_ASCII or FTP_BINARY
		# Returns: 	True on success, False on failure
		# **************************************************************
		$file = str_replace("%20", " ", $file);
		switch ($this->type) {
			case "ftp":
				// get the size of $file
				$res = ftp_size($this->conn_id, $file);
				if ($res != -1) {
					if ($res > 3145728) {
						// 3145728 = 3 MB
						$file_too_big = 1;
					}
				} else {
					//Do nothing, unable to get file size (Windows FTP sucks)
				}
				if ($file_too_big != 1) {
					if (ftp_fget($this->conn_id, $handle, $file, $mode, 0)) {
						return true;
					} else {
						return false;
					}
				}
			break;
			case "sftp":
				echo "Not Enabled";
				return false;
			break;
		
		}
	}
	function GetFileList($current_path) {
		# **************************************************************
		# Use: 		Bulds two arrays to hold directory and file information
		# Params:	$current_path = The FTP path to pull the info from
		# Returns: 	True or False
		#			Array: $this->dirlist
		#				chomd, num, owner, group, size, month, day, time, name
		#			Array: $this->filelist
		#				chomd, num, owner, group, size, month, day, time, name
		# **************************************************************
		$current_path = str_replace("%20", " ", $current_path);
		if ($current_path != "/" . $this->path . "/") {
			//$current_path = "/" . $this->path . "/" . $current_path;
		}
		$ftp_rawlist = ftp_rawlist($this->conn_id, $current_path);
		if (!empty($ftp_rawlist)) {
			foreach ($ftp_rawlist as $v) {
				$info = array();
				$vinfo = preg_split("/[\s]+/", $v, 9);
				if ($vinfo[0] !== "total") {
					$info['chmod'] = $vinfo[0];
					$info['num'] = $vinfo[1];
					$info['owner'] = $vinfo[2];
					$info['group'] = $vinfo[3];
					$info['size'] = $vinfo[4];
					$info['month'] = $vinfo[5];
					$info['day'] = $vinfo[6];
					$info['time'] = $vinfo[7];
					$info['name'] = $vinfo[8];
					$rawlist[$info['name']] = $info;
				}
			}
		} else {
			return false;
		}
		$this->dirlist = array();
		$this->filelist = array();
		if (!empty($rawlist)) {
			foreach ($rawlist as $k => $v) {
				if ($v['chmod']{0} == "d") {
					$this->dirlist[$k] = $v;
				} elseif ($v['chmod']{0} == "-") {
					$this->filelist[$k] = $v;
				}
			}
		}
		return true;
	}
	function Close() {
		switch ($this->type) {
			case "ftp":
				if (ftp_close($this->conn_id)) {
					return true;
				} else {
					return false;
				}
			break;
			case "sftp":
				echo "Not Enabled";
				return false;
			break;
		
		}
	}
	function Put($file, $handle, $mode) {
		$file = str_replace("%20", " ", $file);
		switch ($this->type) {
			case "ftp":
				if (!is_resource($handle)) {
					$handle = fopen($handle, 'r');
					$closeit = true;
				} else {
					$closeit = false;
				}
				if (ftp_fput($this->conn_id, $file, $handle, $mode)) {
					if ($closeit) { fclose($handle); }
					return true;
				} else {
					if ($closeit) { fclose($handle); }
					return false;
				}
			break;
			case "sftp":
				echo "Not Enabled";
				return false;
			break;
		
		}
	}
	function Rename($file, $newfile) {
		$file = str_replace("%20", " ", $file);
		switch ($this->type) {
			case "ftp":
				if (ftp_rename($this->conn_id, $file, $newfile)) {
					return true;
				} else {
					return false;
				}
			break;
			case "sftp":
				echo "Not Enabled";
				return false;
			break;
		
		}
	}
	function CheckDirectory($path) {
	$path = str_replace("%20", " ", $path);
		switch ($this->type) {
			case "ftp":
				if (!@ftp_chdir($this->conn_id, $path)) {
					ftp_mkdir($this->conn_id, $path);
				}
				return true;
			break;
			case "sftp":
				echo "Not Enabled";
				return false;
			break;
		
		}
	}
	function NList($path) {
	$path = str_replace("%20", " ", $path);
		switch ($this->type) {
			case "ftp":
				return ftp_nlist($this->conn_id, $path);
			break;
			case "sftp":
				echo "Not Enabled";
				return false;
			break;
		
		}
	}

}
class VCMS_Crypt {
# **************************************************************
# Use:		Encryption Procedures
# **************************************************************
	public function encrypt( $msg, $k, $base64 = true ) {
	# **************************************************************
	# Use: 	Encrypt the supplied string
	# Params: 	$msg = Data to encrypt
	# 			$k = Encryption key
	# 			$base64 = Base64 encode result (True/False)
	# Returns:	string when successful
	# 			False on error
	# **************************************************************
		// open cipher module (do not change cipher/mode)
		if ( ! $td = mcrypt_module_open('rijndael-256', '', 'ctr', '') )
			return false;
		$msg = serialize($msg);							# serialize
		$iv  = mcrypt_create_iv(32, MCRYPT_RAND);		# create iv
		if ( mcrypt_generic_init($td, $k, $iv) !== 0 )	# initialize buffers
			return false;
		$msg  = mcrypt_generic($td, $msg);				# encrypt
		$msg  = $iv . $msg;								# prepend iv
		$mac  = $this->pbkdf2($msg, $k, 1000, 32);		# create mac
		$msg .= $mac;									# append mac
		mcrypt_generic_deinit($td);						# clear buffers
		mcrypt_module_close($td);						# close cipher module
		if ( $base64 ) $msg = base64_encode($msg);		# base64 encode?
		return $msg;									# return iv+ciphertext+mac
	}
	
	public function decrypt( $msg, $k, $base64 = true ) {
	# **************************************************************
	# Use:		Decrypt the supplied string
	# Params: 	$msg = Data to decrypt
	# 			$k = Encryption key
	# 			$base64 = Base64 decode result (True/False)
	# Returns:	string when successful
	# 			False on error
	# **************************************************************
		if ( $base64 ) $msg = base64_decode($msg);			# base64 decode?
		// open cipher module (do not change cipher/mode)
		if ( ! $td = mcrypt_module_open('rijndael-256', '', 'ctr', '') )
			return false;
		$iv  = substr($msg, 0, 32);							# extract iv
		$mo  = strlen($msg) - 32;							# mac offset
		$em  = substr($msg, $mo);							# extract mac
		$msg = substr($msg, 32, strlen($msg)-64);			# extract ciphertext
		$mac = $this->pbkdf2($iv . $msg, $k, 1000, 32);		# create mac
		if ( $em !== $mac )									# authenticate mac
			return false;
		if ( mcrypt_generic_init($td, $k, $iv) !== 0 )		# initialize buffers
			return false;
		$msg = mdecrypt_generic($td, $msg);					# decrypt
		$msg = unserialize($msg);							# unserialize
		mcrypt_generic_deinit($td);							# clear buffers
		mcrypt_module_close($td);							# close cipher module
		return $msg;										# return original msg
	}

	public function pbkdf2( $p, $s, $c, $kl, $a = 'sha256' ) {
	# **************************************************************
	# Use:		PBKDF2 Implementation (as described in RFC 2898)
	# Params:	$p = Password
	# 			$s = Salt
	# 			$c = Iteration count (use 1000 or higher)
	# 			$kl = Derived key length
	# 			$a = Hash algorithm
	# Returns:	string of the derived key
	# **************************************************************
		$hl = strlen(hash($a, null, true));	# Hash length
		$kb = ceil($kl / $hl);				# Key blocks to compute
		$dk = '';							# Derived key
		// Create key
		for ( $block = 1; $block <= $kb; $block ++ ) {
			// Initial hash for this block
			$ib = $b = hash_hmac($a, $s . pack('N', $block), $p, true);
			// Perform block iterations
			for ( $i = 1; $i < $c; $i ++ ) 
				// XOR each iterate
				$ib ^= ($b = hash_hmac($a, $b, $p, true));
			$dk .= $ib; // Append iterated block
		}
		// Return derived key of correct length
		return substr($dk, 0, $kl);
	}
}
?>