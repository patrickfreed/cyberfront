<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# forgotpass.php - Forgot password page

if ($valid != "yes"){
	die;
}
//Forgot password form is displayed, if error found it is displayed.
echo "<h1>" . FORGOT_PASSWORD_TEXT . "</h1>" . FORGOT_PASSWORD_BODY_TEXT . "<br><br>";
echo $form->error("user");
?>
<div class="form_main">
<form action="process.php" name="forgot_password" method="POST">
<div class="form_a"><div class="form_left"><?php echo USER_NAME_TEXT; ?>:</div><div class="form_right"><input type="text" name="user" maxlength="30" value="<?php echo $form->value("user"); ?>"><br><input type="hidden" name="subforgot" value="1"></div></div>
<div class="form_a"><div class="form_left">&nbsp;</div><div class="form_right"><a href="#" onclick="document.forgot_password.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo GET_NEW_PASSWORD_TEXT;?></span></a></div></div>
<input type="submit" style="visibility:hidden">
</form>
</div>