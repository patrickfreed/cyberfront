<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2011, VyReN, LLC
#
?>
<script type="text/javascript">
    if (parent.$("#colorbox").css("display")=="block") {  
          
    }else{  
        window.location = 'index.php';  
    }  
</script>
<?php
if(!$session->isAdmin()){
	die;
}
// Security check -- does user have permissions on this domain?
if (!domain_permission_check($_REQUEST["domain"])) {
	die;
}
if (!page_permission_check($_REQUEST['activepage'])) {
	die;
}
//Get page info
$q = "SELECT * FROM pages WHERE ID = \"" . mysql_real_escape_string($_REQUEST['activepage']) . "\"";
$result = mysql_query($q);
while ($row = mysql_fetch_array($result)){
	$remote_file = $row["Path"];
	$page_name = $row["Name"];
	$custom_css = $row["CustomCSS"];
}
	
if ($_REQUEST["copy"] != '1') {
?>
<h1><?php echo COPY_PAGE_HEADER_TEXT;?></h1>
		<div class="form_main">
		<form action="index.php" name="copy_page" method="POST" class="niceform"><div class="form_a"><div class="form_left"><?php echo NEW_PAGE_NAME_TEXT;?>:</div><div class="form_right"><input type="text" id="newpagename" name="newpagename" size="30" maxlength="30"></div></div>
			<div class="form_a"><div class="form_left">&nbsp;</div> <div class="form_right">&nbsp;<a href="#" onclick="document.copy_page.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo SAVE_TEXT;?></span></a><input type="hidden" name="page" value="c2"><input type="submit" style="visibility:hidden">
			</div></div>
			<br>&nbsp;
			<input type="hidden" value="1" name="copy">
			<input type="hidden" value="<?php echo $_REQUEST['activepage'];?>" name="activepage">
			<input type="hidden" value="<?php echo $_REQUEST['domain'];?>" name="domain">
			<input type="hidden" value="1" name="popup">
			<script type="text/javascript">document.getElementById('newpagename').focus()</script>
		</form>
		</div>
	</div>
	</div>
    <?php
} else {
	//Create copy
	//Load all the FTP info
	$ftp_error = 0;
	$ftp = new VCMS_FTP;
	$ftp->GetDomainInfo($_REQUEST["domain"]);
	$ftp->Open();
	$thepath = explode("/", $remote_file);
	$savepath = $ftp->path;
	$x = 0;
	while ($x < count($thepath)-1){
		if ($thepath[$x] != "") {
			$savepath = $savepath . "/" . $thepath[$x];
		}
		$x = $x + 1;
	}
	if (substr($savepath, -1) != "/") {
		$savepath = $savepath . "/";
	}
	$random_id = $thepath[count($thepath)] . rand(1000, 999999);
	$handle = fopen("temp/" . $random_id . ".tmp", 'c+');
	if (!$ftp->GetFile($handle, $ftp->path . $remote_file, FTP_ASCII)) {
		echo FTP_ERROR_GET_PAGE_ERROR_TEXT;
		die;
	}
	rewind($handle);
	if (!$ftp->Put($savepath . $_REQUEST['newpagename'], $handle, FTP_ASCII)){
		echo FTP_ERROR_PUT_PAGE_ERROR_TEXT . '<br>' . $savepath . $_REQUEST['newpagename'];
		die;
	}
	$ftp->Close();
	fclose($handle);
	unlink("temp/" . $random_id . ".tmp");

	$_REQUEST["selectedfile"] = $savepath . $_REQUEST['newpagename'];
	$_REQUEST["selectedfile"] = str_replace($ftp->path . "/", "/", $_REQUEST["selectedfile"]);
	require('includes/addfile.php');
}
?>