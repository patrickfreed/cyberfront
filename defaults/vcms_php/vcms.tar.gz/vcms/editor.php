<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# editor.php - The main file editor
//Security Check
if(!$session->logged_in){
	die;
}
//Quick Temp Directory Cleanup
foreach (glob("temp/*") as $Filename) {
    // Read file creation time
    $FileCreationTime = filectime($Filename);
    // Calculate file age in seconds
    $FileAge = time() - $FileCreationTime; 
    // Is the file older than 7200 seconds (2 hours)?
    if ($FileAge > (7200)){
		if ($Filename <> "temp/index.php") {
			unlink($Filename);
		}
    }
}

//File Injection prevention
$replace_array = array("/", "\\", "..");
$_REQUEST["rafile"] = str_replace($replace_array, "", $_REQUEST["rafile"]);
$_REQUEST["editfile"] = str_replace($replace_array, "", $_REQUEST["editfile"]);

//SQL Injection prevention
$_REQUEST["editfile"] = mysql_real_escape_string($_REQUEST["editfile"]);

//Check Permissions
if (!domain_permission_check($_REQUEST["ftp"])) {
	die;
}
if (!page_permission_check($_REQUEST["editfile"])) {
	die;
}

//Define the allowed classes and apend any custom classes
$class_search = "[class^=clienteditor],[class^=cushycms],[class^=editable]";
$class_options[] = "clienteditor";
$class_options[] = "cushycms";
$class_options[] = "editable";
if (defined('CUSTOM_CLASS_1')) {
	$class_search = $class_search . ",[class^=" . CUSTOM_CLASS_1 . "]";
	$class_options[] = CUSTOM_CLASS_1;
}
if (defined('CUSTOM_CLASS_2')) {
	$class_search = $class_search . ",[class^=" . CUSTOM_CLASS_2 . "]";
	$class_options[] = CUSTOM_CLASS_2;
}

//Load all the FTP info
$ftp_error = 0;
$ftp = new VCMS_FTP;
$ftp->GetDomainInfo($_REQUEST["ftp"]);

$ftp->Open();
//If no FTP error is found, begin the process
	//Doing a revision?
	$revision = "";
	if (isset($_REQUEST["revision"])) {
		$q = "SELECT * FROM revisions WHERE ID = \"" . mysql_real_escape_string($_REQUEST["revision"]) . "\"";
		$result = mysql_query($q);
		while ($row = mysql_fetch_array($result)){
			$revision = "_" . $row["Path"];
		}
	}
	//Get page info
	$q = "SELECT * FROM pages WHERE ID = \"" . mysql_real_escape_string($_REQUEST["editfile"]) . "\"";
	$result = mysql_query($q);
	while ($row = mysql_fetch_array($result)){
		$remote_file = $row["Path"] . $revision;
		$page_name = $row["Name"];
		$custom_css = $row["CustomCSS"];
	}
	//If CSS is not set for this page, use the site-wide setting
	if ($custom_css == "") {
		$custom_css = $ftp->site_custom_css;
	}
	//If we are not applying an edit, then get the remote file
	if ($_POST["edittime"] == "") {
		$random_id = $_REQUEST["ftp"] . rand(1000, 999999);
		$handle = fopen("temp/" . $random_id . ".tmp", 'w');
		if (!$ftp->GetFile($handle, $ftp->path . $remote_file, FTP_ASCII)) {
			echo FTP_ERROR_GET_PAGE_ERROR_TEXT;
		}
		$ftp->Close();
		fclose($handle);
	} else {
		//We are applying an edit, store the random number given for the filename
		$random_id = $_REQUEST["rafile"];
	}
	
	//Display preview popup, if requested
	if ($_POST["edittime"] == "preview" & $_REQUEST["preview"] != "1") {
		$position = strrpos($remote_file, "/");
		if ($position === false)  { $position = 0;$remote_file="/".$remote_file;}
		echo "<script type=\"text/javascript\">setTimeout(\"$.colorbox({href:'" . substr($ftp->site_url,0,-1) . substr_replace($remote_file, "/v-cmspreview_", $position, 1) . "', iframe: true, width: '90%', height: '90%'});\",1250);</script>";
		
		$_POST["edittime"] = "";
		$viewing_preview = true;
	}
	
	//Start processing the page for HTML
	$filetoedit = $random_id;
	//Without the following DOM Paraser, none of this would be possible!
	//Website: http://sourceforge.net/projects/simplehtmldom/
	if (!function_exists("file_get_html")){
		include('includes/simple_html_dom.php');
	}
	//Read the file
	$thefile = file_get_contents("temp/" . $filetoedit . ".tmp");
	$html = str_get_html($thefile);
	//If we are editing and the temp file was read correctly then...
	if (($_POST['edittime'] == "yes") && ($thefile !="")) {
		//Save the changes
		$thepath = explode("/", $remote_file);
		$savepath = $ftp->path;
		$x = 0;
		while ($x < count($thepath)-1){
			$savepath = $savepath . "/" . $thepath[$x];
			$x = $x + 1;
		}
		$image_counter = 0;
		//Replace the title of the page
		foreach($html->find("title") as $ul) {
			$ul->innertext = $_POST["page_title"];	
		}
		//Replace the meta description
		foreach($html->find("meta[name=description]") as $ul) {
			$bla = $ul->setAttribute("content", $_POST["page_description"]);
		}
		//Replace the meta keywords
		foreach($html->find("meta[name=keywords]") as $ul) {
			$bla = $ul->setAttribute("content", $_POST["page_keywords"]);
		}
		//Find the titles we are to edit in the HTML
		foreach($_POST['edittitle'] as $editing) {
			$tofind = "[" . $_POST['editor1'][$editing] . "=" . $editing . "]";
			foreach($html->find($tofind) as $ul) {
			
				//Is this an image?  We check to see what the form tells us.
				if ($_POST['isimage'][$editing] == 1) {
					$filedir = 'temp/'; // the directory for the original image
					$thumbdir = 'temp/'; // the directory for the thumbnail image
					$prefix = 'small_'; // the prefix to be added to the original name
					$maxfile = '2000000';
					$mode = '0666';			
					$userfile_name = $_FILES['image']['name'][$image_counter];
					$userfile_tmp = $_FILES['image']['tmp_name'][$image_counter];
					$userfile_size = $_FILES['image']['size'][$image_counter];
					$userfile_type = $_FILES['image']['type'][$image_counter];
					$image_counter = $image_counter + 1;
					if ($userfile_name != "") {
						if(!preg_match('#image/#i', $userfile_type)){
							$_SESSION['editerror'] .= IMAGE_UPLOAD_INVALID_TYPE_TEXT . "<br>";
						} else {
							//Image uploaded, process...
							$prod_img = $filedir.$userfile_name;
							move_uploaded_file($userfile_tmp, $prod_img);
							chmod ($prod_img, octdec($mode));
							if (($_POST["height"][$editing] != 0) || ($_POST["width"][$editing] != 0)){
								//Height or width found, resize image...
								if (!class_exists('Resize_Image')){
									include 'includes/resize.image.class.php';
								}
								$image = new Resize_Image;
								$image->new_width = $_POST["height"][$editing];
								$image->new_height = $_POST["width"][$editing];
								if ($image->new_width == "") { $image->new_width=0;}
								if ($image->new_height == "") { $image->new_width=0;}
								$image->image_to_resize = $prod_img; // Full Path to the file
								$image->ratio = true; // Keep Aspect Ratio?
								// Name of the new image (optional) - If it's not set a new will be added automatically
								$image->new_image_name = $prefix.$userfile_name;
								// Path where the new image should be saved. If it's not set the script will output the image without saving it
								$image->save_folder = $thumbdir;
								$process = $image->resize();
								if($process['result'] && $image->save_folder) {
									$prod_img_thumb = $process['new_file_path'];
									//Successful!
								} else {
									//Fail
									$_SESSION['editerror'] .= ERROR_RESIZE_IMAGE_TEXT . '<br>';
								}
							}	
							if ($prod_img_thumb == "") {
								$prod_img_thumb = $prod_img;
							}
							//Do revisioning here, ftp to server.
							$thepathimg = explode("/", $ul->src);
							$image_path_counter = count($thepathimg)-1;
							
							$ftp->Put($savepath . "/" . $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4), $prod_img_thumb, FTP_BINARY);
							$ul->src = $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4);
							//Update the revision database
							$q = "INSERT INTO img_revisions (PageID, Path, ImgID) VALUES ('" . $_REQUEST["editfile"] . "','" . mysql_real_escape_string($ul->src) . "','" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "')";
							$result = mysql_query($q);
							//Check revision database, remove excess pages
							$q = "SELECT * FROM img_revisions WHERE ImgID = \"" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "\" AND PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID";
							$result = mysql_query($q);
							if (mysql_num_rows($result) > ALLOWED_REVISIONS) {
								$q2 = "SELECT * FROM img_revisions WHERE ImgID = \"" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "\" AND PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID LIMIT 1";
								$result2 = mysql_query($q2);
								while ($row2 = mysql_fetch_array($result2)){
									$ftp->Delete($savepath . "/" . $row2["Path"]);
									$q = "DELETE FroM img_revisions WHERE ID = " . $row2["ID"];
									$result = mysql_query($q);
								}
							}
							unlink($prod_img_thumb);
							$prod_img_thumb = "";
						}
					}
					if ($_REQUEST["image_preview"] == "1") {
						$ul->src = str_replace("v-cmspreview_", "", $ul->src, $count);
						if ($count > 0) {
							//Do revisioning here.
							$thepathimg = explode("/", $ul->src);
							$image_path_counter = count($thepathimg)-1;
							$ul->src = $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4);
							//Update the revision database
							$q = "INSERT INTO img_revisions (PageID, Path, ImgID) VALUES ('" . $_REQUEST["editfile"] . "','" . mysql_real_escape_string($ul->src) . "','" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "')";
							$result = mysql_query($q);
							//Check revision database, remove excess pages
							$q = "SELECT * FROM img_revisions WHERE ImgID = \"" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "\" AND PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID";
							$result = mysql_query($q);
							if (mysql_num_rows($result) > ALLOWED_REVISIONS) {
								$q2 = "SELECT * FROM img_revisions WHERE ImgID = \"" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "\" AND PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID LIMIT 1";
								$result2 = mysql_query($q2);
								while ($row2 = mysql_fetch_array($result2)){
									$ftp->Delete($row2["Path"]);
									$q = "DELETE FroM img_revisions WHERE ID = " . $row2["ID"];
									$result = mysql_query($q);
								}
							}
							$ftp->Rename($savepath . "/v-cmspreview_" . $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4), $savepath . "/" . $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4));
						}
					}
				} else {
					//No src found, not an image.
					$ul->innertext = $_POST["editor"][$editing];
				}
			}
		}
		$handle = fopen("temp/" . $filetoedit . ".tmp", 'w+');
		fwrite($handle, $html->save());
		fseek($handle, 0);
		$ftp->Rename($savepath . "/" . $thepath[$x], $savepath . "/" . $thepath[$x] . "_" . $filetoedit);
		$ftp->Put($savepath . "/" . $thepath[$x], $handle, FTP_ASCII);
		//Cleanup any preview files
		$ftp_nlist = $ftp->NList($savepath . "/");
		if (!Empty($ftp_nlist)) {
			foreach ($ftp_nlist as $v) {
				if (substr($v, 0, 12) == "v-cmspreview"){
					$ftp->Delete($v);
				}
			}
		}
		//Update the revision database
		$q = "INSERT INTO revisions (PageID, Path) VALUES ('" . $_REQUEST["editfile"] . "','" . $filetoedit . "')";
		$result = mysql_query($q);
		//Check revision database, remove excess pages
		$q = "SELECT * FROM revisions WHERE PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID";
		$result = mysql_query($q);
		if (mysql_num_rows($result) > ALLOWED_REVISIONS) {
			$q2 = "SELECT * FROM revisions WHERE PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID";
			$result2 = mysql_query($q2);
			$y = 0;
			while ($row2 = mysql_fetch_array($result2)){
				if ($y == 0) {
					$ftp->Delete($savepath . $thepath[$x] . "_" . $row2["Path"]);
					$q = "DELETE FroM revisions WHERE ID = " . $row2["ID"];
					$result = mysql_query($q);
				}
				$y = 1;
			}
		}
		$ftp->Close();
		fclose($handle);
		unlink("temp/" . $filetoedit . ".tmp");
		echo "<script type=\"text/javascript\">window.location = 'index.php?saved=1';</script>";
		die;
	} elseif ($_REQUEST["preview"] == "" & $thefile !="") {
		//Time to display the editor, and the temp file was read correctly.
		$default_mce_init = '
			mode : "none",
			theme : "advanced",
			plugins : "spellchecker,pagebreak,style,layer,table,advhr,advimage,advlink,iespell,inlinepopups,insertdatetime,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras",
			theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect,|,forecolor,backcolor,|,media,image,link,unlink,anchor",
			theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,tablecontrols,|,hr,removeformat,visualaid",
			theme_advanced_buttons3 : "sub,sup,|,insertlayer,moveforward,movebackward,absolute,|,styleprops,spellchecker,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,pagebreak,|,ltr,rtl,|,charmap,iespell,advhr,|,fullscreen,print,cleanup,code",
			theme_advanced_buttons4 : "",
			theme_advanced_toolbar_location : "top",
			theme_advanced_toolbar_align : "center",
			theme_advanced_statusbar_location : "bottom",
			media_types : "flash=swf;shockwave=dcr;qt=mov,qt,mpg,mp3,mp4,mpeg;shockwave=dcr;wmp=avi,wmv,wm,asf,asx,wmx,wvx"';
			if (ENABLE_IMAGE_MANAGER == "on") {
				$default_mce_init .= ",external_image_list_url : \"includes/get_images.php?domain=" . $_REQUEST["ftp"] . "\"";
			}
			if (ENABLE_IMAGE_MANAGER == "on") {
				$default_mce_init .= ",external_link_list_url : \"includes/get_links.php?domain=" . $_REQUEST["ftp"] . "\"";
			}
			if (ENABLE_LINK_MANAGER == "on") {
				$default_mce_init .= ",media_external_list_url : \"includes/get_media.php?domain=" . $_REQUEST["ftp"] . "\"";
			}

			if ($custom_css != "") {
				$default_mce_init .= ",content_css : \"" . $custom_css . "\"";
			}
			?>
		<script type="text/javascript" src="includes/tiny_mce/tiny_mce.js"></script>
		<div style="width:920px;">
		<h1><?php echo EDIT_CONTENT_TEXT;?></h1><div style="margin-right:250px;float:right;"><a href="<?php echo $ftp->site_url . $remote_file . "?" . rand(100, 50000);?>" target="_blank" class="iframe_lightbox btn blue"><i></i><span><span></span><i></i><?php echo VIEW_LIVE_PAGE_TEXT;?></span></a>
<?php	
		if (ENABLE_MEDIA_MANAGER == "on") {
			echo "<a href=\"?page=m2&amp;popup=1&amp;domain=" . $_REQUEST["ftp"] . "\"class=\"image_manager_lightbox btn blue\"><i></i><span><span></span><i></i><img src=\"images/media_icon.png\" height=\"15\" width=\"15\" border=\"0\" title=\"" . MEDIA_MANAGER_LINK_TEXT . "\" alt=\"" . MEDIA_MANAGER_LINK_TEXT . "\"></span></a>";
		}	
		if (ENABLE_IMAGE_MANAGER == "on") {
			echo "<a href=\"?page=i1&amp;popup=1&amp;domain=" . $_REQUEST["ftp"] . "\"class=\"image_manager_lightbox btn blue\"><i></i><span><span></span><i></i><img src=\"images/img_icon.png\" height=\"15\" width=\"15\" border=\"0\" class=\"none\" title=\"" . IMAGE_MANAGER_LINK_TEXT . "\" alt=\"" . IMAGE_MANAGER_LINK_TEXT . "\"></span></a>";
		}
		if (ENABLE_LINK_MANAGER == "on") {
			echo "<a href=\"?page=l1&amp;popup=1&amp;domain=" . $_REQUEST["ftp"] . "\"class=\"image_manager_lightbox btn blue\"><i></i><span><span></span><i></i><img src=\"images/link_icon.png\" height=\"15\" width=\"15\" border=\"0\" class=\"none\" title=\"" . LINK_MANAGER_LINK_TEXT . "\" alt=\"" . LINK_MANAGER_LINK_TEXT . "\"></span></a>";
		}
?>
		</div>
		
		<h2><?php echo $page_name;?></h2><br><br>
		<?php
		//Load the editing page
		$thepath = explode("/", $remote_file);
		$x = 0;
		while ($x < count($thepath)-1){
			$img_path = $img_path . $thepath[$x] . "/" ;
			$x = $x + 1;
		}
		$editable_regions = 0;
		echo '<form name="editorform" action="index.php" method="post" enctype="multipart/form-data">';
		//Search for the title
		foreach($html->find("title") as $ul) {
			echo "<b>" . PAGE_TITLE_TEXT . "</b>";
			?>
			: <input type="text" name="page_title" size="110" value="<?php echo $ul->innertext;?>"><br>
			<?php
		}
		foreach($html->find('meta[name=description]') as $ul) {
			$ret = $ul->getAttribute("content");
			echo "<b>" . PAGE_DESCRIPTION_TEXT . "</b>";
			?>
			: <input type="text" name="page_description" size="110" value="<?php echo $ul->getAttribute("content");?>"><br>
			<?php
		}
		foreach($html->find('meta[name=keywords]') as $ul) {
			$retk = $ul->getAttribute("content");
			echo "<b>" . PAGE_KEYWORDS_TEXT . "</b>";
			?>
			: <input type="text" name="page_keywords" size="110" value="<?php echo $ul->getAttribute("content");?>"><br>
			<?php
		}
		foreach($html->find($class_search) as $ul) {
		$html_type = "";
			$editable_regions = $editable_regions + 1;
			// If class contains more than the "clienteditor", lets get rid the extra
			$class_text = explode(" ", $ul->getAttribute("class"));
			foreach ($class_text as $c_text) {
				foreach ($class_options as $c_options) {
					if ($c_options == substr($c_text, 0, strlen($c_options))) {
						$class_active = substr($c_text, strlen($c_options));
					}
				}
			}
			//Is there additional info after the class name?
			$custom_editor_height = "";
			$custom_editor_width = "";
			$custom_editor_read_only = false;
			if ($class_active != "") {
				$class_actions = explode("_", $class_active);
				foreach ($class_actions as $c_actions) {
					//This allows for and handles extra class info. eg: clienteditor_bla_bla2_bla3					
					if (strtoupper(substr($c_actions,0,1)) == "W") {
						//Make sure this is actually a width setting
						if (is_numeric(substr($c_actions, 1))) {
							//Define the custom width for the editor
							$custom_editor_width = substr($c_actions, 1);	
						}
					}
					if (strtoupper(substr($c_actions,0,1)) == "H") {
						//Make sure this is actually a height setting
						if (is_numeric(substr($c_actions, 1))) {
							//Define the custom height for the editor
							$custom_editor_height = substr($c_actions, 1);	
						}
					}
					if (strtoupper($c_actions) == "READONLY") {
						//Make editor read only
						$custom_editor_read_only = true;
					}
				}
			}
			
			
			if ($ul->getAttribute("alt") != ""){
				$thetitle = $ul->getAttribute("alt");
				$html_type = "alt";
			}
			if ($ul->getAttribute("id") != ""){
				$thetitle = $ul->getAttribute("id");
				$html_type = "id";
			}
			if ($ul->getAttribute("title") != ""){
				$thetitle = $ul->getAttribute("title");
				$html_type = "title";
			}
			if ($html_type == "") {
				//If no title/id/alt tag exists for us to use to identify this region,
				//We need to create one.
				$html_type = "title";
				//Set the title
				$ul->setAttribute("title", "Editable " . $editable_regions);
				$thetitle = "Editable " . $editable_regions;
				$handle = fopen("temp/" . $filetoedit . ".tmp", 'w+');
				fwrite($handle, $html->save());
				fseek($handle, 0);
				fclose($handle);
			}
			$class_type = $ul->getAttribute("class");
			$titlearray[] = $thetitle;
			?>
			<br><p><b><?php echo $thetitle;?></b>
			<?php
			//Is image?
			if ($ul->tag == "img") {
				//Yes, it is an image
				$display_width = $ul->getAttribute("width");
				$display_height = $ul->getAttribute("height");
				if (($display_height != "") || ($display_width != "")) {
					echo " - <i>" . IMAGE_RESIZE_NOTICE_TEXT . ": ";
					if ($display_width != "") {
						echo WIDTH_TEXT . ": " . $display_width . " ";
					}
					if ($display_height != "") {
						echo HEIGHT_TEXT . ": " . $display_height;
					}
					echo "</i><br>";
				}
				?>
				<img src="includes/phpThumb/phpThumb.php?h=125&amp;&amp;src=<?php echo $ftp->site_url .  substr($img_path,1) . $ul->src; ?>" align="middle" alt="<?php echo $ftp->site_url . $img_path . $ul->src; ?>">
				<LABEL for="firstname"><?php echo IMAGE_TEXT;?>: </LABEL>
				<input type="file" name="image[]"> <?php echo IMAGE_BLANK_NOTICE_TEXT;?>
				<input type="hidden" name="height[<?php echo  $thetitle;?>]" value="<?php echo $ul->getAttribute("height");?>">
				<input type="hidden" name="width[<?php echo  $thetitle;?>]" value="<?php echo $ul->getAttribute("width");?>">
				<input type="hidden" name="isimage[<?php echo  $thetitle;?>]" value="1">
				<?php
			} else {
				//No, no src property found
				$mce_init = $default_mce_init;
				if ($custom_editor_height == "" & $custom_editor_width == "") {
					$mce_init .= ',theme_advanced_resizing : true';
				}
				if ($custom_editor_width == "") {
					$custom_editor_width = "905";
				}
				if ($custom_editor_height == "") {
					$custom_editor_height = "250";
				}
				if ($custom_editor_height != "") {
					$mce_init .= ',height : "'.$custom_editor_height.'"';
				}
				if ($custom_editor_width != "") {
					$mce_init .= ',width : "'.$custom_editor_width.'"';
				}
				if ($custom_editor_read_only) {
					$mce_init .= ',readonly : 1';
				}
				?>
				<script type="text/javascript">
				tinyMCE.init({
					<?php echo $mce_init;?>
				});
				</script>
				<br><center><textarea class="editor_<?php echo $editable_regions;?>" id="<?php echo $thetitle;?>" name="editor[<?php echo $thetitle;?>]"><?php echo $ul->innertext;?>
				</textarea></center><script type="text/javascript">tinyMCE.execCommand('mceAddControl', true, "<?php echo $thetitle;?>");</script>
				<?php				
			}
			?>
			<input type="hidden" name="class[<?php echo $thetitle;?>]" value="<?php echo $class_type;?>">
			<input type="hidden" name="editor1[<?php echo $thetitle; ?>]" value="<?php echo $html_type;?>">
			<input type="hidden" name="edittitle[<?php echo $editable_regions;?>]" value="<?php echo $thetitle;?>">
			
			</p>
			<?php
		}
		if ($editable_regions == 0) {
			echo NO_EDITABLE_FOUND_TEXT . "<br>";
		} else {
			?>
			<p>
			<div id="edittime"><input type="hidden" name="popup" value="1"><input type="hidden" name="edittime" value="yes"></div>
			<input type="hidden" name="rafile" value="<?php echo $filetoedit;?>">
			<input type="hidden" name="editfile" value="<?php echo $_REQUEST["editfile"];?>">
			<input type="hidden" name="ftp" value="<?php echo $_REQUEST["ftp"];?>">
			<div id="preview"></div>
			<input type="hidden" name="page" value="e2">
			<?php
			if ($viewing_preview) {
				echo "<input type=\"hidden\" name=\"image_preview\" value=\"1\">";
				$viewing_preview = false;
			}
			
			$submitval = SUBMIT_TEXT;
			if (isset($_REQUEST["revision"])) {
				$submitval = RESTORE_REVISION_TEXT;
			}
			?></p>
			<a href="#" onclick="document.editorform.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo $submitval;?></span></a>&nbsp;&nbsp;<a href="#" onclick='$("#edittime").html("<input type=hidden name=edittime value=preview>");$("#preview").html("<input type=hidden name=preview id=preview value=1>");document.editorform.submit(); return false' class="btn blue"><i></i><span><span></span><i></i><?php echo PREVIEW_TEXT;?></span></a>
			<br><br>
			<?php
		}
		?>
		</form>
		</div>
		<?php
	} elseif ($_REQUEST["preview"] == "1" & $thefile !="") {
		//Render a preview of the page
		$thepath = explode("/", $remote_file);
		$savepath = $ftp->path;
		$x = 0;
		while ($x < count($thepath)-1){
			$savepath = $savepath . "/" . $thepath[$x];
			$x = $x + 1;
		}
		$image_counter = 0;
		//Replace the title of the page
		foreach($html->find("title") as $ul) {
			$ul->innertext = $_POST["page_title"];	
		}
		//Replace the meta description
		foreach($html->find("meta[name=description]") as $ul) {
			$bla = $ul->setAttribute("content", $_POST["page_description"]);
		}
		//Replace the meta keywords
		foreach($html->find("meta[name=keywords]") as $ul) {
			$bla = $ul->setAttribute("content", $_POST["page_keywords"]);
		}
		//Find the titles we are to edit in the HTML
		foreach($_POST['edittitle'] as $editing) {
			$tofind = "[" . $_POST['editor1'][$editing] . "=" . $editing . "]";
			foreach($html->find($tofind) as $ul) {
				//Is this an image?  We check to see what the form tells us.
				if ($_POST['isimage'][$editing] == 1) {
					$filedir = 'temp/'; // the directory for the original image
					$thumbdir = 'temp/'; // the directory for the thumbnail image
					$prefix = 'small_'; // the prefix to be added to the original name
					$maxfile = '2000000';
					$mode = '0666';			
					$userfile_name = $_FILES['image']['name'][$image_counter];
					$userfile_tmp = $_FILES['image']['tmp_name'][$image_counter];
					$userfile_size = $_FILES['image']['size'][$image_counter];
					$userfile_type = $_FILES['image']['type'][$image_counter];
					$image_counter = $image_counter + 1;
					if ($userfile_name != "") {
						if(!eregi('image/', $userfile_type)){
							$_SESSION['editerror'] .= IMAGE_UPLOAD_INVALID_TYPE_TEXT . "<br>";
						} else {
							//Image uploaded, process...
							$prod_img = $filedir.$userfile_name;
							move_uploaded_file($userfile_tmp, $prod_img);
							chmod ($prod_img, octdec($mode));
							if (($_POST["height"][$editing] != 0) || ($_POST["width"][$editing] != 0)){
								//Height or width found, resize image...
								if (!class_exists('Resize_Image')){
									include 'includes/resize.image.class.php';
								}
								$image = new Resize_Image;
								$image->new_width = $_POST["height"][$editing];
								$image->new_height = $_POST["width"][$editing];
								if ($image->new_width == "") { $image->new_width=0;}
								if ($image->new_height == "") { $image->new_width=0;}
								$image->image_to_resize = $prod_img; // Full Path to the file
								$image->ratio = true; // Keep Aspect Ratio?
								// Name of the new image (optional) - If it's not set a new will be added automatically
								$image->new_image_name = $prefix.$userfile_name;
								// Path where the new image should be saved. If it's not set the script will output the image without saving it //
								$image->save_folder = $thumbdir;
								$process = $image->resize();
								if($process['result'] && $image->save_folder) {
									$prod_img_thumb = $process['new_file_path'];
									//Successful!
								} else {
									//Fail
									$_SESSION['editerror'] .= ERROR_RESIZE_IMAGE_TEXT . '<br>';
								}
							}	
							if ($prod_img_thumb == "") {
								$prod_img_thumb = $prod_img;
							}
							//Do revisioning here, ftp to server.
							$thepathimg = explode("/", $ul->src);
							$image_path_counter = count($thepathimg)-1;
							$ftp->Put($savepath . "/v-cmspreview_" . $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4), $prod_img_thumb, FTP_BINARY);
							$ul->src = "v-cmspreview_" . $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4);
							unlink($prod_img_thumb);
							$prod_img_thumb = "";
						}
					}
				} else {
					//No src found, not an image.
					$ul->innertext = $_POST["editor"][$editing];
				}
			}
		}
		$handle = fopen("temp/" . $filetoedit . ".tmp", 'w+');
		fwrite($handle, $html->save());
		fseek($handle, 0);
		$ftp->Put($savepath . "/v-cmspreview_" . $thepath[$x], $handle, FTP_ASCII);
		$ftp->Close();
		fclose($handle);
		$_REQUEST["preview"] = "";
		$_POST["edittime"] = "preview";
		require("editor.php");
		$noborder = 1;
	} else {
		//Something went wrong, just dump to the home page
		//This was added because if you refreshed the page after submitting
		//The system would write a blank file to the FTP.  It's cheap error handling.
		require('main.php');
		$noborder = 1;
	}
if ($noborder !=1 ) {
	?>
	</div>
	<?php if ($ftperror == 0) {
	?>
		<div id="sidebar" style="z-index:-1;">
		<ul><li><a href="#" onClick="$('#revisions_sidebar').slideToggle('slow', function() {});">
		<h2><?php echo REVISIONS_TEXT;?><img align="top" src="images/e_c.png" alt="+/-" border="0"></h2></a><div style="display:none;" id="revisions_sidebar"><p>
		<?php echo REVISIONS_HOWTO_TEXT;?></p><ul>
		<?php
		$q = "SELECT * FROM revisions WHERE PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID DESC";
		$result = mysql_query($q);
		$revision_counter = 0;
		while ($row = mysql_fetch_array($result)) {
			$revision_counter = $revision_counter + 1;
			$datetime = strtotime($row->createdate);
			echo "<li><a href=\"?page=e2&amp;revision=" . $row["ID"] . "&amp;ftp=" . $_REQUEST["ftp"] . "&amp;editfile=" . $_REQUEST["editfile"] . "\">" . date("m/d/Y g:i a", strtotime($row["TimeStamp"])) . "</a></li>";
		}
		if ($revision_counter == 0) {
			echo NO_REVISIONS_FOUND_TEXT;
		}
		?>	
		</div>
		</ul></li></ul>
		</div>
	<?php
	}
}
?>