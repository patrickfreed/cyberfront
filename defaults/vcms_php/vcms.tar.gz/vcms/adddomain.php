<div style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# adddomain.php - Called when adding a domain

if(!$session->isAdmin()){
	die;
}
if ($_REQUEST["domain"] != "") {
	$ftp_server = $_REQUEST["domain"];
	$ftp_user_name = $_REQUEST["user"];
	$ftp_user_pass = $_REQUEST["pass"];
	$ftp_port = $_REQUEST["port"];
	$ftp_type = $_REQUEST["FTPType"];
	$ftp = new VCMS_FTP;
	$ftp->user_name = $ftp_user_name;
	$ftp->user_pass = $ftp_user_pass;
	$ftp->server = $ftp_server;
	$ftp->port = $ftp_port;
	$ftp->type = $ftp_type;
	$ftp->open();
	
	echo CONNECTION_OK_TEXT . "<br>";
	echo SAVED_TEXT . "...<br>";
	$VCMS_Crypt = new VCMS_Crypt;
	$key = $VCMS_Crypt->pbkdf2(ENCRYPTION_PASSWORD, ENCRYPTION_SALT, 1000, 32) or
		die(KEY_GENERATION_FAILED_TEXT);
	$_REQUEST["pass"] = $VCMS_Crypt->encrypt($_REQUEST["pass"], $key) or
		die(ENCRYPTION_FAILED_TEXT);
	if (substr($_REQUEST["site_url"], strlen($_REQUEST["site_url"])-1,1) != "/") {
		$_REQUEST["site_url"] = $_REQUEST["site_url"] . "/";
	}
	if (substr(strtolower($_REQUEST["site_url"]), 0, 4) != "http") {
		$_REQUEST["site_url"] = "http://" . $_REQUEST["site_url"];
	}

	$q = "INSERT INTO domains (Name, ftp, UserName, Password, SiteURL, Path, ImagePath, LinkPath, MediaPath, CustomCSS, InlineEditor, FTPType, Port) VALUES ('" . mysql_real_escape_string($_REQUEST["domain"]) . "','" . mysql_real_escape_string($_REQUEST["domain"]) . "','" . mysql_real_escape_string($_REQUEST["user"]) . "','" . $_REQUEST["pass"] . "','" . mysql_real_escape_string($_REQUEST["site_url"]) . "','" . mysql_real_escape_string($_REQUEST["path"]) . "','" . mysql_real_escape_string($_REQUEST["imagepath"]) . "','" . mysql_real_escape_string($_REQUEST["linkpath"]) . "','" . mysql_real_escape_string($_REQUEST["mediapath"]) . "','" . mysql_real_escape_string($_REQUEST["CustomCSS"]) . "','" . mysql_real_escape_string($_REQUEST["InlineEditor"]) . "','" . mysql_real_escape_string($_REQUEST["FTPType"]) . "','" . mysql_real_escape_string($_REQUEST["port"]) . "')";
    $result = mysql_query($q);
	$_REQUEST["domain"] = mysql_insert_id();
	$path_query = "";
	if ($_REQUEST["linkpath"] == "") {
		$path_query = "LinkPath = \"" . $_REQUEST["domain"] . "cms_links\"";
	}
	if ($_REQUEST["imagepath"] == "") {
		if ($path_query != "") {
			$path_query = $path_query . ", ";
		}
		$path_query = $path_query . "ImagePath = \"" . $_REQUEST["domain"] . "cms_images\"";
	}
	if ($_REQUEST["mediapath"] == "") {
		if ($path_query != "") {
			$path_query = $path_query . ", ";
		}
		$path_query = $path_query . "MediaPath = \"" . $_REQUEST["domain"] . "cms_media\"";
	}
	if ($path_query != "") {
		$path_query = "UPDATE domains SET " . $path_query . " WHERE ID = '" . $_REQUEST["domain"] . "'";
		$result = mysql_query($path_query);
	}
	$q = "INSERT INTO permissions (UserID, Type, Permission) VALUES ('" . $session->user_db_id . "','Domain','" . $_REQUEST["domain"] . "')";
	$result = mysql_query($q);
	$noborder=1;
	require("addfile.php");
	$noborder=0;
	$no_domain_form=1;
}
echo "<font color=red>" . $ftperror . "</font><br>";
if ($no_domain_form!=1){
	?>
	<div id="register">
	<h1><?php echo ADD_NEW_SITE_TEXT;?></h1>
	<div class="form_main">
	<form method="POST" name="add_domain">
	<div class="form_a"><div class="form_left"><?php echo SITE_URL_TEXT;?>:</div><div class="form_right"><input size="45" type="text" name="site_url"></div></div>
	<div class="form_a"><div class="form_left"><?php echo CUSTOM_CSS_TEXT;?>:</div><div class="form_right"><input size="45" type="text" id="CustomCSS" name="CustomCSS"></div></div>
	<div class="form_a"><div class="form_left"><?php echo FTP_SERVER_TEXT;?>:</div><div class="form_right"><select id="FTPType" name="FTPType">
	<option value="ftp">FTP</option>
	</select>://<input size="35" type="text" id="domain" name="domain"> Port: <input size="3" type="text" id="port" name="port" value="21"></div></div>
	<div class="form_a"><div class="form_left"><?php echo USER_NAME_TEXT;?>:</div><div class="form_right"><input size="45" type="text" name="user" id="user"></div></div>
	<div class="form_a"><div class="form_left"><?php echo PASSWORD_TEXT;?>:</div><div class="form_right"><input size="45" type="password" id="pass" name="pass"></div></div>
	<?php
if (ENABLE_INLINE_EDITOR == "on") {
?>
	<div class="form_a"><div class="form_left"><?php echo ENABLE_INLINE_EDITOR_TEXT;?>:</div><div class="form_right"><input type="checkbox" id="InlineEditor" name="InlineEditor" checked></div></div>
	<?php
	}
	?>
	<div class="form_a"><div class="form_left"><?php echo PATH_TEXT;?>:</div><div class="form_right"><input size="45" type="text" id="path" name="path" onClick="getchoose_path('<?php echo $_REQUEST["path"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
	<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_path"></div></div></div>
	<div class="form_a"><div class="form_left"><?php echo IMAGE_PATH_TEXT;?>:</div><div class="form_right"><input size="45" type="text" id="imagepath" name="imagepath" onClick="getchoose_image_path('<?php echo $_REQUEST["imagepath"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
	<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_image_path"></div></div></div>
	<div class="form_a"><div class="form_left"><?php echo LINK_PATH_TEXT;?>:</div><div class="form_right"><input size="45" type="text" id="linkpath" name="linkpath" onClick="getchoose_link_path('<?php echo $_REQUEST["linkpath"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
	<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_link_path"></div></div></div>
	<div class="form_a"><div class="form_left"><?php echo MEDIA_PATH_TEXT;?>:</div><div class="form_right"><input size="45" type="text" id="mediapath" name="medapath" onClick="getchoose_media_path('<?php echo $_REQUEST["mediapath"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
	<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_media_path"></div></div></div>
	<div class="form_a"><div class="form_left"></div><div class="form_right"><a href="#" onclick="document.add_domain.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo ADD_NEW_SITE_TEXT;?></span></a></div></div>
	<br><br>
	</form>
	</div>
	</div>
	</div>
	</div>
	<div id="sidebar">
	<ul><li><h2><?php echo ADD_NEW_SITE_TEXT;?></h2>
	<?php echo ADD_DOMAIN_PAGE_RIGHT_TEXT;?>
	</ul></li></ul></div>
	<script type="text/javascript">
	$.extend($.fn, {
		fileTree: function(o, h) {
			// Defaults
			if( !o ) var o = {};
			if( o.root == undefined ) o.root = '';
			if( o.script == undefined ) o.script = 'includes/addfile.php';
			if( o.folderEvent == undefined ) o.folderEvent = 'click';
			if( o.expandSpeed == undefined ) o.expandSpeed= 500;
			if( o.collapseSpeed == undefined ) o.collapseSpeed= 500;
			if( o.expandEasing == undefined ) o.expandEasing = null;
			if( o.collapseEasing == undefined ) o.collapseEasing = null;
			if( o.multiFolder == undefined ) o.multiFolder = true;
			if( o.loadMessage == undefined ) o.loadMessage = 'Loading...';

			$(this).each( function() {
				
				function showTree(c, t) {
					$(c).addClass('wait');
					//$(".jqueryFileTree.start").remove();
					$.post(o.script, { path: t, domain: "<?php echo $_REQUEST["domain"];?>", selectedfile: "<?php echo $_REQUEST["selectedfile"];?>", activepage: "<?php echo $_REQUEST["activepage"];?>" }, function(data) {
						$(c).find('.start').html('');
						$(c).removeClass('wait').append(data);
						if( o.root == t ) $(c).find('UL:hidden').show(); else $(c).find('UL:hidden').slideDown({ duration: o.expandSpeed, easing: o.expandEasing });
						bindTree(c);
					});
				}
				
				function bindTree(t) {
					$(t).find('LI A').bind(o.folderEvent, function() {
						if( $(this).parent().hasClass('directory') ) {
							
							if (o.form != 'path') {
								toreturn = $(this).attr('rel').slice(0,$(this).attr('rel').length-1);
								toreturn = toreturn.replace(document.getElementById('path').value + "/", '');
							} else {
								toreturn = $(this).attr('rel').slice(0,$(this).attr('rel').length-1);
							}
							eval("document.forms['add_domain']." + o.form + ".value = toreturn");
							if( $(this).parent().hasClass('collapsed') ) {
								// Expand
								if( !o.multiFolder ) {
									$(this).parent().parent().find('UL').slideUp({ duration: o.collapseSpeed, easing: o.collapseEasing });
									$(this).parent().parent().find('LI.directory').removeClass('expanded').addClass('collapsed');
								}
								$(this).parent().find('UL').remove(); // cleanup
								showTree( $(this).parent(), escape($(this).attr('rel').match( /.*\// )) );
								$(this).parent().removeClass('collapsed').addClass('expanded');
							} else {
								// Collapse
								$(this).parent().find('UL').slideUp({ duration: o.collapseSpeed, easing: o.collapseEasing });
								$(this).parent().removeClass('expanded').addClass('collapsed');
							}
						} else {
							h($(this).attr('rel'));
						}
						return false;
					});
					// Prevent A from triggering the # on non-click events
					if( o.folderEvent.toLowerCase != 'click' ) $(t).find('LI A').bind('click', function() { return false; });
				}
				// Loading message
				
				$(this).html('<ul class="jqueryFileTree start"><li class="wait">' + o.loadMessage + '<li></ul>');
				// Get the initial file list
				showTree( $(this), escape(o.root) );
			});
		}
	});
	function getchoose_path(path, domain, selectedfile, activepage) {
	$('#choose_path').fileTree({ form: 'path', root: '', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', script: 'includes/choose_path.php?Password=' + document.getElementById('pass').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value + '&ftp=' + document.getElementById('domain').value + '&User=' + document.getElementById('user').value + '&path=' + path +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
       
    });
	}
	function getchoose_image_path(imagepath, domain, selectedfile, activepage) {
		$('#choose_image_path').fileTree({ form: 'imagepath', root: '', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', script: 'includes/choose_image_path.php?docroot=' + document.getElementById('path').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value + '&Password=' + document.getElementById('pass').value +'&ftp=' + document.getElementById('domain').value + '&User=' + document.getElementById('user').value + '&path=' + imagepath +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
    });
	}
	function getchoose_link_path(linkpath, domain, selectedfile, activepage) {
	$('#choose_link_path').fileTree({ form: 'linkpath', root: '', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', script: 'includes/choose_link_path.php?docroot=' + document.getElementById('path').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value + '&Password=' + document.getElementById('pass').value +'&ftp=' + document.getElementById('domain').value + '&User=' + document.getElementById('user').value + '&path=' + linkpath +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
       
    });
	}
	function getchoose_media_path(mediapath, domain, selectedfile, activepage) {
	$('#choose_media_path').fileTree({ form: 'mediapath', root: '', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', script: 'includes/choose_media_path.php?docroot=' + document.getElementById('path').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value + '&Password=' + document.getElementById('pass').value +'&ftp=' + document.getElementById('domain').value + '&User=' + document.getElementById('user').value + '&path=' + mediapath +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
       
    });
	}
	</script>
<?php
}
?>