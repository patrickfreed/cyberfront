<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# inline_editor.php - The inline editor
?>
<script type="text/javascript">
    if (parent.$("#colorbox").css("display")=="block") {  
          
    }else{  
        window.location = 'index.php';  
    }  
</script>
<?php
//Security Check
if(!$session->logged_in){
	die;
}
//Quick Temp Directory Cleanup
foreach (glob("temp/*") as $Filename) {
    // Read file creation time
    $FileCreationTime = filectime($Filename);
    // Calculate file age in seconds
    $FileAge = time() - $FileCreationTime; 
    // Is the file older than 7200 seconds (2 hours)?
    if ($FileAge > (7200)){
		if ($Filename <> "temp/index.php") {
			unlink($Filename);
		}
    }
}

//File Injection prevention
$replace_array = array("/", "\\", "..");
$_REQUEST["rafile"] = str_replace($replace_array, "", $_REQUEST["rafile"]);
$_REQUEST["editfile"] = str_replace($replace_array, "", $_REQUEST["editfile"]);

//SQL Injection prevention
$_REQUEST["editfile"] = mysql_real_escape_string($_REQUEST["editfile"]);
if (!domain_permission_check($_REQUEST["ftp"])) {
	die;
}
if (!page_permission_check($_REQUEST["editfile"])) {
	die;
}

//Define the allowed classes and apend any custom classes
$class_search = "[class^=clienteditor],[class^=cushycms],[class^=editable]";
$class_options[] = "clienteditor";
$class_options[] = "cushycms";
$class_options[] = "editable";
if (defined('CUSTOM_CLASS_1')) {
	$class_search = $class_search . ",[class^=" . CUSTOM_CLASS_1 . "]";
	$class_options[] = CUSTOM_CLASS_1;
}
if (defined('CUSTOM_CLASS_2')) {
	$class_search = $class_search . ",[class^=" . CUSTOM_CLASS_2 . "]";
	$class_options[] = CUSTOM_CLASS_2;
}
$class_exclude_search = str_replace("^", "!=", $class_search);
//Load all the FTP info
$ftp_error = 0;
$ftp = new VCMS_FTP;
$ftp->GetDomainInfo($_REQUEST["ftp"]);

$ftp->Open();
//If no FTP error is found, begin the process
	//Get page info
	$q = "SELECT * FROM pages WHERE ID = \"" . mysql_real_escape_string($_REQUEST["editfile"]) . "\"";
	$result = mysql_query($q);
	while ($row = mysql_fetch_array($result)){
		$remote_file = $row["Path"] . $revision;
		$page_name = $row["Name"];
		$custom_css = $row["CustomCSS"];
	}
	//If CSS is not set for this page, use the site-wide setting
	if ($custom_css == "") {
		$custom_css = $site_custom_css;
	}
	//If we are not applying an edit, then get the remote file
	if ($_REQUEST["edittime"] == "") {
		$random_id = $_REQUEST["ftp"] . rand(1000, 999999);
		$handle = fopen("temp/" . $random_id . ".tmp", 'w');
		if (!$ftp->GetFile($handle, $ftp->path . $remote_file, FTP_ASCII)) {
			echo FTP_ERROR_GET_PAGE_ERROR_TEXT;
		}
		$ftp->Close();
		fclose($handle);
	} else {
		//We are applying an edit, store the random number given for the filename
		$random_id = $_REQUEST["rafile"];
	}
	
	//Start processing the page for HTML
	$filetoedit = $random_id;
	//Without the following DOM Paraser, none of this would be possible!
	//Website: http://sourceforge.net/projects/simplehtmldom/
	if (!function_exists("file_get_html")){
		include('includes/simple_html_dom.php');
	}
	//Read the file
	$thefile = file_get_contents("temp/" . $filetoedit . ".tmp");
	$html = str_get_html($thefile);
	//If we are editing and the temp file was read correctly then...
	if (($_POST['edittime'] == "yes") && ($thefile !="")) {
	$edittitle_inline_array = explode("vcms_~_vcms", $_POST["edittitle_inline"]);
	foreach ($edittitle_inline_array as $arr => $value){
		$edittitle_inline_array_value = explode("vcms_;_vcms", $value);
		$edittitle_inline_array_value[1] = str_replace("vcms_vcms", " ", $edittitle_inline_array_value[1]);
		$_POST["edittitle"][$edittitle_inline_array_value[0]] = $edittitle_inline_array_value[1];
	}
	$editor1_inline_array = explode("vcms_~_vcms", $_POST["editor1_inline"]);
	foreach ($editor1_inline_array as $arr => $value){
		$editor1_inline_array_value = explode("vcms_;_vcms", $value);
		$editor1_inline_array_value[0] = str_replace("vcms_vcms", " ", $editor1_inline_array_value[0]);
		$_POST["editor1"][$editor1_inline_array_value[0]] = $editor1_inline_array_value[1];
	}	$class_inline_array = explode("vcms_~_vcms", $_POST["class_inline"]);
	foreach ($class_inline_array as $arr => $value){
		$class_inline_array_value = explode("vcms_;_vcms", $value);
		$class_inline_array_value[0] = str_replace("vcms_vcms", " ", $class_inline_array_value[0]);
		$_POST["class"][$class_inline_array_value[0]] = $class_inline_array_value[1];
	}

	$editor_inline_array = explode("vcms_~_vcms", $_POST["editor_inline"]);
	foreach ($editor_inline_array as $arr => $value){
		$editor_inline_array_value = explode("vcms_;_vcms", $value);
		$editor_inline_array_value[0] = str_replace("vcms_vcms", " ", $editor_inline_array_value[0]);
		$_POST["editor"][$editor_inline_array_value[0]] = $editor_inline_array_value[1];
	}

	$isimage_inline_array = explode("vcms_~_vcms", $_POST["isimage_inline"]);
	foreach ($isimage_inline_array as $arr => $value){
		$isimage_inline_array_value = explode("vcms_;_vcms", $value);
		$isimage_inline_array_value[0] = str_replace("vcms_vcms", " ", $isimage_inline_array_value[0]);
		$_POST["isimage"][$isimage_inline_array_value[0]] = $isimage_inline_array_value[1];
	}
		//Save the changes
		$thepath = explode("/", $remote_file);
		$savepath = $ftp->path;
		$x = 0;
		while ($x < count($thepath)-1){
			$savepath = $savepath . "/" . $thepath[$x];
			$x = $x + 1;
		}
		$image_counter = 0;
		//Replace the title of the page
		if ($_POST["page_title"] != "") {
			foreach($html->find("title") as $ul) {
				$ul->innertext = $_POST["page_title"];	
			}
		}
		//Replace the meta description
		if ($_POST["page_description"] != "") {
			foreach($html->find("meta[name=description]") as $ul) {
				$bla = $ul->setAttribute("content", $_POST["page_description"]);
			}
		}
		//Replace the meta keywords
		if ($_POST["page_keywords"] != "") {
			foreach($html->find("meta[name=keywords]") as $ul) {
				$bla = $ul->setAttribute("content", $_POST["page_keywords"]);
			}
		}
		//Find the titles we are to edit in the HTML
		
		foreach($_POST['edittitle'] as $editing) {
			$tofind = "[" . $_POST['editor1'][$editing] . "=" . $editing . "]";
			foreach($html->find($tofind) as $ul) {
				//Is this an image?  We check to see what the form tells us.
				if ($_POST['isimage'][$editing] == 1) {
					//Do revisioning here, ftp to server.
					$thepathimg = explode("/", $ul->src);
					$image_path_counter = count($thepathimg)-1;
					$prod_img_thumb = substr($_POST["editor"][$editing],1);
					$ftp->Put($savepath . "/" . $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4), $prod_img_thumb, FTP_BINARY);
					$ul->src = $filetoedit . str_replace(" ","_",$editing) . substr($thepathimg[$image_path_counter], - 4);
					//Update the revision database
					$q = "INSERT INTO img_revisions (PageID, Path, ImgID) VALUES ('" . $_REQUEST["editfile"] . "','" . mysql_real_escape_string($ul->src) . "','" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "')";
					$result = mysql_query($q);
					//Check revision database, remove excess pages
					$q = "SELECT * FROM img_revisions WHERE ImgID = \"" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "\" AND PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID";
					$result = mysql_query($q);
					if (mysql_num_rows($result) > ALLOWED_REVISIONS) {
						$q2 = "SELECT * FROM img_revisions WHERE ImgID = \"" . mysql_real_escape_string($ul->getAttribute($_POST['editor1'][$editing])) . "\" AND PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID LIMIT 1";
						$result2 = mysql_query($q2);
						while ($row2 = mysql_fetch_array($result2)){
							$ftp->Delete($savepath . "/" . $row2["Path"]);
							$q = "DELETE FroM img_revisions WHERE ID = " . $row2["ID"];
							$result = mysql_query($q);
						}
					}
					unlink($prod_img_thumb);
					$prod_img_thumb = "";
				}else {
					//No src found, not an image.
					$ul->innertext = $_POST["editor"][$editing];
				}
			}
		}
		$handle = fopen("temp/" . $filetoedit . "temp", 'w+');
		fwrite($handle, $html->save());
		fseek($handle, 0);
		$ftp->Rename($savepath . "/" . $thepath[$x], $savepath . "/" . $thepath[$x] . "_" . $filetoedit);
		$ftp->Put($savepath . "/" . $thepath[$x], $handle, FTP_ASCII);
		//Cleanup any preview files
		$ftp_nlist = $ftp->NList($savepath);
		if (!Empty($ftp_nlist)) {
			foreach ($ftp_nlist as $v) {
				if (substr($v, 0, 12) == "v-cmspreview"){
					$ftp->Delete($v);
				}
			}
		}
		//Update the revision database
		$q = "INSERT INTO revisions (PageID, Path) VALUES ('" . $_REQUEST["editfile"] . "','" . $filetoedit . "')";
		$result = mysql_query($q);
		//Check revision database, remove excess pages
		$q = "SELECT * FROM revisions WHERE PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID";
		$result = mysql_query($q);
		if (mysql_num_rows($result) > ALLOWED_REVISIONS) {
			$q2 = "SELECT * FROM revisions WHERE PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID";
			$result2 = mysql_query($q2);
			$y = 0;
			while ($row2 = mysql_fetch_array($result2)){
				if ($y == 0) {
					$ftp->Delete($savepath . "/" . $thepath[$x] . "_" . $row2["Path"]);
					$q = "DELETE FroM revisions WHERE ID = " . $row2["ID"];
					$result = mysql_query($q);
				}
				$y = 1;
			}
		}
		$ftp->Close();
		fclose($handle);
		unlink("temp/" . $filetoedit . ".tmp");
		unlink("temp/" . $filetoedit . "_inline.html");
		echo "<script type=\"text/javascript\">parent.$.colorbox.close();</script>";
		die;
		$noborder=1;

	} elseif ($thefile !="") {
		//Time to display the editor, and the temp file was read correctly.
		//Are there any editable regions?
		$regions = $html->find($class_search);
		if (empty($regions)) {
			echo '<script language="javascript" type="text/javascript">
					alert("' . NO_EDITABLE_FOUND_TEXT . '");
					parent.$.colorbox.close();
				</script>';
			die;
		}
		foreach($html->find($class_search) as $ul) {
			$editable_regions = 1;
		}
		//Remove java from the page, things link onmoveover and onclick can break the CMS
		$inline_java_clean = array("onclick", "onblur","onchange","onclick", "ondblclick" , "onerror","onfocus","onkeydown","onkeypress","onkeyup","onmousedown","onmousemove","onmouseout","onmouseover","onmouseup","onresize","onselect","onunload");
		foreach ($inline_java_clean as $clean) {
			foreach ($html->find("[" . $clean . "]") as $ul) {
				$ul->$clean="";
			}
		}
		
		$default_mce_init = 'script_url : "'.BASE_URL.'/includes/tiny_mce/tiny_mce.js",
						theme : "advanced",
						plugins : "save,spellchecker,pagebreak,style,layer,table,advhr,advimage,advlink,iespell,inlinepopups,insertdatetime,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras",
						theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,forecolor,backcolor,|,media,image,link,unlink,anchor",
						theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,hr,removeformat,visualaid",
						theme_advanced_buttons3 : "onbreaking,pagebreak,|,ltr,rtl,|,charmap,iespell,advhr,|,fullscreen,print,cleanup,code,|,save, cancel",
						theme_advanced_buttons4 : "",
						save_onsavecallback : "save_" + divtitle,
						save_oncancelcallback : "cancel_" + divtitle,
						theme_advanced_toolbar_location : "top",
						theme_advanced_toolbar_align : "center",
						theme_advanced_statusbar_location : "bottom",
						readonly : custom_editor_read_only,
						media_types : "flash=swf;shockwave=dcr;qt=mov,qt,mpg,mp3,mp4,mpeg;shockwave=dcr;wmp=avi,wmv,wm,asf,asx,wmx,wvx"
						';
		if (ENABLE_IMAGE_MANAGER == "on") {
			$default_mce_init .= ",external_image_list_url : \"" . BASE_URL . "/includes/get_images.php?domain=" . $_REQUEST["ftp"] . "\"
			";
		}
		if (ENABLE_IMAGE_MANAGER == "on") {
			$default_mce_init .= ",external_link_list_url : \"" . BASE_URL . "/includes/get_links.php?domain=" . $_REQUEST["ftp"] . "\"
			";
		}
		if (ENABLE_LINK_MANAGER == "on") {
			$default_mce_init .= ",media_external_list_url : \"" . BASE_URL . "/includes/get_media.php?domain=" . $_REQUEST["ftp"] . "\"
			";
		}
		if ($custom_css != "") {
			$default_mce_init .= ",content_css : \"" . $custom_css . "\"";
		}
		foreach($html->find("title") as $ul) {
			$page_title = $ul->innertext;	
		}
		foreach($html->find('meta[name=description]') as $ul) {
			$page_description = $ul->getAttribute("content");
		}
		foreach($html->find('meta[name=keywords]') as $ul) {
			$page_keywords = $ul->getAttribute("content");
		}
		require('includes/inline_editor.php');
		foreach($html->find("head") as $ul) {
			$head = $ul->innertext;
			$ul->innertext = $out . $head;	
		}
		$page_options = "";
		
								
		if (ENABLE_MEDIA_MANAGER == "on") {
			$page_options .= '<div id="media_manager_dropdown" class="vcms_inline media_manager_dropdown" style="border: 1px black solid; height:400px; width:955px; padding: 5px;background-color:#ffffff;position: absolute;display:none;">
		<iframe width="100%" height="100%" src="' . BASE_URL . '/?page=m2&amp;inline=1&amp;popup=1&amp;domain=' . $_REQUEST["ftp"] . '"></iframe>
				</div>';
		}	
		if (ENABLE_IMAGE_MANAGER == "on") {
			$page_options .= '<div id="image_manager_dropdown" class="vcms_inline image_manager_dropdown" style="border: 1px black solid; height:400px; width:955px; padding: 5px;background-color:#ffffff;position: absolute;display:none;">
		<iframe width="100%" height="100%" src="' . BASE_URL . '/?page=i1&amp;inline=1&amp;popup=1&amp;domain=' . $_REQUEST["ftp"] . '"></iframe>
				</div>';
		}
		if (ENABLE_LINK_MANAGER == "on") {
			$page_options .= '<div id="link_manager_dropdown" class="vcms_inline link_manager_dropdown" style="border: 1px black solid; height:400px; width:955px; padding: 5px;background-color:#ffffff;position: absolute;display:none;">
		<iframe width="100%" height="100%" src="'. BASE_URL . "/?page=l1&amp;inline=1&amp;popup=1&amp;domain=" . $_REQUEST["ftp"] . '"></iframe>
				</div>';
		}
		
		if (ENABLE_MEDIA_MANAGER == "on") {
			$page_options .= '<div id="media_manager_dropdown" class="vcms_inline media_manager_dropdown" style="border: 1px black solid; height:400px; width:955px; padding: 5px;background-color:#ffffff;position: absolute;display:none;">
		<iframe width="100%" height="100%" src="' . BASE_URL . '/?page=m2&amp;inline=1&amp;popup=1&amp;domain=' . $_REQUEST["ftp"] . '"></iframe>
				</div>';
			$page_options .= "<a onClick=\"$('#media_manager_dropdown').slideToggle('slow'); return false;\" href=\"#\" class=\"vcms_inline\"><img class=\"vcms_inline\" style=\"margin: 5px;border:1px grey solid;\" src=\"" . BASE_URL . "/images/media_icon.png\" height=\"15\" width=\"15\" border=\"0\" title=\"" . MEDIA_MANAGER_LINK_TEXT . "\" alt=\"" . MEDIA_MANAGER_LINK_TEXT . "\"></a>";
		}	
		if (ENABLE_IMAGE_MANAGER == "on") {
			$page_options .= '<div id="image_manager_dropdown" class="vcms_inline image_manager_dropdown" style="border: 1px black solid; height:400px; width:955px; padding: 5px;background-color:#ffffff;position: absolute;display:none;">
		<iframe width="100%" height="100%" src="' . BASE_URL . '/?page=i1&amp;inline=1&amp;popup=1&amp;domain=' . $_REQUEST["ftp"] . '"></iframe>
				</div>';
			$page_options .="<a onClick=\"$('#image_manager_dropdown').slideToggle('slow'); return false;\" href=\"#\" class=\"vcms_inline\"><img class=\"vcms_inline\" style=\"margin: 5px;border:1px grey solid;\" src=\"" . BASE_URL . "/images/img_icon.png\" height=\"15\" width=\"15\" border=\"0\" class=\"none\" title=\"" . IMAGE_MANAGER_LINK_TEXT . "\" alt=\"" . IMAGE_MANAGER_LINK_TEXT . "\"></a>";
		}
		if (ENABLE_LINK_MANAGER == "on") {
			$page_options .= '<div id="link_manager_dropdown" class="vcms_inline link_manager_dropdown" style="border: 1px black solid; height:400px; width:955px; padding: 5px;background-color:#ffffff;position: absolute;display:none;">
		<iframe width="100%" height="100%" src="'. BASE_URL . "/?page=l1&amp;inline=1&amp;popup=1&amp;domain=" . $_REQUEST["ftp"] . '"></iframe>
				</div>';
			$page_options .= "<a onClick=\"$('#link_manager_dropdown').slideToggle('slow'); return false;\" href=\"#\"  class=\"vcms_inline\"><img class=\"vcms_inline\" style=\"margin: 5px;border:1px grey solid;\" src=\"" . BASE_URL . "/images/link_icon.png\" height=\"15\" width=\"15\" border=\"0\" class=\"none\" title=\"" . LINK_MANAGER_LINK_TEXT . "\" alt=\"" . LINK_MANAGER_LINK_TEXT . "\"></a>";
		}
		$inline_edit_options_window = '<div class="vcms_inline" id="draggable" style="z-index:1000;background:#ffffff; width:90px; padding:5px;text-align: center;position: fixed;top: 15px;left: 15px; border:1px grey solid;">
		<div class="vcms_inline" style="background:#ffffff;padding:3px;position:absolute;margin:-14px;border:1px grey solid;"><img class="vcms_inline" src="'.BASE_URL.'/images/move_icon.png" title="'.MOVE_TEXT.'" alt="'.MOVE_TEXT.'"></div>
		<a class="vcms_inline" href="#" onclick="savechanges();return false;"><img class="vcms_inline" style="margin: 5px;border:1px grey solid;" src="'.BASE_URL.'/images/save_icon.png" title="'.SAVE_TEXT.'" alt="'.SAVE_TEXT.'" border="0"></a><a  class="vcms_inline" href="#" onclick="parent.$.colorbox.close();return false;"><img class="vcms_inline" style="margin: 5px;border:1px grey solid;" src="'.BASE_URL.'/images/cancel_icon.png" title="'.CANCEL_TEXT.'" alt="'.CANCEL_TEXT.'" border="0"></a><br>'.$page_options.'<hr><div id="title_editor" class="vcms_inline title_editor" style="border: 1px black solid; width:555px; padding: 5px;background-color:#ffffff;position: absolute;display:none;">
		<div class="vcms_inline" style="position:absolute;"><a class="vcms_inline" href="#" onclick="save_title_description();return false;"><img class="vcms_inline" style="margin: 5px;border:1px grey solid;" src="'.BASE_URL.'/images/save_icon.png" title="'.SAVE_TEXT.'" alt="'.SAVE_TEXT.'" border="0"></a><a  class="vcms_inline" href="#" onclick="$(\'#title_editor\').slideToggle(\'slow\');return false;"><img class="vcms_inline" style="margin: 5px;border:1px grey solid;" src="'.BASE_URL.'/images/cancel_icon.png" title="'.CANCEL_TEXT.'" alt="'.CANCEL_TEXT.'" border="0"></a></DIV>
		<div class="form_main">
			<div class="form_a">
				<div class="vcms_inline form_left">'.PAGE_TITLE_TEXT.':</div>
				<div class="vcms_inline form_right"><input type="text" name="title" id="title" class="vcms_inline" size="60" value="'.$page_title.'"></div>
			</div>
		</div>
		<br>
		<div class="form_main">
			<div class="form_a">
				<div class="vcms_inline form_left">'.PAGE_DESCRIPTION_TEXT.':</div>
				<div class="vcms_inline form_right"><input type="text" name="description" id="description" class="vcms_inline" size="60" value="'.$page_description.'"></div>
			</div>
		</div>
		<br>
		<div class="form_main">
			<div class="form_a">
				<div class="vcms_inline form_left">'.PAGE_KEYWORDS_TEXT.':</div>
				<div class="vcms_inline form_right"><input type="text" name="keywords" id="keywords" class="vcms_inline" size="60" value="'.$page_keywords.'"></div>
			</div>
		</div>
		</div>
				
		<a class="vcms_inline" href="#" onClick="$(\'#title_editor\').slideToggle(\'slow\'); return false;"><div class="vcms_inline" style="font-size:10px;line-height:9px;text-decoration:underline;">'.EDIT_TITLE_DESCRIPTION_TEXT.'</div></a></div>
';
				
		foreach ($html->find("body") as $ul){
			$ul->innertext = $inline_edit_options_window . $ul->innertext;
		}
		
		$handle = fopen("temp/" . $filetoedit . "_inline.html", 'w+');
		fwrite($handle, $html->save());
		fclose($handle);
		?>
		<script type="text/javascript">function update_title(title){$('.te_title').html(title);}</script>
		<?php
		include('temp/' . $filetoedit . '_inline.html');
		die;
		require('main.php');
		$noborder=1;	

	} else {
		//Something went wrong, just dump to the home page
		//This was added because if you refreshed the page after submitting
		//The system would write a blank file to the FTP.  It's cheap error handling.
		require('main.php');
		$noborder=1;
	}
if ($noborder!=1) {
	?>
	</div>
	<?php if ($ftperror == 0) {
	?>
		<div id="sidebar" style="z-index:-1;">
		<ul><li><a href="#" onClick="$('#revisions_sidebar').slideToggle('slow', function() {});">
		<h2><?php echo REVISIONS_TEXT;?><img align="top" src="images/e_c.png" alt="+/-" border="0"></h2></a><div style="display:none;" id="revisions_sidebar"><p>
		<?php echo REVISIONS_HOWTO_TEXT;?></p><ul>
		<?php
		$q = "SELECT * FROM revisions WHERE PageID = \"" . $_REQUEST["editfile"] . "\" ORDER BY ID DESC";
		$result = mysql_query($q);
		while ($row = mysql_fetch_array($result)) {
		$datetime = strtotime($row->createdate);
			echo "<li><a href=\"?page=e2&amp;popup=1&amp;revision=" . $row["ID"] . "&amp;ftp=" . $_REQUEST["ftp"] . "&amp;editfile=" . $_REQUEST["editfile"] . "\">" . date("m/d/Y g:i a", strtotime($row["TimeStamp"])) . "</a></li>";
		}
		?>	
		</div>
		</ul></li></ul>
		</div>
	<?php
	}
}
?>