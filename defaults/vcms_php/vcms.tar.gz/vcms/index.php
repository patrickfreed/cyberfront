<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# index.php - The main wrapper for V-CMS, all files/functions should
#	be called via this file
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
$time = microtime();
$time = explode(" ", $time);
$time = $time[1] + $time[0];
$start = $time;

define("VCMS_VERSION", "1.0");
(include('includes/config.php')) or die("Cannot find includes/config.php");
if ($_SERVER['HTTPS'] != "on" && USE_SSL == 1) {
    $url = BASE_URL;
    header("Location: $url");
    exit;
}  
include("includes/session.php");
include("includes/languages/" . LANGUAGE_FILE . ".php");
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
MySQL_select_db(DB_NAME) or die(DATABASE_SELECT_ERROR_TEXT);
$query = "SELECT * FROM configuration";
$result = mysql_query($query);
if ($result) {
	while ($row = mysql_fetch_array($result)) {
		if ($row["value"] != "") {
			define($row["name"], $row["value"]);
		}
	}
}

if (!defined('SITE_NAME')) {
	define("SITE_NAME", "V-CMS");
	define("TAGLINE", "A Completely Open Source Simple CMS");
	define("LOGO_IMAGE", "images/logo.png");
	define("BACKGROUND_CSS", "#F5F5F5 url(images/img01.jpg) repeat-x left top");
	define("HEADER_COLOR", "#AA2808");
	define("BUTTON_BACKGROUND", "#22aaee");
	define("BUTTON_COLOR", "#ffffff");
	define("BUTTON_HOVER_BACKGROUND", "#aa0000");
	define("BUTTON_HOVER_COLOR", "#ffffff");
	define("BUTTON_ACTIVE_BACKGROUND", "#444444");
	define("BUTTON_ACTIVE_COLOR", "#ffffff");
	if (!isset($_REQUEST["page"])) {
		$_REQUEST["page"] = "install";
	}
}
require('includes/v-cms.php');
require('includes/header.php');
if (defined('VCMS_INSTALLED_VERSION')) {
	if (VCMS_VERSION > VCMS_INSTALLED_VERSION) {
		$_REQUEST["page"] = "u3";
	}
}
$page = "main.php";
if ($_GET["page"] == "f1") {
	$valid = "yes";
	require("forgotpass.php");
} 
if (!$session->logged_in & $_REQUEST["page"] <> "valid" & $_REQUEST["page"] <> "r1" & $_REQUEST["page"] <> "install" & $_REQUEST["page"] <> "install2" & $_REQUEST["page"] <> "fix_admin"){
	if ($_REQUEST['popup'] == '1') {
		echo '<script type="text/javascript">parent.window.location = "index.php";parent.$.colorbox.close();';
		echo '</script>';
		die;
	}
	if ($critical_error == "") {
		?>
		<h1><?php echo LOGIN_TEXT;?></h1>
		<?php
		/**
		* User not logged in, display the login form.
		* If user has already tried to login, but errors were
		* found, display the total number of errors.
		* If errors occurred, they will be displayed.
		*/
		if($form->num_errors > 0){
			echo "<font size=\"2\" color=\"#ff0000\">".$form->num_errors." " . ERRORS_FOUND_TEXT . "</font>";
		}
		?>
		<div class="form_main">
		<form action="process.php" name="login" method="POST" class="niceform"><div class="form_a"><div class="form_left"><?php echo USER_NAME_TEXT;?>:</div><div class="form_right"><input type="text" id="user" name="user" size="30" maxlength="30" value="<?php echo $form->value("user"); ?>"><?php echo $form->error("user"); ?></div></div>
			<div class="form_a"><div class="form_left"><?php echo PASSWORD_TEXT;?>:</div><div class="form_right"><input type="password" name="pass" size="30" maxlength="30" value="<?php echo $form->value("pass"); ?>"><?php echo $form->error("pass"); ?></div></div>
			<div class="form_a" style="margin-top:5px;"><div class="form_left"><input type="checkbox" name="remember" <?php if($form->value("remember") != ""){ echo "checked"; } ?>>&nbsp;</div><div class="form_right"><?php echo REMEMBER_NEXT_TIME_TEXT; ?></div></div>
			<div class="form_a"><div class="form_left">&nbsp;</div> <div class="form_right"><input type="hidden" name="sublogin" value="1"><input type="submit" style="visibility:hidden">
			<a href="#" onclick="document.login.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo LOGIN_TEXT;?></span></a></div></div>
			<hr>
			<script type="text/javascript">document.getElementById('user').focus()</script>
			<br><a class="btn blue" href="?page=f1"><i></i><span><span></span><i></i><?php echo FORGOT_PASSWORD_TEXT;?></span></a>
			<?php
			if (ENABLE_PUBLIC_SIGNUP == "on") {
				echo "<a class=\"btn blue\" href='?page=r1'><i></i><span><span></span><i></i>" . SIGN_UP_TEXT . "</span></a>";
			}
			if(EMAIL_WELCOME){
				echo "<a class=\"btn blue\" href='valid.php'><i></i><span><span></span><i></i>" . SEND_CONFIRMATION_LINK_TEXT . "</span></a><br><br><br>";
			}
			?>
		</form>
		</div>
		</div>
		<div id="sidebar">
			<ul><li><h2><?php echo LOGIN_TEXT;?></h2><?php echo LOGIN_PAGE_RIGHT_TEXT;?>
			</li></ul>
		</div>
		<?php
	} else {
		echo "<h1>" . CRITICAL_ERROR_TEXT . "</h1><br><font color=\"red\">". strtoupper(CRITICAL_ERROR_TEXT) . ":</font> " . $critical_error . "<br><br>" . CRITICAL_ERROR_STOP_TEXT . "<br><br><br><br><br></div>";
	}
} else {
	switch ($_REQUEST["page"]) {
		case "a1":
			$page_to_load = "adddomain.php";
			break;
		case "a2":
			$page_to_load = "addfile.php";
			break;
		case "c1":
			$page_to_load = "configure.php";
			break;
		case "c2":
			$page_to_load = "copy_page.php";
			break;
		case "e1":
			$page_to_load = "editdomain.php";
			break;
		case "e2":
			$page_to_load = "editor.php";
			break;
		case "e3":
			$page_to_load = "inline_editor.php";
			break;
		case "f1":
			$page_to_load = "forgotpass.php";
			break;
		case "i1":
			$page_to_load = "image_manager.php";
			break;
		case "i2":
			$page_to_load = "includes/inline_image_upload.php";
			break;
		case "l1":
			$page_to_load = "link_manager.php";
			break;
		case "m2":
			$page_to_load = "media_manager.php";
			break;
		case "p1":
			$page_to_load = "permissions.php";
			break;
		case "p2":
			$page_to_load = "process.php";
			break;
		case "p2_d":
			echo "p2_d Page Called, please report this error";
			die;
			break;
		case "r1":
			$page_to_load = "register.php";
			break;
		case "u1":
			$page_to_load = "useredit.php";
			break;
		case "u2":
			$page_to_load = "userpermissions.php";
			break;
		case "u3":
			$page_to_load = "install/upgrade.php";
			break;
		case "valid":
			$page_to_load = "valid.php";
			break;
		case "install":
			$page_to_load = "install/main.php";
			break;
		case "install2":
			$page_to_load = "install/install.php";
			break;
		case "fix_admin":
			$page_to_load = "install/fix.php";
			break;
		case "inline_test":
			$page_to_load = "includes/inline_editor.php";
			break;
		default:
			$page_to_load = "main.php";
			break;
		}
	if (!IsSet($_REQUEST["file"])) {
			require($page_to_load);
	}
}
require('includes/footer.php');
?>