<body style="margin:10px;">
<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# editdomain.php - Used to change the settings of a domain that
#	already exists.

if(!$session->isAdmin()){
die;
}
//security check
if ($_REQUEST["domainedit"] == "") {
	$domain_check = $_REQUEST["domain"];
} else {
	$domain_check = $_REQUEST["domainedit"];
}
if (!domain_permission_check($domain_check)) {
	echo DOMAIN_CHECK_FAILED;
	die;
}
if ($_REQUEST["domain"] != "") {
	$ftp_server = $_REQUEST["domain"];
	$ftp_user_name = $_REQUEST["user"];
	$ftp_user_pass = $_REQUEST["pass"];
	$ftp_port = $_REQUEST["port"];
	$ftp_type = $_REQUEST["FTPType"];
	$ftp = new VCMS_FTP;
	$ftp->user_name = $ftp_user_name;
	// if $ftp_user_pass is blank, get the current password
	if ($ftp_user_pass == "") {
		$q = "SELECT Password FROM domains WHERE ID = " . mysql_real_escape_string($_REQUEST["domainedit"]);
		$result = mysql_query($q);
		while ($row = mysql_fetch_array($result)) {
			$password_edit = $row["Password"];
			$ftp_user_pass = decrypt_password($password_edit);
		}
	}
	
	$ftp->user_pass = $ftp_user_pass;
	$ftp->server = $ftp_server;
	$ftp->port = $ftp_port;
	$ftp->type = $ftp_type;
	$ftp->open();
	$VCMS_Crypt = new VCMS_Crypt;
	$key = $VCMS_Crypt->pbkdf2(ENCRYPTION_PASSWORD, ENCRYPTION_SALT, 1000, 32) or
		die(KEY_GENERATION_FAILED_TEXT);
	$ftp_user_pass = $VCMS_Crypt->encrypt($ftp_user_pass, $key) or
		die(ENCRYPTION_FAILED_TEXT);
	if (substr($_REQUEST["site_url"], strlen($_REQUEST["site_url"])-1,1) != "/") {
		$_REQUEST["site_url"] = $_REQUEST["site_url"] . "/";
	}
	if (substr(strtolower($_REQUEST["site_url"]), 0, 4) != "http") {
		$_REQUEST["site_url"] = "http://" . $_REQUEST["site_url"];
	}
	if ($_REQUEST["linkpath"] == "") {
		$_REQUEST["linkpath"] = $_REQUEST["domainedit"] . "cms_links";
	}
	if ($_REQUEST["imagepath"] == "") {
		$_REQUEST["imagepath"] = $_REQUEST["domainedit"] . "cms_images";
	}
	if ($_REQUEST["mediapath"] == "") {
		$_REQUEST["mediapath"] = $_REQUEST["domainedit"] . "cms_media";
	}

	$q = "UPDATE domains SET FTPType = \"" . mysql_real_escape_string($_REQUEST["FTPType"]) . "\", Port = \"" . mysql_real_escape_string($_REQUEST["port"]) . "\", InlineEditor = \"" . mysql_real_escape_string($_REQUEST["InlineEditor"]) . "\", CustomCSS = \"" . mysql_real_escape_string($_REQUEST["CustomCSS"]) . "\", Name = \"" . mysql_real_escape_string($_REQUEST["site_name"]) . "\", ftp = \"" . mysql_real_escape_string($_REQUEST["domain"]) . "\", UserName = \"" . mysql_real_escape_string($_REQUEST["user"]) . "\", Password = \"" . $ftp_user_pass . "\", SiteURL = \"" . mysql_real_escape_string($_REQUEST["site_url"]) . "\", Path = \"" . mysql_real_escape_string($_REQUEST["path"]) . "\", LinkPath = \"" . mysql_real_escape_string($_REQUEST["linkpath"]) . "\", MediaPath = \"" . mysql_real_escape_string($_REQUEST["mediapath"]) . "\", ImagePath = \"" . mysql_real_escape_string($_REQUEST["imagepath"]) . "\" WHERE ID = '" . mysql_real_escape_string($_REQUEST["domainedit"]) . "'";
	$result = mysql_query($q);
	echo "<script type=\"text/javascript\">parent.domainupdate('" . $_REQUEST["domainedit"] ."', '" . ENABLE_IMAGE_MANAGER . "', '" . ENABLE_LINK_MANAGER . "', '" . ENABLE_MEDIA_MANAGER . "', '" . ENABLE_INLINE_EDITOR . "');parent.$.colorbox.close();</script>";
	die;
}

$q = "SELECT * FROM domains WHERE ID = " . mysql_real_escape_string($_REQUEST["domainedit"]);
$result = mysql_query($q);
while ($row = mysql_fetch_array($result)) {
	$ftp_edit = $row["ftp"];
	$name_edit = $row["Name"];
	$username_edit = $row["UserName"];
	$password_edit = $row["Password"];
	$siteurl_edit = $row["SiteURL"];
	$path_edit = $row["Path"];
	$image_path_edit = $row["ImagePath"];
	$link_path_edit = $row["LinkPath"];
	$media_path_edit = $row["MediaPath"];
	$site_custom_css = $row["CustomCSS"];
	$password_edit = decrypt_password($password_edit);
	$inline_editor = $row["InlineEditor"];
	$ftp_type = $row["Type"];
	$ftp_port = $row["Port"];
}
echo "<font color=red>" . $ftperror . "</font><br>";
?>
<script type="text/javascript">
function submitdomain(){
	$(".error").hide();
	var hasError = false;
	var passwordVal = $("#pass").val();
	var checkVal = $("#confirmpass").val();
	if (passwordVal != checkVal ) {
		$("#confirmpass").after('<span class="error">Passwords do not match.</span>');
		hasError = true;
	}
	if(hasError != true) {document.add_domain.submit();}
}
function errorhide() {
	$(".error").hide();
}
</script>
<div id="register">
<h1><?php echo EDIT_DOMAIN_TEXT;?></h1>
<div class="form_main">
<form method="POST" name="add_domain"><div class="form_a"><div class="form_left"><?php echo SITE_NAME_TEXT;?>:</div><div class="form_right"><input type="text" size="60" name="site_name" id="site_name" value="<?php echo $name_edit;?>"></div></div>
<div class="form_a"><div class="form_left"><?php echo SITE_URL_TEXT;?>:</div><div class="form_right"><input size="60" type="text" name="site_url" id="site_url" value="<?php echo $siteurl_edit;?>"></div></div>
<div class="form_a"><div class="form_left"><?php echo CUSTOM_CSS_TEXT;?>:</div><div class="form_right"><input size="60" type="text" name="CustomCSS" id="CustomCSS" value="<?php echo $site_custom_css;?>"></div></div>
<div class="form_a"><div class="form_left"><?php echo FTP_SERVER_TEXT;?>:</div><div class="form_right"><select id="FTPType" name="FTPType">
	<option value="ftp" <?php if ($ftp_type == "ftp") { echo "selected";}?>>FTP</option>
	</select>://<input size="35" type="text" id="domain" name="domain" value="<?php echo $ftp_edit;?>"> Port: <input size="3" type="text" id="port" name="port" value="<?php echo $ftp_port;?>"></div></div>
	
<div class="form_a"><div class="form_left"><?php echo USER_NAME_TEXT;?>:</div><div class="form_right"><input size="30" type="text" name="user" id="user" value="<?php echo $username_edit;?>"></div></div>
<div class="form_a"><div class="form_left"><?php echo NEW_PASSWORD_TEXT;?>:</div><div class="form_right"><input size="30" type="password" id="pass" name="pass" value="" onChange="errorhide()"></div></div>
<div class="form_a"><div class="form_left"><?php echo CONFIRM_PASSWORD_TEXT;?>:</div><div class="form_right"><input size="30" type="password" id="confirmpass" name="confirmpass" value="" onChange="errorhide()"></div></div>
<?php
if (ENABLE_INLINE_EDITOR == "on") {
?>
<div class="form_a"><div class="form_left"><?php echo ENABLE_INLINE_EDITOR_TEXT;?>:</div><div class="form_right"><input type="checkbox" id="InlineEditor" name="InlineEditor" <?php if ($inline_editor == "on") { echo "checked";}?>></div></div>
<?php
}
?>
<div class="form_a"><div class="form_left"><?php echo PATH_TEXT;?>:</div><div class="form_right"><input size="60" type="text" id="path" name="path" value="<?php echo $path_edit;?>" onClick="getchoose_path('<?php echo $_REQUEST["path"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_path"></div></div></div>
<div class="form_a"><div class="form_left"><?php echo IMAGE_PATH_TEXT;?>:</div><div class="form_right"><input size="60" type="text" id="imagepath" name="imagepath" value="<?php echo $image_path_edit;?>" onClick="getchoose_image_path('<?php echo $_REQUEST["path"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_image_path"></div></div></div>
<div class="form_a"><div class="form_left"><?php echo LINK_PATH_TEXT;?>:</div><div class="form_right"><input size="60" type="text" id="linkpath" name="linkpath" value="<?php echo $link_path_edit;?>" onClick="getchoose_link_path('<?php echo $_REQUEST["path"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_link_path"></div></div></div>
<div class="form_a"><div class="form_left"><?php echo MEDIA_PATH_TEXT;?>:</div><div class="form_right"><input size="60" type="text" id="mediapath" name="mediapath" value="<?php echo $media_path_edit;?>" onClick="getchoose_media_path('<?php echo $_REQUEST["path"];?>','<?php echo $_REQUEST["domain"]; ?>','<?php echo $_REQUEST["selectedfile"];?>','<?php echo $_REQUEST["activepage"];?>')"></div></div>
<div class="form_a"><div class="form_left"></div><div class="form_right"><div id="choose_media_path"></div></div></div>
<div class="form_a"><div class="form_left"></div><div class="form_right"><input type="hidden" name="popup" value="1"><input type="hidden" name="page" value="e1"><div id="edit_domain"><a href="javascript:submitdomain()" class="btn blue"><i></i><span><span></span><i></i><?php echo SAVE_SETTINGS_TEXT;?></a></span></div><input type="hidden" id="domainedit" name="domainedit" value="<?php echo $_REQUEST["domainedit"];?>"></div></div>
<br><br>
</form>
</div>
</div>
<script type="text/javascript">
$.extend($.fn, {
		fileTree: function(o, h) {
			// Defaults
			if( !o ) var o = {};
			if( o.root == undefined ) o.root = '';
			if( o.script == undefined ) o.script = 'includes/addfile.php';
			if( o.folderEvent == undefined ) o.folderEvent = 'click';
			if( o.expandSpeed == undefined ) o.expandSpeed= 500;
			if( o.collapseSpeed == undefined ) o.collapseSpeed= 500;
			if( o.expandEasing == undefined ) o.expandEasing = null;
			if( o.collapseEasing == undefined ) o.collapseEasing = null;
			if( o.multiFolder == undefined ) o.multiFolder = true;
			if( o.loadMessage == undefined ) o.loadMessage = 'Loading...';

			$(this).each( function() {
				
				function showTree(c, t) {
					$(c).addClass('wait');
					//$(".jqueryFileTree.start").remove();
					$.post(o.script, { path: t, domain: "<?php echo $_REQUEST["domain"];?>", selectedfile: "<?php echo $_REQUEST["selectedfile"];?>", activepage: "<?php echo $_REQUEST["activepage"];?>" }, function(data) {
						$(c).find('.start').html('');
						$(c).removeClass('wait').append(data);
						if( o.root == t ) $(c).find('UL:hidden').show(); else $(c).find('UL:hidden').slideDown({ duration: o.expandSpeed, easing: o.expandEasing });
						bindTree(c);
					});
				}
				
				function bindTree(t) {
					$(t).find('LI A').bind(o.folderEvent, function() {
						if( $(this).parent().hasClass('directory') ) {
							
							if (o.form != 'path') {
								toreturn = $(this).attr('rel').slice(0,$(this).attr('rel').length-1);
								toreturn = toreturn.replace(document.getElementById('path').value + "/", '');
							} else {
								toreturn = $(this).attr('rel').slice(0,$(this).attr('rel').length-1);
							}
							eval("document.forms['add_domain']." + o.form + ".value = toreturn");
							if( $(this).parent().hasClass('collapsed') ) {
								// Expand
								if( !o.multiFolder ) {
									$(this).parent().parent().find('UL').slideUp({ duration: o.collapseSpeed, easing: o.collapseEasing });
									$(this).parent().parent().find('LI.directory').removeClass('expanded').addClass('collapsed');
								}
								$(this).parent().find('UL').remove(); // cleanup
								showTree( $(this).parent(), escape($(this).attr('rel').match( /.*\// )) );
								$(this).parent().removeClass('collapsed').addClass('expanded');
							} else {
								// Collapse
								$(this).parent().find('UL').slideUp({ duration: o.collapseSpeed, easing: o.collapseEasing });
								$(this).parent().removeClass('expanded').addClass('collapsed');
							}
						} else {
							h($(this).attr('rel'));
						}
						return false;
					});
					// Prevent A from triggering the # on non-click events
					if( o.folderEvent.toLowerCase != 'click' ) $(t).find('LI A').bind('click', function() { return false; });
				}
				// Loading message
				$(this).html('<ul class="jqueryFileTree start"><li class="wait">' + o.loadMessage + '<li></ul>');
				// Get the initial file list
				showTree( $(this), escape(o.root) );
			});
		}
	});
	
function getchoose_path(path, domain, selectedfile, activepage) {
	$('#choose_path').fileTree({ form: 'path', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', root: '', script: 'includes/choose_path.php?Password=' + document.getElementById('pass').value +'&ftp=' + document.getElementById('domain').value + '&User=' + document.getElementById('user').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value+ '&path=' + path +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
       
    });
}
function getchoose_image_path(imagepath, domain, selectedfile, activepage) {
	$('#choose_image_path').fileTree({ form: 'imagepath', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', root: '', script: 'includes/choose_image_path.php?docroot=' + document.getElementById('path').value + '&Password=' + document.getElementById('pass').value +'&ftp=' + document.getElementById('domain').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value+ '&User=' + document.getElementById('user').value + '&path=' + imagepath +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
       
    });
}
function getchoose_link_path(linkpath, domain, selectedfile, activepage) {
	$('#choose_link_path').fileTree({ form: 'linkpath', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', root: '', script: 'includes/choose_link_path.php?docroot=' + document.getElementById('path').value + '&Password=' + document.getElementById('pass').value +'&ftp=' + document.getElementById('domain').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value+ '&User=' + document.getElementById('user').value + '&path=' + linkpath +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
       
    });
}
function getchoose_media_path(mediapath, domain, selectedfile, activepage) {
	$('#choose_media_path').fileTree({ form: 'mediapath', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>', root: '', script: 'includes/choose_media_path.php?docroot=' + document.getElementById('path').value + '&Password=' + document.getElementById('pass').value +'&ftp=' + document.getElementById('domain').value + '&port=' + document.getElementById('port').value + '&FTPType=' + document.getElementById('FTPType').value+ '&User=' + document.getElementById('user').value + '&path=' + mediapath +'&domain=' + domain + '&selectedfile=' + selectedfile + '&activepage=' + activepage }, function(file) {
       
    });
}
function getEditDomain() {
	document.getElementById('edit_domain').innerHTML='<p><img src="images/ajax-loader.gif"/></p>';
	$.post("includes/editdomain.php", { site_name: document.getElementById('site_name').value, site_url: document.getElementById('site_url').value, domain: document.getElementById('domain').value, user: document.getElementById('user').value, pass: document.getElementById('pass').value, domainedit: document.getElementById('domainedit').value, path: document.getElementById('path').value, imagepath: document.getElementById('imagepath').value },
	function(data){
		document.getElementById('edit_domain').innerHTML=data;
	});
}
</script>
<?php
if ($noborder != 1) {
?>
</div>
      <div id="sidebar">
       <ul><li><h2><?php echo EDIT_DOMAIN_TEXT;?></h2>
	   <?php echo EDIT_DOMAIN_PAGE_RIGHT_TEXT;?>
	   </li></ul>
      </div>
<?php
}
?>