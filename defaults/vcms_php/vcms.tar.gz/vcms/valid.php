<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# File originally from Jpmaster77's login system
if (!class_exists('Session')) {
	$_REQUEST["page"] = "valid";
	require("index.php");
	die;
}
/* 
 * If the someone accesses this page without the correct variables
 * passed, assume they are want to fill out a form asking for a 
 * confirmation email.
 */	
if(!(isset($_GET['qs1']) && isset($_GET['qs2']))){
	?>
	<div id="form_main">
	<h1><?php echo SEND_CONFIRMATION_EMAIL_TEXT;?></h1><br>
	<form action="process.php" name="send_confirm" method="POST" class="niceform">
	<div class="form_a"><div class="form_left"><?php echo USER_NAME_TEXT;?>:</div><div class="form_right"><input type="text" name="user" maxlength="30" value="<?php echo $form->value("user"); ?>"><?php echo $form->error("user"); ?></div></div>
	<div class="form_a"><div class="form_left"><?php echo PASSWORD_TEXT;?>:</div><div class="form_right"><input type="password" name="pass" maxlength="30" value="<?php echo $form->value("pass"); ?>"><?php echo $form->error("pass"); ?></div></div>
	<div class="form_a"><div class="form_left">&nbsp;</div> <div class="form_right"><a href="#" onclick="document.send_confirm.submit(); return false" class="btn blue"><i></i><span><span></span><i></i><?php echo SEND_TEXT;?></span></a></div></div>
	<input type="submit" style="visibility:hidden">
	<input type="hidden" name="subConfirm" value="1"><br>
	</form>
	</div>
	<?php
if ($noborder != 1) {
?>
</div>
      <div id="sidebar">
       <ul><li><h2><?php echo SEND_CONFIRMATION_EMAIL_TEXT;?></h2>
	   <?php echo SEND_CONFIRMATION_EMAIL_PAGE_RIGHT_TEXT;?>
	   </li></ul>
      </div>
<?php
}

}
/* If the correct variables are passed, define and check them. */
else{
	$v_username		=	$_GET['qs1'];
	$v_userid		=	$_GET['qs2'];
	$field			=	'valid';
	$q 				=	"SELECT userid from ".TBL_USERS." WHERE username='" . mysql_real_escape_string($v_username) . "'";
	$query			=	$database->query($q) or die(mysql_error());
	$query			=	mysql_fetch_array($query);
	/* 
	 * if the userid associated with the passed username does not
	 * exactly equal the passed userid automatically redirect
	 * them to the main page.
	 */
	if(!($query['userid'] == $v_userid)){
		echo CONFIRMATION_FAIL_TEXT;
	}
	/* 
	 * If the userid's match go ahead and change the value in
	 * the valid field to 1, display a 'success' message, and
	 * redirect to main.php.
	 */
	else{
		$database->updateUserField($v_username, $field, '1') or die(mysql_error());
		echo "<h1>" . ACCOUNT_VERIFIED_TEXT . "</h1>" . ACCOUNT_VERIFIED_THANKS_TEXT . "<br><br>";
		echo $v_username. " " . ACCOUNT_VERIFIED_SUCCESSFUL_TEXT;
		}
	}
?></div>
