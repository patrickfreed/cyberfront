<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# configure.php - The popup displayed for the configuration page
?>
<script type="text/javascript">
    if (parent.$("#colorbox").css("display")=="block") {  
          
    }else{  
        window.location = 'index.php';  
    }  
</script>
<div style="margin:10px;">
<?php
if (!$session->isSuperAdmin()) {
	die;
}
if($form->num_errors > 0){
   echo "<font size=\"2\" color=\"#ff0000\">".$form->num_errors." " . ERRORS_FOUND_TEXT . "</font>";
}
if($_POST["config"] == "1") {
	foreach($_POST["settingname"] as $setting) {
		$query = "UPDATE configuration SET value = \"" . mysql_real_escape_string($_POST["setting"][$setting]) . "\" WHERE name = \"" . mysql_real_escape_string($setting) . "\"";
		if (!defined("DEMO_SITE")) {
			$result = mysql_query($query);
		}
	}
	echo "<script type=\"text/javascript\">parent.$.colorbox.close();</script>";
	die;
}
?>
<script type="text/javascript">
 /***********************************************
* Cool DHTML tooltip script- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/
var offsetxpoint=-60 //Customize x offset of tooltip
var offsetypoint=20 //Customize y offset of tooltip
var ie=document.all
var ns6=document.getElementById && !document.all
var enabletip=false
if (ie||ns6)
var tipobj=document.all? document.all["dhtmltooltip"] : document.getElementById? document.getElementById("dhtmltooltip") : ""
function ietruebody(){
	return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}
function ddrivetip(thetext, thecolor, thewidth){
	if (ns6||ie){
		if (typeof thewidth!="undefined") tipobj.style.width=thewidth+"px"
		if (typeof thecolor!="undefined" && thecolor!="") tipobj.style.backgroundColor=thecolor
		tipobj.innerHTML=thetext
		enabletip=true
		return false
	}
}
function positiontip(e){
	if (enabletip){
		var curX=(ns6)?e.pageX : event.clientX+ietruebody().scrollLeft;
		var curY=(ns6)?e.pageY : event.clientY+ietruebody().scrollTop;
		//Find out how close the mouse is to the corner of the window
		var rightedge=ie&&!window.opera? ietruebody().clientWidth-event.clientX-offsetxpoint : window.innerWidth-e.clientX-offsetxpoint-20
		var bottomedge=ie&&!window.opera? ietruebody().clientHeight-event.clientY-offsetypoint : window.innerHeight-e.clientY-offsetypoint-20
		var leftedge=(offsetxpoint<0)? offsetxpoint*(-1) : -1000
		//if the horizontal distance isn't enough to accomodate the width of the context menu
		if (rightedge<tipobj.offsetWidth)
			//move the horizontal position of the menu to the left by it's width
			tipobj.style.left=ie? ietruebody().scrollLeft+event.clientX-tipobj.offsetWidth+"px" : window.pageXOffset+e.clientX-tipobj.offsetWidth+"px"
		else if (curX<leftedge)
			tipobj.style.left="5px"
		else
			//position the horizontal position of the menu where the mouse is positioned
			tipobj.style.left=curX+offsetxpoint+"px"
			//same concept with the vertical position
			if (bottomedge<tipobj.offsetHeight)
				tipobj.style.top=ie? ietruebody().scrollTop+event.clientY-tipobj.offsetHeight-offsetypoint+"px" : window.pageYOffset+e.clientY-tipobj.offsetHeight-offsetypoint+"px"
			else
				tipobj.style.top=curY+offsetypoint+"px"
				tipobj.style.visibility="visible"
			}
		}
function hideddrivetip(){
	if (ns6||ie){
		enabletip=false
		tipobj.style.visibility="hidden"
		tipobj.style.left="-1000px"
		tipobj.style.backgroundColor=''
		tipobj.style.width=''
	}
}
document.onmousemove=positiontip
</script>
<h1><?php echo CONFIGURATION_TEXT;?></h1>
<div id="register">
	<div class="form_main">
	<form action="" name="configuration" style="background:none;border:0;" method="POST">
	<?php
	echo "<ul class=\"tabs\">";
    foreach ($configuration_tab as $value => $tab) {
		echo "<li><a href=\"#tab" . $value . "\">" . $tab . "</a></li>";
	}  
	echo "</ul>";
	echo "<div class=\"tab_container\">";
	foreach ($configuration_tab as $tab => $value) {
		echo "<div id=\"tab" . $tab . "\" class=\"tab_content\">";
		$query = "SELECT * FROM configuration WHERE active != \"0\" AND tab = \"" . $tab . "\" ORDER BY sortorder";
		$result = mysql_query($query);
		while ($row = mysql_fetch_array($result)){
			switch($row["active"]) {
				case 1:
					echo "<div class=\"form_a\"><div class=\"form_left\"><span style=\"\" class=\"dummy\" onMouseout=\"hideddrivetip()\" onMouseover=\"ddrivetip('" . $configuration_help[$row["name"]] . "','white', 425)\"; href=\"#\">" . $configuration_setting[$row["name"]] . ":</span></div><div class=\"form_right\"><input type=\"text\" size=\"55\" name=\"setting[" . $row["name"] . "]\" value=\"" . $row["value"] . "\"><input type=\"hidden\" name=\"settingname[" . $row["name"] . "]\" value=\"" . $row["name"] . "\"></div></div>";
					break;
				case 2:
					echo "<div class=\"form_a\"><div class=\"form_left\"><span style=\"\" class=\"dummy\" onMouseout=\"hideddrivetip()\" onMouseover=\"ddrivetip('" . $configuration_help[$row["name"]] . "','white', 425)\"; href=\"#\">" . $configuration_setting[$row["name"]] . ":</span></div><div class=\"form_right\"><input type=\"checkbox\" name=\"setting[" . $row["name"] . "]\""; 
					if ($row["value"] == "on") { echo "checked";}
					echo "><input type=\"hidden\" name=\"settingname[" . $row["name"] . "]\" value=\"" . $row["name"] . "\"></div></div>";
					break;				
				case 5:
					echo "<div class=\"form_a\"><div class=\"form_left\"><span style=\"\" class=\"dummy\" onMouseout=\"hideddrivetip()\" onMouseover=\"ddrivetip('" . $configuration_help[$row["name"]] . "','white', 425)\"; href=\"#\">" . $configuration_setting[$row["name"]] . ":</span></div><div class=\"form_right\"><input type=\"text\" readonly=\"readonly\" onClick=\"" . $row["name"] . "popColorPicker()\" size=\"7\" id=\"" . $row["name"] . "\" name=\"setting[" . $row["name"] . "]\" value=\"" . $row["value"] . "\"><input type=\"hidden\" name=\"settingname[" . $row["name"] . "]\" value=\"" . $row["name"] . "\"></div></div>";
					?>
					<script language="javascript" type="text/javascript">
						function <?php echo $row["name"];?>popColorPicker(){
							//preload should contain '#' hash, followed by 6 digit hex color code
							preload = document.getElementById('<?php echo $row["name"];?>').value;
							//detail factor, see class.TrueColorPicker.php
							df = 64;
							//Where to pop the color picker window
							_top = 230;
							_left = 220;
							//Where the index.php exists
							path = 'includes/TrueColorPicker/';
							if(preload != ''){
								preload = encodeURIComponent(preload);
							}
							window.open(path + 'index.php?df='+df+'&box=<?php echo $row["name"];?>&preload=' + preload, null,'width=420, height=290, top='+_top+', left='+_left+', help=no, status=no, scrollbars=no, resizable=no, dependent=yes,status=no', true);
						}
						function <?php echo $row["name"];?>passColorCode(clr){
							document.getElementById('<?php echo $row["name"];?>').value = '#' + clr;
						}
					</script>
					<?php
					break;
				default:
					echo "<div class=\"form_a\"><div class=\"form_left\"><span style=\"\" class=\"dummy\" onMouseout=\"hideddrivetip()\" onMouseover=\"ddrivetip('" . $configuration_help[$row["name"]] . "','white', 425)\"; href=\"#\">" . $configuration_setting[$row["name"]] . ":</span></div><div class=\"form_right\"><input type=\"text\" size=\"50\" name=\"setting[" . $row["name"] . "]\" value=\"" . $row["value"] . "\"><input type=\"hidden\" name=\"settingname[" . $row["name"] . "]\" value=\"" . $row["name"] . "\"></div></div>";
					break;
			}
		}
		echo "</div>";
	}
	?>
	<div class="form_a"><div class="form_left"></div><div class="form_right"><input type="hidden" name="config" value="1"><input type="hidden" name="page" value="c1"><a href="javascript:document.configuration.submit()" class="btn blue"><i></i><span><span></span><i></i><?php echo SAVE_SETTINGS_TEXT;?></span></a> <a href="#" class="btn blue" onClick="parent.$.colorbox.close(); return false;"><i></i><span><span></span><i></i><?php echo CLOSE_TEXT;?></span></a></div></div>
	<br><br>
	</div>
	
	<script>
	$(document).ready(function() {

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});

});
</script>
		
		
	</form>
	</div>
</div></div>
</div>
      <div id="sidebar">
       <ul><li><h2><?php echo CONFIGURATION_TEXT;?></h2><?php echo CONFIGURATION_PAGE_RIGHT_TEXT;?>
	   <?php
 	    if (defined("DEMO_SITE")) {
			echo "<P><b>Running in Demo Mode, no changes will be saved.</b></p>";
		}
		?>
</li></ul>
      </div>