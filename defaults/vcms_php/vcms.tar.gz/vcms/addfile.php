<?php
# V-CMS - A simple web-based content management system
#
# V-CMS is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# V-CMS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with V-CMS.  If not, see <http://www.gnu.org/licenses/>.
#
# http://www.v-cms.org
# V-CMS, Copyright 2010, VyReN, LLC
#
# addfile.php - Displayed when adding a new page to a site
?>
<script type="text/javascript">
    if (parent.$("#colorbox").css("display")=="block") {  
          
    }else{  
        window.location = 'index.php';  
    }  
</script>
<?php
if(!$session->logged_in){
	die;
}
?>
<div style="margin:10px;">
<h1><?php echo ADD_FILE_TEXT;?></h1>
<div id="FTP"><a href="#" onClick="getFTP('path=<?php echo $_REQUEST["path"];?>&amp;domain=<?php echo $_REQUEST["domain"]; ?>&amp;selectedfile=<?php echo $_REQUEST["selectedfile"];?>&amp;activepage=<?php echo $_REQUEST["activepage"];?>');return false"><?php echo CLICK_TEXT;?></a></div><br>
<?php
if ($noborder!=1) {
	?>
	</div>
<?php
}
?>
<script type="text/javascript">
$.extend($.fn, {
		fileTree: function(o, h) {
			// Defaults
			if( !o ) var o = {};
			if( o.root == undefined ) o.root = '/';
			if( o.script == undefined ) o.script = 'includes/addfile.php';
			if( o.folderEvent == undefined ) o.folderEvent = 'click';
			if( o.expandSpeed == undefined ) o.expandSpeed= 500;
			if( o.collapseSpeed == undefined ) o.collapseSpeed= 500;
			if( o.expandEasing == undefined ) o.expandEasing = null;
			if( o.collapseEasing == undefined ) o.collapseEasing = null;
			if( o.multiFolder == undefined ) o.multiFolder = true;
			if( o.loadMessage == undefined ) o.loadMessage = 'Loading...';
			
			$(this).each( function() {
				
				function showTree(c, t) {
					$(c).addClass('wait');
					//$(".jqueryFileTree.start").remove();
					$.post(o.script, { path: t, domain: "<?php echo $_REQUEST["domain"];?>", selectedfile: "<?php echo $_REQUEST["selectedfile"];?>", activepage: "<?php echo $_REQUEST["activepage"];?>" }, function(data) {
						$(c).find('.start').html('');
						$(c).removeClass('wait').append(data);
						if( o.root == t ) $(c).find('UL:hidden').show(); else $(c).find('UL:hidden').slideDown({ duration: o.expandSpeed, easing: o.expandEasing });
						bindTree(c);
					});
				}
				
				function bindTree(t) {
					$(t).find('LI A').bind(o.folderEvent, function() {
						if( $(this).parent().hasClass('directory') ) {
							if( $(this).parent().hasClass('collapsed') ) {
								// Expand
								if( !o.multiFolder ) {
									$(this).parent().parent().find('UL').slideUp({ duration: o.collapseSpeed, easing: o.collapseEasing });
									$(this).parent().parent().find('LI.directory').removeClass('expanded').addClass('collapsed');
								}
								$(this).parent().find('UL').remove(); // cleanup
								showTree( $(this).parent(), escape($(this).attr('rel').match( /.*\// )) );
								$(this).parent().removeClass('collapsed').addClass('expanded');
							} else {
								// Collapse
								$(this).parent().find('UL').slideUp({ duration: o.collapseSpeed, easing: o.collapseEasing });
								$(this).parent().removeClass('expanded').addClass('collapsed');
							}
						} else {
							h($(this).attr('rel'));
						}
						return false;
					});
					// Prevent A from triggering the # on non-click events
					if( o.folderEvent.toLowerCase != 'click' ) $(t).find('LI A').bind('click', function() { return false; });
				}
				// Loading message
				$(this).html('<ul class="jqueryFileTree start"><li class="wait">' + o.loadMessage + '<li></ul>');
				// Get the initial file list
				showTree( $(this), escape(o.root) );
			});
		}
	});



$(document).ready( function() {
	
    $('#FTP').fileTree({ root: '', loadMessage: '<?php echo LOADING_FTP_TEXT; ?>' }, function(file) {
       getFTP('selectedfile=' + file + '&domain=<?php echo $_REQUEST["domain"];?>');
    });
});

function getFTP(strURL) {
	document.getElementById('FTP').innerHTML='<?php echo LOADING_FTP_TEXT; ?><img src="images/ajax-loader.gif"/>';
	$.get("includes/addfile.php?" + strURL, {  },
	function(data){
		document.getElementById('FTP').innerHTML=data;
	});
}

</script>
</div>