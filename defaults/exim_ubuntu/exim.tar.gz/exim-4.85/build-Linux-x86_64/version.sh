# automatically generated file - see ../scripts/reversion
EXIM_RELEASE_VERSION="4.85"
EXIM_VARIANT_VERSION=""
EXIM_COMPILE_NUMBER="4"
