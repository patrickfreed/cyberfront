/*************************************************
*           Configuration header for Exim        *
*************************************************/

/* This file was automatically generated from Makefile and config.h.defaults,
using values specified in the configuration file Local/Makefile.
Do not edit it. Instead, edit Local/Makefile and rerun make. */

#ifndef OFF_T_FMT
#define OFF_T_FMT  "%ld"
#define LONGLONG_T long int
#endif

#ifndef TIME_T_FMT
#define TIME_T_FMT  "%ld"
#endif

#define SIZE_T_FMT  "%lu"
#define SSIZE_T_FMT  "%ld"
#define HAVE_IPV6             FALSE
#define HAVE_ICONV            TRUE

/* ALT_CONFIG_PREFIX not set */
/* TRUSTED_CONFIG_LIST not set */

#define APPENDFILE_MODE            0600
#define APPENDFILE_DIRECTORY_MODE  0700
#define APPENDFILE_LOCKFILE_MODE   0600
/* AUTH_CRAM_MD5 not set */
/* AUTH_CYRUS_SASL not set */
/* AUTH_DOVECOT not set */
/* AUTH_GSASL not set */
/* AUTH_HEIMDAL_GSSAPI not set */
/* AUTH_PLAINTEXT not set */
/* AUTH_SPA not set */
#define AUTH_VARS                     3
#define BIN_DIRECTORY         "/usr/exim/bin"
#define CONFIGURE_FILE        "/etc/exim.conf"
/* CONFIGURE_FILE_USE_EUID not set */
/* CONFIGURE_FILE_USE_NODE not set */
/* CONFIGURE_GROUP not set */
/* CONFIGURE_OWNER not set */
/* CYRUS_PWCHECK_SOCKET not set */
/* CYRUS_SASLAUTHD_SOCKET not set */
#define DEFAULT_CRYPT              crypt
#define DELIVER_IN_BUFFER_SIZE     8192
#define DELIVER_OUT_BUFFER_SIZE    8192
/* DISABLE_DKIM not set */
/* DISABLE_PRDR not set */
/* DISABLE_OCSP not set */
/* DISABLE_DNSSEC not set */
/* DISABLE_D_OPTION not set */
/* ENABLE_DISABLE_FSYNC not set */
#define EXIMDB_DIRECTORY_MODE      0750
#define EXIMDB_LOCK_TIMEOUT          60
#define EXIMDB_LOCKFILE_MODE       0640
#define EXIMDB_MODE                0640
#define EXIM_CLIENT_DH_MIN_MIN_BITS         512
#define EXIM_CLIENT_DH_DEFAULT_MIN_BITS    1024
/* EXIM_GNUTLS_LIBRARY_LOG_LEVEL not set */
/* EXIM_SERVER_DH_BITS_PRE2_12 not set */
#define EXIM_PERL             perl.o
#define EXIM_USERNAME         "exim"
#define EXIM_UID              0
#define EXIM_GID              0
/* EXPAND_DLFUNC not set */
/* EXPAND_LISTMATCH_RHS not set */
#define FIXED_NEVER_USERS     1, 0
/* HAVE_CRYPT16 not set */
/* HAVE_SA_LEN not set */
#define HEADERS_CHARSET       "ISO-8859-1"
#define HEADER_ADD_BUFFER_SIZE    (8192 * 4)
#define HEADER_MAXSIZE            (1024*1024)
#define INPUT_DIRECTORY_MODE       0750
/* IPV6_USE_INET_PTON not set */
/* LDAP_LIB_TYPE not set */
/* LOCAL_SCAN_HAS_OPTIONS not set */
#define LOG_DIRECTORY_MODE         0750
/* LOG_FILE_PATH not set */
#define LOG_MODE                   0640
/* LOOKUP_CDB not set */
#define LOOKUP_DBM            yes
#define LOOKUP_DNSDB          yes
/* LOOKUP_DSEARCH not set */
/* LOOKUP_IBASE not set */
/* LOOKUP_LDAP not set */
#define LOOKUP_LSEARCH        yes
/* LOOKUP_MYSQL not set */
/* LOOKUP_NIS not set */
/* LOOKUP_NISPLUS not set */
/* LOOKUP_ORACLE not set */
/* LOOKUP_PASSWD not set */
/* LOOKUP_PGSQL not set */
/* LOOKUP_SQLITE not set */
/* LOOKUP_TESTDB not set */
/* LOOKUP_WHOSON not set */
/* LOOKUP_WILDLSEARCH not set */
/* LOOKUP_NWILDLSEARCH not set */
/* LOOKUP_MODULE_DIR not set */
#define MAX_FILTER_SIZE           (1024*1024)
#define MAX_LOCALHOST_NUMBER        256
#define MAX_INCLUDE_SIZE          (1024*1024)
#define MAX_INTERFACES              250
#define MAX_NAMED_LIST               16
#define MSGLOG_DIRECTORY_MODE      0750
/* NVALGRIND not set */
/* PID_FILE_PATH not set */
/* RADIUS_CONFIG_FILE not set */
/* RADIUS_LIB_TYPE not set */
#define ROUTER_ACCEPT         yes
#define ROUTER_DNSLOOKUP      yes
#define ROUTER_IPLITERAL      yes
/* ROUTER_IPLOOKUP not set */
#define ROUTER_MANUALROUTE    yes
#define ROUTER_QUERYPROGRAM   yes
#define ROUTER_REDIRECT       yes
#define SPOOL_DIRECTORY       "/var/spool/exim"
#define SPOOL_DIRECTORY_MODE       0750
#define SPOOL_MODE                 0640
#define STRING_SPRINTF_BUFFER_SIZE (8192 * 4)
/* SUPPORT_A6 not set */
/* SUPPORT_CRYPTEQ not set */
/* SUPPORT_MAILDIR not set */
/* SUPPORT_MAILSTORE not set */
/* SUPPORT_MBX not set */
/* SUPPORT_MOVE_FROZEN_MESSAGES not set */
/* SUPPORT_PAM not set */
/* SUPPORT_TLS not set */
/* SUPPORT_TRANSLATE_IP_ADDRESS not set */
#define SYSLOG_LOG_PID        yes
/* SYSLOG_LONG_LINES not set */
#define TCP_WRAPPERS_DAEMON_NAME "exim"
#define TIMEZONE_DEFAULT      NULL
#define TMPDIR                "/tmp"
#define TRANSPORT_APPENDFILE  yes
#define TRANSPORT_AUTOREPLY   yes
/* TRANSPORT_LMTP not set */
#define TRANSPORT_PIPE        yes
#define TRANSPORT_SMTP        yes
#define USE_DB                yes
/* USE_GDBM not set */
/* USE_GNUTLS not set */

/* AVOID_GNUTLS_PKCS11 not set */
/* USE_READLINE not set */
/* USE_TCP_WRAPPERS not set */
/* USE_TDB not set */
/* WHITELIST_D_MACROS not set */
/* WITH_CONTENT_SCAN not set */
/* WITH_OLD_DEMIME not set */
/* WITH_OLD_CLAMAV_STREAM not set */

/* EXPERIMENTAL_BRIGHTMAIL not set */
/* EXPERIMENTAL_CERTNAMES not set */
/* EXPERIMENTAL_DANE not set */
/* EXPERIMENTAL_DCC not set */
/* EXPERIMENTAL_DMARC not set */
/* EXPERIMENTAL_DSN not set */
/* EXPERIMENTAL_PROXY not set */
/* EXPERIMENTAL_REDIS not set */
/* EXPERIMENTAL_SPF not set */
/* EXPERIMENTAL_SRS not set */
/* EXPERIMENTAL_EVENT not set */
/* WANT_DEEPER_PRINTF_CHECKS not set */

#define DNS_MAXNAME                1024
#define EXPAND_MAXN                  20
#define ROOT_UID                      0
#define ROOT_GID                      0
#define int_eximarith_t int64_t

#define PR_EXIM_ARITH "%" PRId64		/* C99 standard, printf %lld */
#define SC_EXIM_ARITH "%" SCNi64		/* scanf incl. 0x prefix */
#define SC_EXIM_DEC   "%" SCNd64		/* scanf decimal */

/* End of config.h */
