<?php
/*
 * Renameuser file for b/c... this sucks
 */
require_once( __DIR__ . '/Renameuser.php' );
